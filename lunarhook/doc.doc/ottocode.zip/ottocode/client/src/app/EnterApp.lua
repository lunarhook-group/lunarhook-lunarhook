
require "config"
require "cocos.init"



local MainScene = import("app.views.MainScene")

local EnterApp = class("EnterApp")

function EnterApp:ctor()
	math.randomseed(os.time())

	self:loadAppFile()

	if CC_SHOW_FPS then
        cc.Director:getInstance():setDisplayStats(true)
    end
end

function EnterApp:run()
	local scene = MainScene.new()
	if scene ~= nil then
		display.runScene(scene)
	end
end

-- 加载必要的文件
function EnterApp:loadAppFile(scene)
	import("app.base.BaseNode")
	import("app.base.BaseLayer")
	import("app.base.BaseCharacter")

	cc.Director:getInstance().eventDispatcher = require("cocos.framework.components.event").new()

	import("app.common.LangStringDefine")
	import("app.common.ResourceDef")
	import("app.common.GameDefine")
    import("app.common.GameConfig")
    import("app.common.GameAIDefine")

	import("app.common.GameTools")

    import("app.common.UserDataManager")
    import("app.common.ResourceManager")
    import("app.common.AudioManager")
    import("app.common.ConfigManager")
    import("app.common.ErrorManager")
    import("app.common.AnimationManager")
    import("app.common.EventListener")

    import("app.common.GameNetWorker")
end

return EnterApp