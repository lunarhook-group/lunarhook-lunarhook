
--创建道具

local new_item = class("new_item")

function new_item:ctor(aiManager, params)
	self.aiManager = aiManager
	self.paramList = params
	self.initFinFlag = false

	self:initParam()
end

function new_item:initParam()
	if self.paramList == nil or type(self.paramList) ~= "table" or table.nums(self.paramList) < 4 then
		return
	end

	self.ruleId = tonumber(self.paramList[1])
	if self.ruleId <= 0 then
		return
	end

	self.pos = {
		x = tonumber(self.paramList[2]),
		y = tonumber(self.paramList[3])
	}
	self.itemKeepSeconds = tonumber(self.paramList[4])
	
	self.initFinFlag = true
end

function new_item:doEvent()
	if self.initFinFlag == false or self.aiManager == nil or self.aiManager.map == nil then
		return
	end

	self.itemId = self:getItemID(self.ruleId)
	if self.itemId == nil then
		return
	end

	if self.itemId ~= nil then
		self.aiManager.map:addNewItem(self.itemId, self.pos.x, self.pos.y, self.itemKeepSeconds)
	end
end

function new_item:getItemID(ruleId)
	if ruleId == nil then
		return nil
	end

	local ruleTblInfo = ConfigManager.itemCreateRuleTbl[tostring(ruleId)]
	if ruleTblInfo == nil then
		return nil
	end

	local randomNumber = math.random(0, 10000)
	local tmpVal = 0
	for k,v in pairs(ruleTblInfo) do
		tmpVal = tmpVal + v
		if randomNumber < tmpVal then
			return tonumber(k)
		end
	end

	return nil
end

return new_item
