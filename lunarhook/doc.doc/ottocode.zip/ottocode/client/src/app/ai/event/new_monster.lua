
--创建怪物

local new_monster = class("new_monster")

function new_monster:ctor(aiManager, params)
	self.aiManager = aiManager
	self.paramList = params
	self.initFinFlag = false

	self:initParam()
end

function new_monster:initParam()
	if self.paramList == nil or type(self.paramList) ~= "table" or table.nums(self.paramList) < 3 then
		return
	end

	self.monsterId = tonumber(self.paramList[1])
	self.pos = {
		x = tonumber(self.paramList[2]),
		y = tonumber(self.paramList[3])
	}

	self.initReviveFlag = false
	if self.paramList[4] ~= nil then
		if tonumber(self.paramList[4]) == 1 then
			self.initReviveFlag = true
		end
	end
	self.needReviveFlag = self.initReviveFlag

	self.initFinFlag = true
end

function new_monster:doEvent()
	if self.aiManager == nil or self.aiManager.map == nil then
		return
	end

	self.aiManager.map:addNewMonster(self.monsterId, self.pos.x, self.pos.y, self.needReviveFlag)
	self.needReviveFlag = self.initReviveFlag
end

return new_monster
