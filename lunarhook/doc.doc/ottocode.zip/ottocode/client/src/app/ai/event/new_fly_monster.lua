--创建飞行怪物
local new_fly_monster = class("new_fly_monster")

function new_fly_monster:ctor(aiManager, params)
	self.aiManager = aiManager
	self.paramList = params
	self.initFinFlag = false

	self:initParam()
end

function new_fly_monster:initParam()
	if self.paramList == nil or type(self.paramList) ~= "table" or table.nums(self.paramList) < 5 then
		return
	end

	self.monsterId = tonumber(self.paramList[1])
	self.bornArea = {
		minX = tonumber(self.paramList[2]),
		maxX = tonumber(self.paramList[3]),
		minY = tonumber(self.paramList[4]),
		maxY = tonumber(self.paramList[5]),
	}
	
	self.initFinFlag = true
end

function new_fly_monster:doEvent()
	if self.aiManager == nil or self.aiManager.map == nil or self.initFinFlag == false then
		return
	end

	local dir = math.random(1, 4)
	local targetX = nil
	local targetY = nil
	if dir == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_TOP then
		targetX = self.bornArea.maxX
		targetY = math.random(0, self.bornArea.maxY - self.bornArea.minY) + self.bornArea.minY
	elseif dir == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_BOTTOM then
		targetY = self.bornArea.maxY
		targetX = math.random(0, self.bornArea.maxX - self.bornArea.minX) + self.bornArea.minX
	elseif dir == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_TOP then
		targetY = self.bornArea.minY
		targetX = math.random(0, self.bornArea.maxX - self.bornArea.minX) + self.bornArea.minX
	elseif dir == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_BOTTOM then
		targetX = self.bornArea.minX
		targetY = math.random(0, self.bornArea.maxY - self.bornArea.minY) + self.bornArea.minY 
	else
		return
	end

	self.aiManager.map:addNewFlyMonster(self.monsterId, targetX, targetY, dir)
end

return new_fly_monster
