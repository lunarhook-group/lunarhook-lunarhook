--怪物死了
local monster_die = class("monster_die")

function monster_die:ctor(aiManager, params, eventObj)
	self.aiManager = aiManager
	self.paramList = params
	self.eventObj = eventObj
	self.initFinFlag = false
	self.needRevive = false

	self:initParam()
end

function monster_die:initParam()
	if self.paramList == nil or type(self.paramList) ~= "table" or table.nums(self.paramList) < 1 then
		return
	end

	self.needDelayTimeAfterMonsterDied = self.paramList[1]
	self.targetMonsterId = nil

	self.hasReached = false
	self.timeRecord = 0

	self.initFinFlag = true
end

function monster_die:update(t)
	if self.initFinFlag == false or self.eventObj == nil or self.eventObj.initFinFlag == false then
		return
	end

	if self.hasReached == false then
		return
	end

	self.timeRecord = self.timeRecord + t
	if self.timeRecord >= self.needDelayTimeAfterMonsterDied then
		if self.eventObj.monsterId ~= nil then
			self.eventObj.monsterId = self.targetMonsterId
			self.eventObj.needReviveFlag = true
			self.eventObj.pos.x = self.initPos.x
			self.eventObj.pos.y = self.initPos.y
		end
		self.eventObj:doEvent()
		self:resetCondition()
	end

end

function monster_die:someoneDie(monsterId, initPos)
	if monsterId == nil then
		return
	end
	
	self.initPos = initPos

	if ConfigManager.monsterTbl[tostring(monsterId)] == nil then
		return
	end

	self.targetMonsterId = monsterId
	self.hasReached = true
	self.timeRecord = 0
end

function monster_die:resetCondition()
	self.hasReached = false
	self.timeRecord = 0
	self.targetMonsterId = nil
end

return monster_die