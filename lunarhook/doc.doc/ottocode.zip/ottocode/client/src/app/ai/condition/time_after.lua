--经过一段时间
local time_after = class("time_after")

function time_after:ctor(aiManager, params, eventObj)
	self.aiManager = aiManager
	self.paramList = params
	self.eventObj = eventObj
	self.initFinFlag = false

	self:initParam()
end

function time_after:initParam()
	if self.paramList == nil or type(self.paramList) ~= "table" or table.nums(self.paramList) < 1 then
		return
	end

	self.leftTimeToEvent = tonumber(self.paramList[1]) or 0

	self.hasReached = false
	self.initFinFlag = true
end

function time_after:update(t)
	if self.initFinFlag == false or self.eventObj == nil or self.eventObj.initFinFlag == false then
		return
	end
	if self.hasReached == true then
		return
	end

	self.leftTimeToEvent = self.leftTimeToEvent - t
	if self.leftTimeToEvent <= 0 then
		self.hasReached = true
		self:resetCondition()
		self.eventObj:doEvent()
	end
end


function time_after:resetCondition()
	self.leftTimeToEvent = 0
end

return time_after