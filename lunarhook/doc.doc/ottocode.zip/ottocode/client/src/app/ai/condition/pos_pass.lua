--玩家经过某位置
local pos_pass = class("pos_pass")

function pos_pass:ctor(aiManager, params, eventObj)
	self.aiManager = aiManager
	self.paramList = params
	self.eventObj = eventObj
	self.initFinFlag = false

	self:initParam()
end

function pos_pass:initParam()
	if self.paramList == nil or type(self.paramList) ~= "table" or table.nums(self.paramList) < 2 then
		return
	end

	self.pos = {
		x = tonumber(self.paramList[1]),
		y = tonumber(self.paramList[2])
	}
	
	self.hasReached = false
	self.initFinFlag = true
end

function pos_pass:update(t)
end

function pos_pass:checkCondition(x, y)
	if self.initFinFlag == false or self.eventObj == nil or self.eventObj.initFinFlag == false then
		return
	end
	if self.hasReached == true then
		return
	end
	if self.pos == nil or self.pos.x == nil or self.pos.y == nil then
		return
	end

	if self.pos.x == x and self.pos.y == y then
		self.hasReached = true
		self:resetCondition()
		self.eventObj:doEvent()
	end
end

function pos_pass:resetCondition()
	
end

return pos_pass