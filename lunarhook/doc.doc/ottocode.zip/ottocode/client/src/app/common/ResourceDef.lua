local ResourceDef = {

----------------------------

	--=============================================== dir
	UI_DIR = "image/",
	SOUND_DIR = "sound/",
	FONT_DIR = "font/",
	PARTICLE_DIR = "effect/particle/",


	--prefix & tailfix
	SPRITE_FROMAT_STR = ".png",
	SPRITE_PLIST_STR = ".plist",
	AUDIO_FROMAT_STR = ".mp3",

	
}



--=============================================== font
ResourceDef.FONT_GAME_MAIN = ResourceDef.FONT_DIR .. "game_font.ttf"

--=============================================== sprite
ResourceDef.IMAGE_TRANSPARENT = ResourceDef.UI_DIR .. "transparent"
ResourceDef.DEFAULT_SHOP_MAP_PIC = ResourceDef.IMAGE_TRANSPARENT

ResourceDef.GAME_MAIN_SPRITE = {
	ResourceDef.UI_DIR .. "game_res",
	ResourceDef.UI_DIR .. "player_res",
	ResourceDef.UI_DIR .. "monster_res",
	ResourceDef.UI_DIR .. "map_block_res",
	ResourceDef.UI_DIR .. "effect_res",
}

ResourceDef.PLAYER_GOD_FRAME_TAILFIX = "_god"
ResourceDef.PLAYER_PROTECT_FRAME_TAILFIX = "_protect"

ResourceDef.ARROW = "#arrow"
ResourceDef.ARROW_SELECT = "#arrow_select"
ResourceDef.CONTROL_CENTER_BG = "#control_centerBg"


--shadow
ResourceDef.PLAYER_SHADOW = "#shadow_player"
ResourceDef.MONSTER_SHADOW = "#shadow_monster"


--ani
ResourceDef.UI_FRIEND_ZHAOSHOU_RES_PARAM = {res="#friend_zhaoshou_", start=1, count=2, time=0.25}
ResourceDef.MONSTER_FIND_TARGET_WARNING_ANI_PARAM = {res="#pic_jinggao_", start=1, count=2, time=0.1}
ResourceDef.DISAPPEAR_COVER_ANI_PARAM = {res="#pic_daojucloud_", start=1, count=17, time=0.02}
ResourceDef.ITEM_EFFECT_LIGHTNING_RES_PARAM = {res="#pic_flash_", start=1, count=5, time=0.03}
ResourceDef.TITLE_SHADING_RES_PARAM = {res="#icon_zhizuo_", start=1, count=3, time=0.08}
ResourceDef.THUNDER_ANIMATION_RES_PARAM = {res="#pic_flash_", start=1, count=5, time=0.1}
ResourceDef.MONSTER_THUNDER_DIE_ANI_RES_PARAM = {res="#monster_thunder_die_", start=1, count=8, time=0.1}

--item effect lightning
ResourceDef.ITEM_EFFECT_LIGHTNING = "#item_effect_thunder"


ResourceDef.ITEM_EFFECT_PIC_SHIELD = "#pic_dun"
ResourceDef.ITEM_EFFECT_PIC_GOD = "#pic_wudi"

ResourceDef.BUTTON_BG_PANEL_LIST = {
	{res="#pic_repeat_btn_fanhui_01",size={width=108,height=58}},
	{res="#pic_repeat_btn_huanbeijing",size={width=124,height=58}},
	{res="#pic_repeat_btn_yigoumai_01",size={width=148,height=58}},
	{res="#pic_btn_size_01",size={width=160,height=90}},
}
ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST = {
	"#pic_repeat_btn_fanhui_02",
	"#pic_repeat_btn_yigoumai_02",
	"#pic_repeat_bg_game_02",
	"#pic_repeat_btn_huanbeijing_02",
	"#pic_repeat_btn_baocun_02",
	"#pic_repeat_btn_fangxiang_02",
	"#pic_repeat_tiaozhan_01",
	"#pic_repeat_quxiao_01",
}

ResourceDef.EDITOR_FACTORY_ELEMENT_LIST = {
	"#pic_make_factory_01", 
	"#pic_make_factory_02", 
	"#pic_make_factory_03", 
	"#pic_make_factory_04", 
	"#pic_make_factory_05", 
	"#pic_make_factory_06",
}

ResourceDef.PANEL_CONNECT_POLE = "#pic_repeat_link_01"
ResourceDef.BG_FLAGPOLE_RES = "#pic_repeat_link_05"
ResourceDef.PANEL_CONNECT_POLE2 = "#pic_repeat_link_07"
ResourceDef.PANEL_CONNECT_POLE3 = "#pic_repeat_link_06"

--common button res
ResourceDef.COMMON_BUTTON_RES_CONTINUE = "#btn_contioun_n"
ResourceDef.COMMON_BUTTON_RES_RETURN_LIST = "#btn_fanhuidating_n"
ResourceDef.COMMON_BUTTON_RES_NEXT_CHALLENGE ="#btn_next_n"
ResourceDef.COMMON_BUTTON_RES_RETRY = "#btn_replay_n"
ResourceDef.COMMON_BUTTON_RES_SOUND_ON = "#btn_sounds_n"
ResourceDef.COMMON_BUTTON_RES_SOUND_OFF = "#btn_soundsclose_n"

--PANEL ARROR
ResourceDef.PANEL_ARROW_RES = "#btn_down_n"
ResourceDef.WORLD_CHANGE_ARROW_RES = "#btn_left_01_s"

--GAME UI
ResourceDef.GAME_TITLE_BG_PANEL = "#panel_repeat_bg_top_01"
ResourceDef.GAME_RESULT_MIDDLE_BG_PANEL = "#panel_repeat_mid_03"
ResourceDef.GAME_RESULT_MIDDLE_PANEL_LONG_POLE = "#pic_repeat_link_03"
ResourceDef.GAME_TITLE_ICON_STEPS = "#icon_bushu_01"
ResourceDef.GAME_TITLE_ICON_STAGE = "#icon_guanqiashu_01"
ResourceDef.GAME_PAUSE_TITLE_BG = "#pic_biaoti_01"
ResourceDef.RADIO_BUTTON_SELECTED_PIC = "#pic_right_01"

ResourceDef.CONTROL_ICON_SLIDE = "#btn_huadong_n"
ResourceDef.CONTROL_ICON_PRESS = "#btn_huadong_s"
ResourceDef.SOUND_MUSIC_ON = "#btn_sound_n"
ResourceDef.SOUND_MUSIC_OFF = "#btn_sound_s"
ResourceDef.SOUND_EFFECT_ON = "#btn_music_n"
ResourceDef.SOUND_EFFECT_OFF = "#btn_music_s"

--game result
ResourceDef.GAME_WIN_FLOWER_EFFECT_PIC = "#pic_repeat_win_05"
ResourceDef.GAME_LOSE_FLOWER_EFFECT_PIC = "#pic_repeat_lose_05"
ResourceDef.GAME_WIN_FLOWER_RES_LIST = {
	"#pic_repeat_win_01",
	"#pic_repeat_win_02",
	"#pic_repeat_win_03",
	"#pic_repeat_win_04",
}
ResourceDef.GAME_LOSE_FLOWER_RES_LIST = {
	"#pic_repeat_lose_01",
	"#pic_repeat_lose_02",
	"#pic_repeat_lose_03",
	"#pic_repeat_lose_04",
}

--lamp pic
ResourceDef.LAMP_PIC = {
	"#pic_repeat_point_01", "#pic_repeat_point_02",
}

--world bg
ResourceDef.WORLD_LAYER_BG = {
	ResourceDef.UI_DIR .. "pic_bg_repeat_land_01", 
	ResourceDef.UI_DIR .. "pic_bg_repeat_land_02", 
	ResourceDef.UI_DIR .. "pic_bg_repeat_land_03", 
}

--mainscene content
ResourceDef.MAINSCENE_CONTENT = {
	transparentBg1 = "#pic_bg_repeat_01",
	transparentBg2 = "#pic_bg_repeat_02",
	roundSmallTree = {
		"#pic_bg_repeat_circular_01",
		"#pic_bg_repeat_circular_02",
		"#pic_bg_repeat_circular_03",
	},
	bigFlower = {res="#pic_hall_plant_", start=12, count=2, time=0.2},
	stone = "#pic_bg_stone",
	homeCarrot = "#pic_hall_radish_01",
	factoryCarrotList = {
		"#pic_radish_poumian_01", "#pic_radish_poumian_02",
	},
	carrotLeaf = {
		"#pic_hall_radish_02", "#pic_hall_radish_03", "#pic_hall_radish_04",
	},
	gameNameWord = {
		"#login_logo_kai", "#login_logo_xin", "#login_logo_beng", "#login_logo_beng", "#login_logo_qiu_01",
	},
	cloudResList = {
		ResourceDef.UI_DIR .. "pic_cloud_01", ResourceDef.UI_DIR .. "pic_cloud_02", ResourceDef.UI_DIR .. "pic_cloud_03", ResourceDef.UI_DIR .. "pic_cloud_04",
	},
	smallFlowerResList = {
		"#pic_hall_plant_01", "#pic_hall_plant_02", "#pic_hall_plant_03",
		"#pic_hall_plant_04", "#pic_hall_plant_05", "#pic_hall_plant_06",
		"#pic_hall_plant_07", "#pic_hall_plant_08", "#pic_hall_plant_09", 
		"#pic_hall_plant_10", "#pic_hall_plant_11",
	},
	funcPanelGanResList = {
		"#pic_bg_btnrod_01", "#pic_bg_btnrod_02", "#pic_bg_btnrod_03", "#pic_bg_btnrod_04",
	},
	floatFlowers = {
		"#pic_bg_repeat_floewer_01", "#pic_bg_repeat_floewer_02", "#pic_bg_repeat_floewer_03", "#pic_bg_repeat_floewer_04",
	},
	funcPanelBtnRes = "#pic_bg_btn_01",
	groundResList = {
		"#login_grass_botton_01", "#login_grass_botton_02", "#pic_hall_grass_botton_01",
	},
	airGround1 = "#login_grass_top_01",
	airGround2 = "#login_grass_top_02",
	airGround3 = "#pic_hall_grass_middle_01",

	groundBallResList = {
		"#pic_hall_yellowball_01", "#pic_hall_yellowball_02", "#pic_hall_yellowball_03", "#pic_hall_yellowball_04", "#pic_hall_yellowball_05",
	}
}

--stage select content
ResourceDef.STAGE_SELECT_CONTENT = {
	worldMainBgColorList = {
		cc.c4b(240, 240, 240, 255), cc.c4b(240, 240, 240, 255), cc.c4b(120, 50, 68, 255),
	},
	worldGroundMainColorList = {
		cc.c4b(255, 127, 0, 255), cc.c4b(149, 0, 0, 255), cc.c4b(17, 16, 14, 255),
	},
	stageViewMainColorList = {
		cc.c4b(91, 41, 6, 170), cc.c4b(25, 32, 64, 170), cc.c4b(120, 50, 68, 170),
	},
	worldMountainResList = {
		"#pic_bg_chenghuang_01", "#pic_bg_hongse_01", "#pic_bg_heian_01",
	},
	groundShadingResList = {
		"#pic_bg_chenghuang_02", "#pic_bg_chenghuang_03", "#pic_bg_chenghuang_08",
		"#pic_bg_hongse_02", "#pic_bg_hongse_03", "#pic_bg_hongse_04",
		"#pic_bg_heian_02", "#pic_bg_heian_03", "#pic_bg_heian_04", 
	},
	worldSceneResList = {
		"#pic_bg_chenghuang_06", "#pic_bg_chenghuang_07", "#pic_bg_chenghuang_04", "#pic_bg_chenghuang_05",
		"#pic_bg_hongse_05","#pic_bg_hongse_06","#pic_bg_hongse_07","#pic_bg_hongse_08","#pic_bg_hongse_09","#pic_bg_hongse_10","#pic_bg_hongse_12","#pic_bg_hongse_13",
		"#pic_bg_heian_05","#pic_bg_heian_06","#pic_bg_heian_07","#pic_bg_heian_08","#pic_bg_heian_09","#pic_bg_heian_10","#pic_bg_heian_12","#pic_bg_heian_13",
	},
	blackUnitResList = {
		"#pic_repeat_darkclouds_01", "#pic_repeat_darkclouds_02", "#pic_repeat_darkclouds_03", "#pic_repeat_darkclouds_04", "#pic_repeat_darkclouds_05",
	},
	stageStateResList = {
		disabled = "#icon_ disabled_01",
		normal = "#icon_normal_01",
		selected = "#icon_selected_01",
		finished = "#icon_pass_01",
	},
	flowerShakeAniParam = {res="#icon_pass_", start=1, count=8, time=0.15},
	worldTitleBgPic = "#pic_repeat_sign_01",
	flowerpotPic = "#pic_repeat_car_01",
	conveyerBeltGearPic = "#pic_repeat_wheel_01",
	stageSelectLightPic = "#pic_repeat_light_01",
	stageSelectLightFinPic = "#pic_repeat_light_02",
	btnLeftArrow = "#btn_left_n",
}


ResourceDef.RANK_LIST_MAIN_BG = "#pic_worldrank_01"
ResourceDef.MY_BEST_RECORD_BG = "#pic_mybest_01"
ResourceDef.RANK_TITLE_SMALL_FLOWER_PIC = "#pic_bg_repeat_ofloewer_01"

--
ResourceDef.TIME_ICON = "#icon_riqi_01" 
ResourceDef.HOT_ICON = "#icon_huomiao_01"

--particle
ResourceDef.RISING_PAOPAO_EFFECT = ResourceDef.PARTICLE_DIR .. "rising_paopao"
ResourceDef.FOUNTAIN_PAOPAO_EFFECT = ResourceDef.PARTICLE_DIR .. "fountain_paopao"
ResourceDef.FLOWER_EXPLODE_EFFECT = ResourceDef.PARTICLE_DIR .. "flower_explode"

--=============================================== sound
ResourceDef.GAME_SOUND_LIST = {
	--out game
	mainBGMusic = "BGM_Login_Lobby_SelectLevel",
	shopBgMusic = "BGM_CPP_Shop",
	editorBgMusic = "BGM_CPP_Shop",
	
	clickButtonEffect_begin = "Click_Begin_Btn",
	clickButtonEffect_big = "Click_Big_Btn",
	clickButtonEffect_small = "Click_Small_Btn",

	--in game
	gameBGMusic = "BGM_Game",
	gamePrepareShow = {
		"Ready_1",
		"Ready_2",
		"Ready_3",
	},
	gameReadyGo = "Player_Appear",

	groundBlockChangeEffect = {
		"Jump_Bing", "Jump_Boing",
	},
	groundBlockHasChangedEffect = "Jump_Bong",

	playerTurnBigEffect = "Jump_Big",
	playerTurnGodEffect = "Jump_Hero",

	getItemEffect = {
		"Get_Good_Gold",
		"Get_Good_Lollipop",
		"Get_Good_Hero",
		"Get_Good_Big",
		"Get_Good_Shield",
		"Get_Good_Thunder",
		"Get_Good_WinGame",
	},

	playerFallEffect = "Player_Fall",
	playerBeCaughtEffect = "Player_Die",

	buffTimeDecreaseEffect = "Clock",

	gameWinEffect_bg = "Level_Win_bg",
	gameWinEffect_flower = "Level_Win_flowers",
	gameFailedEffect = "Level_lose",

}



--=============================================== function



-----------------------------



rawset(_G, "ResourceDef", ResourceDef)
