
local ResourceManager = {
	ImageName = function(str)
		if str == nil then
			return ""
		end
		
		--todo   -HD -lang
		return str .. ResourceDef.SPRITE_FROMAT_STR
	end,

	SoundName = function(str)
		if str == nil then
			return ""
		end

		--todo    --ios xxx android ogg
		return ResourceDef.SOUND_DIR .. str .. ResourceDef.AUDIO_FROMAT_STR
	end,
	
	ResourceName = function(str)
		--todo   -HD -lang
		return str
	end,

	addFramesToCache = function(ImageName, plistFileName)
		display.loadSpriteFrames(plistFileName, ImageName)
	end,

	removeFramesFromMem = function(ImageName, plistFileName)
		display.removeSpriteFrames(plistFileName, ImageName)
	end,


}

ResourceManager.getSpriteFrameFromCache = function (filename)
	if filename == nil then
		return nil
	end

	local arr = GameTools.str_split(filename, "#")
	local framename = nil
	if #arr > 1 then
		framename = arr[2]
	else
		framename = arr[1]
	end
	return cc.SpriteFrameCache:getInstance():getSpriteFrame(framename)
end

rawset(_G, "ResourceManager", ResourceManager)
