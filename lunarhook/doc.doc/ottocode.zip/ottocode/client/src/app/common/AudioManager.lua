local AudioManager = {

	-- 返回音乐的音量值
	-- @function [parent=#audio] getMusicVolume
	-- @return number#number ret (return value: number)  返回值在 0.0 到 1.0 之间，0.0 表示完全静音，1.0 表示 100% 音量
	getMusicVolume = function ( )
		return audio.getMusicVolume()
	end,

	-- 设置音乐的音量
	-- @function [parent=#audio] setMusicVolume
	-- @param number volume 音量在 0.0 到 1.0 之间, 0.0 表示完全静音，1.0 表示 100% 音量
	setMusicVolume = function ( volume )
		local _val = tonumber(volume)
		audio.setMusicVolume(_val)
	end,

	-- 返回音效的音量值
	-- @function [parent=#audio] getEffectVolume
	-- @return number#number ret (return value: number)  返回值在 0.0 到 1.0 之间, 0.0 表示完全静音，1.0 表示 100% 音量
	getEffectVolume = function ( )
		return audio.getSoundsVolume()
	end,

	-- 设置音效的音量
	-- @function [parent=#audio] setEffectVolume
	-- @param number volume 音量在 0.0 到 1.0 之间, 0.0 表示完全静音，1.0 表示 100% 音量
	setEffectVolume = function ( volume )
		local _val = tonumber(volume)
		audio.setSoundsVolume(tonumber(volume))
	end,


	-- 预载入一个音乐文件
	-- @function [parent=#audio] preloadMusic
	-- @param string filePath 音乐文件名
	preloadMusic = function ( filePath )
		audio.preloadMusic(filePath)
	end,

	-- 播放音乐
	-- @function [parent=#audio] playBackgroundMusic
	-- @param string filePath 音乐文件名
	-- @param boolean bLoop 是否循环播放，默认为 true
	playBackgroundMusic = function ( filePath, bLoop )
		audio.playMusic(filePath, bLoop)
	end,

	--播放音效
	playSound = function ( filePath, bLoop )
		audio.playSound(filePath, bLoop)
	end,


	-- 停止播放音乐
	-- @function [parent=#audio] stopBackgroundMusic
	-- @param boolean bReleaseData 是否释放音乐数据，默认为 true
	stopBackgroundMusic = function ( bReleaseData )
		audio.stopMusic(bReleaseData)
	end,

	-- 停止播放音效
	-- @function [parent=#audio] stopBackgroundMusic
	-- @param boolean bReleaseData 是否释放音乐数据，默认为 true
	stopSound = function ( bReleaseData )
		audio.stopSound(bReleaseData)
	end,
	-- 预载入一个音效文件
	-- @function [parent=#audio] preloadEffect
	-- @param filePath 音效文件名
	preloadEffect = function ( filePath )
		audio.preloadSound(filePath)
	end,

	-- 从内存卸载一个音效
	-- @function [parent=#audio] unLoadEffect
	-- @param filePath 音效文件名
	unLoadEffect = function ( filePath )
		audio.unloadSound(filePath)
	end,

	-- 播放音效，并返回音效句柄
	-- 如果音效尚未载入，则会载入后开始播放。
	-- 该方法返回的音效句柄用于 audio.stopSound()、audio.pauseSound() 等方法。
	-- @function [parent=#audio] playEffect
	-- @param string effectPath 音效文件名
	-- @param boolean bLoop 是否重复播放，默认为 false
	-- @return integer#integer ret (return value: int)  音效句柄
	playEffect = function ( effectPath, bLoop)
		if device.platform == "android" then
			return audio.playSound(effectPath, bLoop)
		end
		return nil
	end,

	-- 停止指定的音效
	-- @function [parent=#audio] stopEffect
	-- @param integer nSoundId 音效句柄
	stopEffect = function ( nSoundId )
		audio.stopSound(nSoundId)
	end,

	-- 停止所有音效
	-- @function [parent=#audio] stopAllEffect
	stopAllEffect = function ( ... )
		audio.stopAllSounds()
	end,

}



rawset(_G, "AudioManager", AudioManager)
