local ErrorManager = {}



rawset(_G, "ErrorManager", ErrorManager)
