local ConfigManager = {

	stageTbl = require("app.config.stage"),
	monsterTbl = require("app.config.monster"),
	itemTbl = require("app.config.item"),
	itemCreateRuleTbl = require("app.config.itemCreateRule"),
	mapBlockTbl = require("app.config.mapBlock"),
	playerTbl = require("app.config.player"),
	monsterAITbl = require("app.config.monsterAI"),
	gameAITbl = require("app.config.gameAI"),
}

rawset(_G, "ConfigManager", ConfigManager)
