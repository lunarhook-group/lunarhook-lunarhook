local GameTools = {

	getValueFromCacheByKey = function (key, isString)
	    if isString ~= nil and isString == true then
	        return cc.UserDefault:getInstance():getStringForKey(key)
	    else
	        return cc.UserDefault:getInstance():getIntegerForKey(key)
	    end
	end,

	setValueFromCacheByKey = function (key, value, isString)
	    if isString ~= nil and isString == true then
	        cc.UserDefault:getInstance():setStringForKey(key, value)
	    else
	        cc.UserDefault:getInstance():setIntegerForKey(key, value)
	    end
	end,


	str_split = function (szFullString, szSeparator) 
	    local nFindStartIndex = 1
	    local nSplitIndex = 1
	    local nSplitArray = {}

	    if szFullString == nil or szFullString == "" then
	        return nSplitArray
	    end

	    while true do
	       local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex)
	       if not nFindLastIndex then
	            nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))
	            break
	       end
	       nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)
	       nFindStartIndex = nFindLastIndex + string.len(szSeparator)
	       nSplitIndex = nSplitIndex + 1
	    end
	    return nSplitArray
	end,


	calcAgree = function (srcX, srcY, dstX, dstY)
	    local tarAgree = 0
	    local xx = dstX - srcX
	    local yy = dstY - srcY

	    if xx == 0 then
	        if yy == 0 then
	            tarAgree = 0
	        elseif yy > 0 then
	            tarAgree = -90
	        elseif yy < 0 then
	            tarAgree = 90
	        end
	    elseif yy == 0 then
	        if xx > 0 then
	            tarAgree = 0
	        elseif xx < 0 then
	            tarAgree = 180
	        end
	    else
	        if xx > 0 then
	            if yy > 0 then
	                tarAgree = math.deg(math.atan(yy/xx)) * (-1)
	            elseif yy < 0 then
	                tarAgree = math.deg(math.atan(yy*(-1)/xx))
	            end
	        elseif xx < 0 then
	            if yy > 0 then
	                tarAgree = math.deg(math.atan(yy/(xx*(-1)))) + 180
	            elseif yy < 0 then
	                tarAgree = math.deg(math.atan((xx*(-1))/(yy*(-1)))) + 90
	            end
	        end
	    end
	    -- print("----- tarAgree: " .. tarAgree .. "  " .. xx .. ", " .. yy)
	    return tarAgree
	end,


	HEXtoC3b = function (hex)
	    local flag = string.lower(string.sub(hex,1,2))
	    local len = string.len(hex)
	    if len~=8 then
	        print("hex is invalid")
	        return nil 
	    end
	    if flag ~= "0x" then
	        print("not is a hex")
	        return nil
	    end
	    local rStr =  string.format("%d","0x"..string.sub(hex,3,4))
	    local gStr =  string.format("%d","0x"..string.sub(hex,5,6))
	    local bStr =  string.format("%d","0x"..string.sub(hex,7,8))
	    -- print(rStr,gStr,bStr)
	    -- local ten = string.format("%d",hex)
	    ten = cc.c3b(rStr,gStr,bStr)
	    return ten
	end,

	urlEncode = function (s)  
		s = string.gsub(s, "([^%w%.%- ])", function(c) return string.format("%%%02X", string.byte(c)) end)  
	    return string.gsub(s, " ", "+")  
	end,
	  
	urlDecode = function (s)  
	    s = string.gsub(s, '%%(%x%x)', function(h) return string.char(tonumber(h, 16)) end)  
	    return s  
	end,


	transferMapFromTable2String = function(jsonObj)
		local tarString = ""

		--todo

		return tarString
	end,

	transferMapFromStringToTable = function(str)
		local tarTable = {}

		--todo

		return tarTable
	end,

	shakeNode = function (time, offsetX, offsetY)
		if time == nil or offsetX == nil or offsetY == nil then
			return nil
		end

	    local t = time
	    local offsetX = offsetX
	    local offsetY = offsetY

	    local move1 = cc.MoveBy:create(t ,cc.p(offsetX, offsetY))
	    local seq = cc.Sequence:create(move1, move1:reverse(), move1:reverse(), move1)
	    return seq
	end,


	captureScreen = function (picname, node, size)
		if node == nil or size == nil then
			return
		end
		if size.width == nil or size.height == nil then 
			return
		end

		local render = cc.RenderTexture:create(size.width, size.height)
		if render == nil then
			return
		end

		local writablePath = cc.FileUtils:getInstance():getWritablePath()
		render:begin()
	    node:visit()
	    render:endToLua()
	    render:saveToFile(picname, cc.IMAGE_FORMAT_PNG)          --写到文件
	    -- print("save " .. picname .. " to ".. writablePath .. picname)

	end,

	getTextureData = function(picname)
		local result = ""
		local file = io.open(picname, "rb")
		local content = file:read("*all")
		file:close()
		for i = 1, string.len(content) do
			local charcode = tonumber(string.byte(content, i, i));
			local hexstr = string.format("%02X", charcode);
			result = result .. hexstr
		end

		return result
	end,

	makeTextureByData = function(picname, strData)
		local filename = cc.FileUtils:getInstance():getWritablePath() .. picname
		local fp = io.open(filename, "wb+")
		for i=1, #strData, 2 do
			local str = string.sub(strData, i, i+1)
			local byte = tonumber(str, 16)
			fp:write(string.char(byte))
		end
		fp:close()
	end,

	makeMoveClouds = function(x, y, width, height)
		local cloudResAvgWidth = 500 
		local cloudResAvgHeight = 200 

		local column = math.ceil(width / cloudResAvgWidth)
		local row = math.ceil(height / cloudResAvgHeight)
		local useIdx = 0

		local node = display.newNode()
		local cloudMoveUnitTime = 30

		for i=1, row do
			for j=1, column do
				useIdx = useIdx + 1
				if useIdx > #ResourceDef.MAINSCENE_CONTENT.cloudResList then
					useIdx = 1
				end
				local cloudPic = display.newSprite(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.cloudResList[useIdx]))
				if cloudPic ~= nil then
					cloudPic:setAnchorPoint(cc.p(0, 0.5))
					local randomOffsetY = cloudResAvgHeight*0.4 - math.random(0, cloudResAvgHeight*0.5)
					local offX = 0
					if math.fmod(i, 2) == 1 then
						offX = cloudResAvgWidth/2
					end
					cloudPic:setPosition(cc.p((j-1)*cloudResAvgWidth + x +offX, (i-1)*cloudResAvgHeight + y + randomOffsetY))
					cloudPic:setScale(math.random(40,80)/100)
					node:addChild(cloudPic)
					cloudPic:runAction(cc.RepeatForever:create(cc.Sequence:create(
						cc.MoveBy:create(cloudMoveUnitTime*(column-j+1), cc.p((column-j+1)*cloudResAvgWidth, 0)),
						cc.CallFunc:create(function()
							cloudPic:setPosition(cc.p(x+offX, (i-1)*cloudResAvgHeight + y + randomOffsetY))
						end),
						cc.MoveBy:create(cloudMoveUnitTime*(j-1), cc.p((j-1)*cloudResAvgWidth, 0))
					)))
				end
			end
		end

		return node
	end,
	
	LabelEnableOutline = function(label, outlineSize)
		if label == nil then
			return
		end
		if outlineSize == nil or outlineSize <= 0 then
			outlineSize = 1
		end

		label:enableOutline(cc.c4b(0,0,0,255), outlineSize)
	end,
	
}



rawset(_G, "GameTools", GameTools)
