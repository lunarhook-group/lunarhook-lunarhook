
local GameNetWorker = {}

GameNetWorker.createHttpRequest = function (url)
	local http = require("app.common.net.luasocket.http")
	local resp, retCode = http.request(url)
	if resp ~= nil and retCode ~= nil and retCode == 200 then
		return resp
	end
	return nil
end

GameNetWorker.createHttpRequestWithPostParam = function (url, paramList, isFormFlag)
	if isFormFlag == nil then
		isFormFlag = true
	end

	local http = require("app.common.net.luasocket.http")
	local ltn12 = require("app.common.net.luasocket.ltn12")
	
	local reqbody = ""
	local respbody = {}

	local reqHead = nil
	if isFormFlag == true then
		if paramList ~= nil and type(paramList) == "table" then
			for k,v in pairs(paramList) do
				reqbody = reqbody .. k .."="..v.."&";
			end
		end
		-- reqbody = reqbody .. "curTime="..os.time()

		reqHead = {
            ["Accept"] = "*/*",
            ["Accept-Encoding"] = "gzip, deflate",
            ["Accept-Language"] = "en-us",
            ["Content-Type"] = "application/x-www-form-urlencoded",
            ["content-length"] = string.len(reqbody)
        }
	else
		if paramList ~= nil and type(paramList) == "table" then
			reqbody = json.encode(paramList)
		end

		reqHead = {
            ["Accept"] = "*/*",
            ["Accept-Encoding"] = "gzip, deflate",
            ["Accept-Language"] = "en-us",
            ["Content-Type"] = "application/json",
            ["content-length"] = string.len(reqbody)
        }
	end

	local body, code, headers, status = http.request {
        method = "POST",
        url = url,
        source = ltn12.source.string(reqbody),
        headers = reqHead,
        sink = ltn12.sink.table(respbody)
    }

    if tonumber(code) == 200 then
    	if isFormFlag == true then
    		return true, table.concat(respbody)
    	else
    		return true, table.concat(respbody)
    	end
    else
    	return false, code
    end
end

GameNetWorker.checkNetworkCanUse = function ()
	if GameConfig.PLATFORM == "android" then
		local retFlag, retStr = luaj.callStaticMethod(GameConfig.ANDROID_PACKAGE_MAIN_ACTIVITY, "isNetWorkConnected", {}, "()Ljava/lang/String;")
		if retFlag == true then
			if retStr == "1" then
				return true
			else
				return false
			end
		end
	-- elseif GameConfig.PLATFORM == "ios" then
 --        local retFlag, retStr = luaoc.callStaticMethod("DeviceInfo", "IsNetWorkEnabled")
 --        if retFlag == true then
 --            if retStr == "1" then
 --                return true
 --            else
 --                return false
 --            end
 --        end
	-- else
	-- 	local http = require "app.common.net.luasocket.http"
	-- 	local resp, retCode = http.request(GameConfig.WEB_SERVER_URL .. "common/loginCheck.php")
	-- 	if resp == nil or retCode == nil then
 --            print("===== network logincheck failed ==== ", resp, retCode)
 --            return false
	-- 	end
	end
	return true
end

rawset(_G, "GameNetWorker", GameNetWorker)
