local UserDataManager = {
	USER_DATA_QUERY_DEFINE = {
		PLAYER_UID = "PLAYER_UID",
		USER_BASIC_DATA_PREFIX = "PLAYER_BASIC_DATA",
		USER_MAKE_MAP_LIST = "USER_MAKE_MAP_LIST",
		USER_GAME_CONTROL_SETTING = "USER_GAME_CONTROL_SETTING",
		USER_GAME_DIFFICULTY_SETTING = "USER_GAME_DIFFICULTY_SETTING",
		USER_SOUND_MUSIC_ONOFF_SETTING = "USER_SOUND_MUSIC_ONOFF_SETTING",
		USER_SOUND_EFFECT_ONOFF_SETTING = "USER_SOUND_EFFECT_ONOFF_SETTING",
	},

	PLAYER_STAGES_STATE_LIST = {},
	PlayerModelID = 1,

	UM_COIN = 0,
	UM_CANDY = 0,

	PLAYER_UID = "",

	PLAYER_MAP_UPLOAD_LIST = {},
	PLAYER_MAP_DOWNLOAD_LIST = {},

	PLAYER_MAP_MAKE_LIST = {},

	RANK_LIST = {},

	PLAYER_SETTINGS = {},
}

UserDataManager.loadPlayerData = function()
	-- GameTools.setValueFromCacheByKey(UserDataManager.USER_DATA_QUERY_DEFINE.PLAYER_UID, "", true)  --for reset, for test

	--uuid
	local player_uid = GameTools.getValueFromCacheByKey(UserDataManager.USER_DATA_QUERY_DEFINE.PLAYER_UID, true)
	if player_uid == nil or player_uid == "" then
		--first time enter game
		player_uid = "0000"
	end
	UserDataManager.PLAYER_UID = player_uid

	UserDataManager.getPlayerMakeMapList()
	UserDataManager.loadPlayerSettings()
	UserDataManager.refreshPlayerSetting()
end

UserDataManager.loadPlayerSettings = function()
	UserDataManager.PLAYER_SETTINGS.gamespeed = GameTools.getValueFromCacheByKey(UserDataManager.USER_DATA_QUERY_DEFINE.USER_GAME_DIFFICULTY_SETTING, true)
	if UserDataManager.PLAYER_SETTINGS.gamespeed == nil or UserDataManager.PLAYER_SETTINGS.gamespeed == "" then
		UserDataManager.PLAYER_SETTINGS.gamespeed = GameDefine.GAME_DIFFICULT_TYPE.normal
	elseif GameDefine.GAME_DIFFICULT_TYPE[UserDataManager.PLAYER_SETTINGS.gamespeed] == nil then
		UserDataManager.PLAYER_SETTINGS.gamespeed = GameDefine.GAME_DIFFICULT_TYPE.normal
	end

	UserDataManager.PLAYER_SETTINGS.controlmode = GameTools.getValueFromCacheByKey(UserDataManager.USER_DATA_QUERY_DEFINE.USER_GAME_CONTROL_SETTING, true)
	if UserDataManager.PLAYER_SETTINGS.controlmode == nil or UserDataManager.PLAYER_SETTINGS.controlmode == "" then
		UserDataManager.PLAYER_SETTINGS.controlmode = "button"  --"slide"
	end

	UserDataManager.PLAYER_SETTINGS.soundmusiconoff = GameTools.getValueFromCacheByKey(UserDataManager.USER_DATA_QUERY_DEFINE.USER_SOUND_MUSIC_ONOFF_SETTING, true)
	if UserDataManager.PLAYER_SETTINGS.soundmusiconoff == nil or UserDataManager.PLAYER_SETTINGS.soundmusiconoff == "" then
		UserDataManager.PLAYER_SETTINGS.soundmusiconoff = "on"
	end

	UserDataManager.PLAYER_SETTINGS.soundeffectonoff = GameTools.getValueFromCacheByKey(UserDataManager.USER_DATA_QUERY_DEFINE.USER_SOUND_EFFECT_ONOFF_SETTING, true)
	if UserDataManager.PLAYER_SETTINGS.soundeffectonoff == nil or UserDataManager.PLAYER_SETTINGS.soundeffectonoff == "" then
		UserDataManager.PLAYER_SETTINGS.soundeffectonoff = "on"
	end
	
	UserDataManager.savePlayerSettings()
end

UserDataManager.refreshPlayerSetting = function()
	if UserDataManager.PLAYER_SETTINGS.soundmusiconoff == "on" then
		AudioManager.setMusicVolume(1)
	else
		AudioManager.setMusicVolume(0)
	end

	if UserDataManager.PLAYER_SETTINGS.soundeffectonoff == "on" then
		AudioManager.setEffectVolume(1)
	else
		AudioManager.setEffectVolume(0)
	end
end

UserDataManager.savePlayerSettings = function()
	GameTools.setValueFromCacheByKey(UserDataManager.USER_DATA_QUERY_DEFINE.USER_GAME_DIFFICULTY_SETTING, UserDataManager.PLAYER_SETTINGS.gamespeed, true)
	GameTools.setValueFromCacheByKey(UserDataManager.USER_DATA_QUERY_DEFINE.USER_GAME_CONTROL_SETTING, UserDataManager.PLAYER_SETTINGS.controlmode, true)
	GameTools.setValueFromCacheByKey(UserDataManager.USER_DATA_QUERY_DEFINE.USER_SOUND_MUSIC_ONOFF_SETTING, UserDataManager.PLAYER_SETTINGS.soundmusiconoff, true)
	GameTools.setValueFromCacheByKey(UserDataManager.USER_DATA_QUERY_DEFINE.USER_SOUND_EFFECT_ONOFF_SETTING, UserDataManager.PLAYER_SETTINGS.soundeffectonoff, true)
end

UserDataManager.savePlayerUID = function(playerId)
	UserDataManager.PLAYER_UID = playerId
	GameTools.setValueFromCacheByKey(UserDataManager.USER_DATA_QUERY_DEFINE.PLAYER_UID, playerId, true)
end

UserDataManager.savePlayerBaseData = function()
	local tpArr = {
		model_id = UserDataManager.PlayerModelID,
		coin = UserDataManager.UM_COIN,
		candy = UserDataManager.UM_CANDY
	}
	GameTools.setValueFromCacheByKey(UserDataManager.USER_DATA_QUERY_DEFINE.USER_BASIC_DATA_PREFIX, json.encode(tpArr), true)
end

UserDataManager.getPlayerMakeMapList = function()
	local playerMakeMapListStr = GameTools.getValueFromCacheByKey(UserDataManager.USER_DATA_QUERY_DEFINE.USER_MAKE_MAP_LIST, true)
	if playerMakeMapListStr ~= nil and playerMakeMapListStr ~= "" then
		UserDataManager.PLAYER_MAP_MAKE_LIST = json.decode(playerMakeMapListStr) or {}
	end
end

UserDataManager.savePlayerMakeMapList = function()
	GameTools.setValueFromCacheByKey(UserDataManager.USER_DATA_QUERY_DEFINE.USER_MAKE_MAP_LIST, json.encode(UserDataManager.PLAYER_MAP_MAKE_LIST), true)
end

rawset(_G, "UserDataManager", UserDataManager)
