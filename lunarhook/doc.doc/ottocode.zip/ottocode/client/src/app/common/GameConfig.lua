local GameConfig = {
	SERVER_ADDRESS = "http://211.159.156.169:1337/",
	-- SERVER_ADDRESS = "http://127.0.0.1:1337/",
	REQUEST_URL = {
		login = "login",
		upload = "upload",
		shoplist = "shoplist",
		shopbuy = "shopbuy",
		mapInfo = "mapInfo",
		mylist = "mylist",
		rank = "rank",
		stagecomplete = "stagecomplete",
	},

	PLAYER_JUMP_TIME_EACH_BLOCK = {
		heaven = 1.5,
		easy = 1.2,
		normal = 1.0,
		hard = 0.8,
		hell = 0.5,
	},
}

GameConfig.ISONLINE = true

GameConfig.PLATFORM = device.platform

GameConfig.PACKAGE_MAIN_PATH = "com/umi/otto"
GameConfig.ANDROID_PACKAGE_MAIN_ACTIVITY = GameConfig.PACKAGE_MAIN_PATH .. "/gameActivity"

GameConfig.SHOP_CONTENT = {
	{
		name = LangStringDefine.SHOP_NAME_LATEST,
		shopType = GameDefine.SHOP_TYPE.latest,
	},
	{
		name = LangStringDefine.SHOP_NAME_FAVIROR,
		shopType = GameDefine.SHOP_TYPE.faviror,
	},
	{
		name = LangStringDefine.SHOP_NAME_RECOMMAND,
		shopType = GameDefine.SHOP_TYPE.recommand,
	},
}

GameConfig.CAPTURE_MAP_MINI_PIC_WIDTH = 145

GameConfig.DEFAULT_MONSTER_AI_ID = 1
GameConfig.DEFAULT_GAME_AI_ID = 1

GameConfig.DEFAULT_ITEM_KEEP_TIME = 7
GameConfig.ITEM_DISAPPEAR_WARNING_TIME = 3
GameConfig.ITEM_DISAPPEAR_ACTION_TIME = 0.3

--登录到主场景过渡时间
GameConfig.LOGIN_TO_MAIN_TRANS_TIME = 2
--场景过渡变黑时间
GameConfig.UI_TRANSITION_TIME = 0.8

--world 旋转切换时间
GameConfig.WORLD_TRANSITION_ROTATION_TIME = 0.8

--地编地图移动速度
GameConfig.GROUND_MOVE_CONTROL_SPEED = 300

--大脚动画的参数
GameConfig.BIG_FOOT_GROUND_FLOAT_UNIT_TIME = 0.15
GameConfig.BIG_FOOT_GROUND_FLOAT_OFFSETY = 10

--
GameConfig.USER_MAKE_MAP_SCENE_AI_LIST = {1,2,3}

--boss stage
GameConfig.WAIT_KEY_BLOCK_APPEAR_NEED_TIME = 5
GameConfig.BOSS_STAGE_SHAKE_GROUND_TIME_INTERNAL = 10
GameConfig.BOSS_STAGE_KEY_BLOCK_ID = 13
GameConfig.BOSS_STAGE_BOSS_MONSTER_ID = 6
GameConfig.BOSS_MOVE_SPEED = 2
GameConfig.BOSS_CALC_NEXT_POS_TIME = 0.03

--debug
GameConfig.DEBUG_MODE = true

rawset(_G, "GameConfig", GameConfig)
