﻿local LangStringDefine = {
	FUNC_NOT_OPEN = "功能尚未开放",
	STEP_LABEL = "步数:",
	GAME_WIN_LABEL = "游戏胜利",
	GAME_FAILED_LABEL = "游戏失败",
	MOVE_MODE = "移动模式",
	EDITOR_MODE = "编辑模式",
	BACK_ALIGN = "地图居中",
	MAP_SAVE = "保存",
	LOGIN_LABEL = "登录",
	CHALLENGE_BEGIN = "开始游戏",
	STAGE_CHALLENGE_START = "开始挑战",
	STAGE_SELECT = "关卡选择",
	STAGE_SHOP = "商店",
	STAGE_EDITOR = "地图编辑",
	WORLD_IS_LOCK = "未解锁更多关卡",
	MADE_BY_ME_LABEL = "我制作的",
	EDITOR_LABEL = "地编",
	CHANGE_BG_LABEL = "换背景",
	MY_MADE_LIST_LABEL = "我已制作",
	MY_BOUGHT_LIST_LABEL = "我已购买",
	UPLOAD_LABEL = "上传",
	DELETE_LABEL = "删除",
	TEST_LABEL = "测试",
	MODIFY_LABEL = "修改",
	CHALLENGE_LABEL = "挑战",
	BUY_COMPLETE = "购买成功",
	PLAYER_INFO_LABEL = "个人信息",
	PLAYER_NAME_LABEL = "名称: ",
	PLAYER_MADE_MAP = "自定义地图",

	QUERYING_FROM_SERVER = "正在查询",
	LABEL_IS_LOADING = "加载中...",

	BEST_RECORD_DESC_LABEL = "我的最好成绩:",
	HAVE_NO_RECORD_DESC_LABEL = "您还没有通过关卡",
	GAME_FAILED_DESC_LABEL = "很遗憾，你没有通过关卡",
	GAME_SUCCESS_DESC_LABEL = "恭喜，闯关成功",
	TIME_LABEL = "用时",
	FRIEND_RANK_LABEL = "好友排名:",
	WORLD_RANK_LABEL = "世界排名:",
	GOTO_NEXT_STAGE_LABEL = "前往下一关",
	CHOOSE_OTHER_STAGE_LABEL = "选择其他关卡",
	CONTINUE_CHALLENGE = "继续挑战",
	CONTINUE_LABEL = "继续",
	SHARE_LABEL = "分享",
	JUMP_STEPS_COUNT = "跳跃步数:",
	RETURN_LABEL = "返回",
	BUY_LABEL = "购买",
	CONTROL_LABEL = "控制",
	SOUND_MUSIC_LABEL = "音乐",
	SOUND_EFFECT_LABEL = "音效",

	CONTROL_LABEL_PRESS = "按键",
	CONTROL_LABEL_SLIDE = "滑动",
	CONTROL_LABEL_OPEN = "开启",
	CONTROL_LABEL_CLOSE = "关闭",

	DIFFICULT_MODE_LABEL = {
		-- heaven = "天堂",
		easy = "慢速",
		normal = "中等",
		hard = "快速",
		-- hell = "地狱",
	},

	BUTTON_LABEL_DESC_RETYR = "重新开始",
	BUTTON_LABEL_DESC_RETURN = "返回大厅",
	BUTTON_LABEL_DESC_CONTINUE = "继续游戏",

	VIDEO_BUTTON_LABEL = "观看视频",
	RANK_BUTTON_LABEL = "排行榜",
	NO_RANK_VALUE = "未上榜",
	WAIT_FOR_SERVER_DATA = "正在请求数据...",
	HAVE_BOUGHT_MAP_LIST_LABEL = "已购买",
	HAVE_EDITED_MAP_LIST_LABEL = "已上传",
	STAGE_SHOP_TITLE_LABEL = "关卡商城",

	SHOP_NAME_LATEST = "最新",
	SHOP_NAME_FAVIROR = "畅销",
	SHOP_NAME_RECOMMAND = "精品推荐",

	STR_YEAR = "年",
	STR_MONTH = "月",
	STR_DAY = "日",
	STR_DAY2 = "天",
	STR_HOUR = "小时",
	STR_MINUTE = "分",
	STR_SECOND = "秒",

	CONFIRM_LAYER_LABEL_YES = "确定",
	CONFIRM_LAYER_LABEL_NO = "取消",
	CONFIRM_CONTENT_LABEL = {
		"确定不进行保存，返回上级页面么？",
		"确定保存当前地图么？",
		"确定删除此地图么？",
		"确定将此地图上传到服务器么？",
		"确定购买此地图么？",
	},

	LABEL_TEXT_MAKESURE_TITLE = "确认",
	LABEL_TEXT_EXIT_GAME_DESC =	"您确认要退出游戏吗?",
	LABEL_TEXT_NULL	= "无",
	LABEL_TEXT_SURE = "确定",
	LABEL_TEXT_CANCEL =	"取消",


	GAME_DESC_STRING_LIST = {
		"游戏说明：",
		"单击或滑动虚拟键位控制小球跳跃方向，连击或连续同方向活动可以即时产生大跳（越过一个地块）效果。",
		"小球踩到的地块会变成绿色，直至全部地块变为绿色时挑战关卡胜利。",
	},

	LABEL_EDITED_MAP_IS_NULL = "地图没有内容，请认真编辑"
}



rawset(_G, "LangStringDefine", LangStringDefine)
