local GameDefine = {
	GLOBAL_GRAVITY = 500,

	GAME_CONTROL_EVENT_TYPE = {
		LEFT_TOP = "left_top",
		LEFT_BOTTOM = "left_bottom",
		RIGHT_TOP = "right_top",
		RIGHT_BOTTOM = "right_bottom",
	},

	GAME_CHARACTER_DIRECTION_TYPE = {
		NONE = 0,
		LEFT_TOP = 1,
		LEFT_BOTTOM = 2,
		RIGHT_TOP = 3,
		RIGHT_BOTTOM = 4,
	},

	CHARACTER_DIR_RES_TYPE = {
		TWO = 1,
		FOUR = 2,
	},

	GROUND_BLOCK_WIDTH = 150,
	GROUND_BLOCK_HEIGHT = 75,
	MAX_GROUND_X = 25,
	MAX_GROUND_Y = 25,
	ZORDER_BASE_VALUE = 100,

	MAP_BLOCK_ANIMATION_PREFIX = "MAP_BLOCK_TRANSFER_ANIMATION_",

	MIM_CONTROL_SENSE_DISTANT_POW2 = 100, --有效的屏幕滑动距离（平方数）

	GAME_DIFFICULT_TYPE = {
		-- heaven = "heaven",
		easy = "easy",
		normal = "normal",
		hard = "hard",
		-- hell = "hell",
	},
	UI_EVENT_TYPE = {
		
	},
	GAME_EVENT_TYPE = {
		GET_ITEM = "GET_ITEM",
	},


	CHARACTER_JUMP_STATE = {
		NO 		= 1,
		BEGIN	= 2,
		RISE	= 3,
		FALL	= 4,
		FALLGROUND = 5,
		MJ 		= 6,
	},

	MAX_JUMP_HEIGHT = 35,
	MAX_SECOND_JUMP_HEIGHT = 60,

	ITEM_TYPE = {
		ADD_COIN = 1,
		ADD_CANDY = 2,
		GOD = 3,
		BIG_FOOT = 4,
		WATER_PROTECT = 5,
		THUNDER = 6,
		MAGIC_BALL = 7,
	},

	MONSTER_TYPE = {
		NORMAL = 1,
		FLY = 2,
	},

	GROUND_BLOCK_TYPE = {
		NORMAL = 1,
		ICE = 2,
		FALL = 3,
		SHOW_HIDE = 4,
	},
	
	SHOP_TYPE = {
		latest = "latest",
		faviror = "faviror",
		recommand = "recommand",
	},
}

GameDefine.GAME_CHARACTER_DEFAULT_DIRECTION = GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_BOTTOM
GameDefine.GROUND_OBJ_OFFSET_Y = GameDefine.GROUND_BLOCK_HEIGHT/2

rawset(_G, "GameDefine", GameDefine)
