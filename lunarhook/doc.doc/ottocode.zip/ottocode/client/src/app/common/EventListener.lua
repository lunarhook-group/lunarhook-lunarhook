
local EventListener = {

}

EventListener.addEventListener = function (eventName, listener)
	if cc.Director:getInstance().eventDispatcher ~= nil then
    	cc.Director:getInstance().eventDispatcher:addEventListener(eventName, listener)
    end
end

EventListener.dispatchEvent = function (event)
	if cc.Director:getInstance().eventDispatcher ~= nil then
		cc.Director:getInstance().eventDispatcher:dispatchEvent(event)
	end
end

EventListener.removeEventListener = function (eventName)
	if cc.Director:getInstance().eventDispatcher ~= nil then
		cc.Director:getInstance().eventDispatcher:removeEventListenersByEvent(eventName)
	end
end

EventListener.removeAllEventListeners = function ()
	if cc.Director:getInstance().eventDispatcher ~= nil then
		cc.Director:getInstance().eventDispatcher:removeAllEventListeners()
	end
end

rawset(_G, "EventListener", EventListener)
