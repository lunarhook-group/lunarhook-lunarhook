local AnimationManager = {
	GAME_ANIMATION_CACHE_KEY_LIST = {},

}

AnimationManager.setAniToCache = function (resName, startFrameIdx, frameCnt, playtime, aniName)
	if AnimationManager.GAME_ANIMATION_CACHE_KEY_LIST[aniName] ~= nil then
		return
	end

	local frames = display.newFrames(ResourceManager.ImageName(resName .. "%.2d"), tonumber(startFrameIdx), frameCnt, false)
	if frames == nil then
		-- print("frames error   " .. resName .. "," .. startFrameIdx .. "," .. frameCnt)
		return
	end
	local ani = display.newAnimation(frames, playtime)
	if ani == nil then
		-- print("newAnimation failed   " .. resName .. "," .. startFrameIdx .. "," .. frameCnt)
		return
	end

	AnimationManager.GAME_ANIMATION_CACHE_KEY_LIST[aniName] = true
	display.setAnimationCache(aniName, ani)
end

AnimationManager.getAniFromCacheByName = function ( name )
	return display.getAnimationCache(name)
end

AnimationManager.removeAniFromCacheByName = function ( name )
	display.removeAnimationCache(name)
end

AnimationManager.removeAnimationCache = function ()
	for k,v in pairs(AnimationManager.GAME_ANIMATION_CACHE_KEY_LIST) do
		removeAniFromCacheByName(k)
		AnimationManager.GAME_ANIMATION_CACHE_KEY_LIST[k] = nil
	end
end

rawset(_G, "AnimationManager", AnimationManager)
