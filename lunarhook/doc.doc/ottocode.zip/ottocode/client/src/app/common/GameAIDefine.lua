local GameAIDefine = {

	--场景AI事件
	SCENEAI_CONDITION_TYPE = {
		--多久之后
		time_after 				= 101,  	
		--每隔多久
		time_each 				= 102,		
		--玩家经过某个位置
		-- pos_pass 	 			= 103, 	
		--怪物死掉
		monster_die 			= 104,	
	},

	SCENEAI_EVENT_TYPE = {
		--生成道具
		new_item				= 101,
		--生成地面怪物
		new_monster				= 102,
		--生成飞行怪物
		new_fly_monster 		= 103,
	},

}

GameAIDefine.SCENEAI_CONDITION_LUA = {
	[GameAIDefine.SCENEAI_CONDITION_TYPE.time_after] 		= import("app.ai.condition.time_after"),
	[GameAIDefine.SCENEAI_CONDITION_TYPE.time_each]			= import("app.ai.condition.time_each"),
	-- [GameAIDefine.SCENEAI_CONDITION_TYPE.pos_pass] 			= import("app.ai.condition.pos_pass"),
	[GameAIDefine.SCENEAI_CONDITION_TYPE.monster_die] 		= import("app.ai.condition.monster_die"),
}

GameAIDefine.SCENEAI_EVENT_LUA = {
	[GameAIDefine.SCENEAI_EVENT_TYPE.new_item] 			= import("app.ai.event.new_item"),
	[GameAIDefine.SCENEAI_EVENT_TYPE.new_monster] 		= import("app.ai.event.new_monster"),
	[GameAIDefine.SCENEAI_EVENT_TYPE.new_fly_monster] 	= import("app.ai.event.new_fly_monster"),
}

rawset(_G, "GameAIDefine", GameAIDefine)
