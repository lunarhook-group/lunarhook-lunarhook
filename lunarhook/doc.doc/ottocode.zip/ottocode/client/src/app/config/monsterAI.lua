local tbl = 

{
	["1"] = 
	{
		["findTargetTickTime"] = 0,
		["findTargetViewport"] = 0,
		["missTargetTotalTime"] = 0,
		["missTargetViewport"] = 0,
		["followSpeedRate"] = 1,
		["miss2findDeltTime"] = 0,
		["avoidFallRate"] = 0.75
	},
	["2"] = 
	{
		["findTargetTickTime"] = 1.1,
		["findTargetViewport"] = 2,
		["missTargetTotalTime"] = 10,
		["missTargetViewport"] = 5,
		["followSpeedRate"] = 1.1,
		["miss2findDeltTime"] = 2,
		["avoidFallRate"] = 0.75
	},
	["3"] = 
	{
		["findTargetTickTime"] = 10,
		["findTargetViewport"] = 3,
		["missTargetTotalTime"] = 30,
		["missTargetViewport"] = 5,
		["followSpeedRate"] = 1.5,
		["miss2findDeltTime"] = 1,
		["avoidFallRate"] = 0.25
	}
}
return tbl