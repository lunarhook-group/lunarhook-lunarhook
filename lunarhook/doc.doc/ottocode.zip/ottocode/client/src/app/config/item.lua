local tbl = 

{
	["1"] = 
	{
		["item_type"] = 1,
		["res"] = '#treats_01',
		["params"] = {
			1
		}
	},
	["2"] = 
	{
		["item_type"] = 2,
		["res"] = '#treats_02',
		["params"] = {
			5
		}
	},
	["3"] = 
	{
		["item_type"] = 3,
		["res"] = '#treats_03',
		["params"] = {
			10
		}
	},
	["4"] = 
	{
		["item_type"] = 4,
		["res"] = '#treats_04',
		["params"] = {
			10
		}
	},
	["5"] = 
	{
		["item_type"] = 5,
		["res"] = '#treats_05',
		["params"] = {
			1
		}
	},
	["6"] = 
	{
		["item_type"] = 6,
		["res"] = '#treats_06',
		["params"] = {
			
		}
	},
	["7"] = 
	{
		["item_type"] = 7,
		["res"] = '#treats_07',
		["params"] = {
			
		}
	}
}
return tbl