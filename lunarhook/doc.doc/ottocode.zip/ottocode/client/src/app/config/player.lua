local tbl = 

{
	["1"] = 
	{
		["id"] = 1,
		["res"] = '#player01_',
		["animation"] = 
		{
			["internal"] = 0.02,
			["jump"] = 
			{
				["begin"] = 
				{
					["start"] = 1,
					["count"] = 1
				},
				["rise"] = 
				{
					["start"] = 2,
					["count"] = 9
				},
				["fall"] = 
				{
					["start"] = 11,
					["count"] = 10
				},
				["fallground"] = 
				{
					["start"] = 21,
					["count"] = 4
				}
			},
			["fall_show"] = 
			{
				["start"] = 1,
				["count"] = 1
			},
			["mj"] = 
			{
				["start"] = 51,
				["count"] = 2
			},
			["caught"] = 
			{
				["start"] = 31,
				["count"] = 9
			},
			["victory"] = 
			{
				["start"] = 1,
				["count"] = 1
			}
		}
	}
}
return tbl