local tbl = 

{
	["1"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			10
		},
		["eventId"] = 101,
		["eventParams"] = {
			101,0,0,8
		}
	},
	["2"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			13
		},
		["eventId"] = 101,
		["eventParams"] = {
			102,0,0,8
		}
	},
	["3"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			5
		},
		["eventId"] = 102,
		["eventParams"] = {
			1,0,0
		}
	},
	["4"] = 
	{
		["conditionId"] = 104,
		["conditionParams"] = {
			5
		},
		["eventId"] = 102,
		["eventParams"] = {
			2,0,0
		}
	},
	["5"] = 
	{
		["conditionId"] = 104,
		["conditionParams"] = {
			5
		},
		["eventId"] = 102,
		["eventParams"] = {
			3,0,0
		}
	},
	["101"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,10,0,10
		}
	},
	["102"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,8,0,10
		}
	},
	["103"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,12,0,12
		}
	},
	["104"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,10,0,10
		}
	},
	["105"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,11,0,11
		}
	},
	["106"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,13,0,12
		}
	},
	["107"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,13,0,17
		}
	},
	["108"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,12,0,12
		}
	},
	["109"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,11,0,11
		}
	},
	["110"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,12,0,12
		}
	},
	["111"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,12,0,12
		}
	},
	["112"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,12,0,12
		}
	},
	["113"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,13,0,13
		}
	},
	["114"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,10,0,10
		}
	},
	["115"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,13,0,13
		}
	},
	["116"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,12,0,12
		}
	},
	["117"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,14,0,14
		}
	},
	["118"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,11,0,15
		}
	},
	["119"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,11,0,11
		}
	},
	["120"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,14,0,14
		}
	},
	["121"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,8,0,16
		}
	},
	["122"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,12,0,12
		}
	},
	["123"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,12,0,12
		}
	},
	["124"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,13,0,13
		}
	},
	["125"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,13,0,12
		}
	},
	["126"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,13,0,14
		}
	},
	["127"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,12,0,14
		}
	},
	["128"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,14,0,14
		}
	},
	["129"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,16,0,15
		}
	},
	["130"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,15,0,15
		}
	},
	["131"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,15,0,15
		}
	},
	["132"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,13,0,13
		}
	},
	["133"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,11,0,19
		}
	},
	["134"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,12,0,12
		}
	},
	["135"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,18,0,14
		}
	},
	["136"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,13,0,16
		}
	},
	["137"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,11,0,11
		}
	},
	["138"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,18,0,13
		}
	},
	["139"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,16,0,14
		}
	},
	["140"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			7
		},
		["eventId"] = 103,
		["eventParams"] = {
			5,0,12,0,12
		}
	},
	["1001"] = 
	{
		["conditionId"] = 102,
		["conditionParams"] = {
			13
		},
		["eventId"] = 101,
		["eventParams"] = {
			103,0,0,8
		}
	}
}
return tbl