local tbl = 

{
	["1"] = 
	{
		["type"] = 1,
		["resType"] = 1,
		["res"] = '#monster01_',
		["aiID"] = 1,
		["animation"] = 
		{
			["internal"] = 0.02,
			["jump"] = 
			{
				["begin"] = 
				{
					["start"] = 1,
					["count"] = 7
				},
				["rise"] = 
				{
					["start"] = 8,
					["count"] = 6
				},
				["fall"] = 
				{
					["start"] = 14,
					["count"] = 4
				},
				["fallground"] = 
				{
					["start"] = 18,
					["count"] = 1
				}
			},
			["fall"] = 
			{
				["start"] = 1,
				["count"] = 1,
				["time"] = 0.1
			},
			["victory"] = 
			{
				["start"] = 41,
				["count"] = 5,
				["time"] = 0.1
			},
			["thunder"] = 
			{
				["start"] = 31,
				["count"] = 1,
				["time"] = 0.1
			}
		}
	},
	["2"] = 
	{
		["type"] = 1,
		["resType"] = 1,
		["res"] = '#monster02_',
		["aiID"] = 2,
		["animation"] = 
		{
			["internal"] = 0.02,
			["jump"] = 
			{
				["begin"] = 
				{
					["start"] = 1,
					["count"] = 7
				},
				["rise"] = 
				{
					["start"] = 8,
					["count"] = 6
				},
				["fall"] = 
				{
					["start"] = 14,
					["count"] = 4
				},
				["fallground"] = 
				{
					["start"] = 18,
					["count"] = 1
				}
			},
			["fall"] = 
			{
				["start"] = 1,
				["count"] = 1,
				["time"] = 0.1
			},
			["victory"] = 
			{
				["start"] = 41,
				["count"] = 5,
				["time"] = 0.1
			},
			["thunder"] = 
			{
				["start"] = 31,
				["count"] = 1,
				["time"] = 0.1
			}
		}
	},
	["3"] = 
	{
		["type"] = 1,
		["resType"] = 1,
		["res"] = '#monster03_',
		["aiID"] = 3,
		["animation"] = 
		{
			["internal"] = 0.02,
			["jump"] = 
			{
				["begin"] = 
				{
					["start"] = 1,
					["count"] = 7
				},
				["rise"] = 
				{
					["start"] = 8,
					["count"] = 6
				},
				["fall"] = 
				{
					["start"] = 14,
					["count"] = 4
				},
				["fallground"] = 
				{
					["start"] = 18,
					["count"] = 1
				}
			},
			["fall"] = 
			{
				["start"] = 1,
				["count"] = 1,
				["time"] = 0.1
			},
			["victory"] = 
			{
				["start"] = 41,
				["count"] = 5,
				["time"] = 0.1
			},
			["thunder"] = 
			{
				["start"] = 31,
				["count"] = 1,
				["time"] = 0.1
			}
		}
	},
	["4"] = 
	{
		["type"] = 2,
		["resType"] = 1,
		["res"] = '#monster04_',
		["aiID"] = 1,
		["animation"] = 
		{
			["internal"] = 0.02,
			["jump"] = 
			{
				["begin"] = 
				{
					["start"] = 1,
					["count"] = 1
				},
				["rise"] = 
				{
					["start"] = 1,
					["count"] = 1
				},
				["fall"] = 
				{
					["start"] = 1,
					["count"] = 1
				},
				["fallground"] = 
				{
					["start"] = 1,
					["count"] = 1
				}
			},
			["fall"] = 
			{
				["start"] = 1,
				["count"] = 2,
				["time"] = 0.05
			},
			["victory"] = 
			{
				["start"] = 11,
				["count"] = 4,
				["time"] = 0.08
			},
			["thunder"] = 
			{
				["start"] = 31,
				["count"] = 1,
				["time"] = 0.1
			}
		}
	},
	["5"] = 
	{
		["type"] = 2,
		["resType"] = 1,
		["res"] = '#monster05_',
		["aiID"] = 1,
		["animation"] = 
		{
			["internal"] = 0.02,
			["jump"] = 
			{
				["begin"] = 
				{
					["start"] = 1,
					["count"] = 1
				},
				["rise"] = 
				{
					["start"] = 1,
					["count"] = 1
				},
				["fall"] = 
				{
					["start"] = 1,
					["count"] = 1
				},
				["fallground"] = 
				{
					["start"] = 1,
					["count"] = 1
				}
			},
			["fall"] = 
			{
				["start"] = 1,
				["count"] = 7,
				["time"] = 0.5
			},
			["victory"] = 
			{
				["start"] = 41,
				["count"] = 6,
				["time"] = 0.6
			},
			["thunder"] = 
			{
				["start"] = 21,
				["count"] = 9,
				["time"] = 0.1
			}
		}
	},
	["6"] = 
	{
		["type"] = 2,
		["resType"] = 1,
		["res"] = '#monster06_',
		["aiID"] = 1,
		["animation"] = 
		{
			["internal"] = 0.1,
			["jump"] = 
			{
				["begin"] = 
				{
					["start"] = 1,
					["count"] = 4
				},
				["rise"] = 
				{
					["start"] = 1,
					["count"] = 1
				},
				["fall"] = 
				{
					["start"] = 1,
					["count"] = 1
				},
				["fallground"] = 
				{
					["start"] = 1,
					["count"] = 1
				}
			},
			["fall"] = 
			{
				["start"] = 9,
				["count"] = 2,
				["time"] = 0.5
			},
			["victory"] = 
			{
				["start"] = 31,
				["count"] = 3,
				["time"] = 0.05
			},
			["thunder"] = 
			{
				["start"] = 11,
				["count"] = 12,
				["time"] = 0.05
			}
		}
	}
}
return tbl