local tbl = 

{
	["0"] = 
	{
		["id"] = 0,
		["type"] = 0,
		["target"] = 0,
		["res"] = '#brick00_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["1"] = 
	{
		["id"] = 1,
		["type"] = 1,
		["target"] = 0,
		["res"] = '#brick01_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 20,
			["time"] = 0.8
		}
	},
	["2"] = 
	{
		["id"] = 2,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick02_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["3"] = 
	{
		["id"] = 3,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick03_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["4"] = 
	{
		["id"] = 4,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick04_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["5"] = 
	{
		["id"] = 5,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick05_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["6"] = 
	{
		["id"] = 6,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick06_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["7"] = 
	{
		["id"] = 7,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick07_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["11"] = 
	{
		["id"] = 11,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick11_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["12"] = 
	{
		["id"] = 12,
		["type"] = 1,
		["target"] = 2,
		["res"] = '#brick12_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["13"] = 
	{
		["id"] = 13,
		["type"] = 1,
		["target"] = 3,
		["res"] = '#brick13_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 20,
			["time"] = 0.8
		}
	},
	["14"] = 
	{
		["id"] = 14,
		["type"] = 1,
		["target"] = 4,
		["res"] = '#brick14_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["15"] = 
	{
		["id"] = 15,
		["type"] = 1,
		["target"] = 5,
		["res"] = '#brick15_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["16"] = 
	{
		["id"] = 16,
		["type"] = 1,
		["target"] = 6,
		["res"] = '#brick16_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["17"] = 
	{
		["id"] = 17,
		["type"] = 1,
		["target"] = 7,
		["res"] = '#brick17_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["21"] = 
	{
		["id"] = 21,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick21_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["22"] = 
	{
		["id"] = 22,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick22_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["23"] = 
	{
		["id"] = 23,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick23_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["24"] = 
	{
		["id"] = 24,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick24_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["25"] = 
	{
		["id"] = 25,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick25_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["26"] = 
	{
		["id"] = 26,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick26_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["27"] = 
	{
		["id"] = 27,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick27_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["28"] = 
	{
		["id"] = 28,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick28_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["29"] = 
	{
		["id"] = 29,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick29_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["30"] = 
	{
		["id"] = 30,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick30_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["31"] = 
	{
		["id"] = 31,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick31_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["32"] = 
	{
		["id"] = 32,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick32_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["90"] = 
	{
		["id"] = 90,
		["type"] = 2,
		["target"] = 0,
		["res"] = '#brick90_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 20,
			["time"] = 2
		}
	},
	["91"] = 
	{
		["id"] = 91,
		["type"] = 4,
		["target"] = 0,
		["res"] = '#brick91_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 20,
			["time"] = 2
		}
	},
	["92"] = 
	{
		["id"] = 92,
		["type"] = 3,
		["target"] = 1,
		["res"] = '#brick92_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 12,
			["time"] = 0.6
		}
	},
	["93"] = 
	{
		["id"] = 93,
		["type"] = 3,
		["target"] = 1,
		["res"] = '#brick93_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["94"] = 
	{
		["id"] = 94,
		["type"] = 3,
		["target"] = 1,
		["res"] = '#brick94_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 1,
			["time"] = 0.2
		}
	},
	["95"] = 
	{
		["id"] = 95,
		["type"] = 4,
		["target"] = 0,
		["res"] = '#brick95_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 8,
			["time"] = 0.4
		}
	},
	["96"] = 
	{
		["id"] = 96,
		["type"] = 3,
		["target"] = 1,
		["res"] = '#brick96_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 4,
			["time"] = 0.8
		}
	},
	["97"] = 
	{
		["id"] = 97,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick97_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 4,
			["time"] = 0.8
		}
	},
	["98"] = 
	{
		["id"] = 98,
		["type"] = 1,
		["target"] = 1,
		["res"] = '#brick98_',
		["animation"] = 
		{
			["start"] = 1,
			["count"] = 2,
			["time"] = 0.4
		}
	}
}
return tbl