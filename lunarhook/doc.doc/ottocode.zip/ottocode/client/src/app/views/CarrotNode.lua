
local CarrotNode = class("CarrotNode", function()
	return display.newNode()
end)

function CarrotNode:ctor(isInsideFlag)
	if isInsideFlag == nil then
		isInsideFlag = false
	end
	self.isInsideFlag = isInsideFlag

	self:init()
end

function CarrotNode:init()
	
	local offX = 0
	if self.isInsideFlag == false then
		self.homeCarrot = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.homeCarrot)))
	else
		self.homeCarrot = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.factoryCarrotList[1])))
		offX = -20
	end
	if self.homeCarrot ~= nil then
		self.homeCarrot:setAnchorPoint(cc.p(0.5, 0))
		self.homeCarrot:setPosition(cc.p(offX, 0))
		local scaleRate = 1.2
		self.homeCarrot:setScale(scaleRate)
		self:addChild(self.homeCarrot, 3)

		self.carrotLeaf1 = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.carrotLeaf[1])))
		if self.carrotLeaf1 ~= nil then
			self.carrotLeaf1:setAnchorPoint(cc.p(1, 0))
			self.carrotLeaf1:setScale(scaleRate)
			self.carrotLeaf1:setPosition(cc.p(0, self.homeCarrot:getContentSize().height*scaleRate - 30))
			self:addChild(self.carrotLeaf1, 1)

			self.carrotLeaf1:runAction(cc.RepeatForever:create(cc.Sequence:create(
					cc.RotateBy:create(2, 3),
					cc.RotateBy:create(3.5, -6),
					cc.RotateBy:create(2, 3)
					)))
		end
		self.carrotLeaf2 = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.carrotLeaf[2])))
		if self.carrotLeaf2 ~= nil then
			self.carrotLeaf2:setScale(scaleRate)
			self.carrotLeaf2:setAnchorPoint(cc.p(0, 0))
			self.carrotLeaf2:setPosition(cc.p(-30, self.homeCarrot:getContentSize().height*scaleRate - 30))
			self:addChild(self.carrotLeaf2, 1)

			self.carrotLeaf2:runAction(cc.RepeatForever:create(cc.Sequence:create(
					cc.RotateBy:create(0.5, -2),
					cc.RotateBy:create(1, 5),
					cc.RotateBy:create(0.8, -3)
					)))
		end
		self.carrotLeaf3 = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.carrotLeaf[3])))
		if self.carrotLeaf3 ~= nil then
			self.carrotLeaf3:setScale(scaleRate)
			self.carrotLeaf3:setAnchorPoint(cc.p(0, 0))
			self.carrotLeaf3:setPosition(cc.p(0, self.homeCarrot:getContentSize().height*scaleRate - 30))
			self:addChild(self.carrotLeaf3, 1)

			self.carrotLeaf3:runAction(cc.RepeatForever:create(cc.Sequence:create(
					cc.RotateBy:create(0.8, -4),
					cc.RotateBy:create(1.2, 7),
					cc.RotateBy:create(0.6, -3)
					)))
		end
	end

	if self.isInsideFlag == true then
		self.carrotPart2 = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.factoryCarrotList[2])))
		if self.carrotPart2 ~= nil then
			self.carrotPart2:setAnchorPoint(cc.p(0.5, 0))
			self.carrotPart2:setScale(1)
			self.carrotPart2:setPosition(cc.p(150, 465))
			self:addChild(self.carrotPart2, 2)
		end
	end
end

return CarrotNode
