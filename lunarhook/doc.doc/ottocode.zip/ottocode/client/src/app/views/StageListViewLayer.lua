
local StageListViewLayer = class("StageListViewLayer", function()
	return display.newNode()
end)

function StageListViewLayer:ctor(parentLayer)

	self.parent = parentLayer
	self.worldIdx = parentLayer.worldIdx
	self.touchEnableFlag = true

	self:initUI()
end

function StageListViewLayer:initUI()

	local stageViewBgSize = {width=display.width-150, height=200}
	local stageViewBg = cc.LayerColor:create(ResourceDef.STAGE_SELECT_CONTENT.stageViewMainColorList[self.worldIdx], stageViewBgSize.width, stageViewBgSize.height)
	if stageViewBg ~= nil then
		stageViewBg:setAnchorPoint(cc.p(0, 0))
		stageViewBg:setPosition(cc.p(0, 0))
		self:addChild(stageViewBg, 50)

		local conveyerbeltColor = cc.c4b(227,96,5,255)
		local conveyerbeltLayer = cc.LayerColor:create(conveyerbeltColor, stageViewBgSize.width-40, 18)
		if conveyerbeltLayer ~= nil then
			conveyerbeltLayer:setAnchorPoint(cc.p(0, 0))
			conveyerbeltLayer:setPosition(cc.p(20, 15))
			stageViewBg:addChild(conveyerbeltLayer, 2)
		end

		local conveyerbeltSideLayer1 = cc.LayerColor:create(conveyerbeltColor, 18, 33)
		if conveyerbeltSideLayer1 ~= nil then
			conveyerbeltSideLayer1:setAnchorPoint(cc.p(0, 0))
			conveyerbeltSideLayer1:setPosition(cc.p(5, 0))
			stageViewBg:addChild(conveyerbeltSideLayer1, 1)
		end
		local conveyerbeltSideLayer2 = cc.LayerColor:create(conveyerbeltColor, 18, 33)
		if conveyerbeltSideLayer2 ~= nil then
			conveyerbeltSideLayer2:setAnchorPoint(cc.p(0, 0))
			conveyerbeltSideLayer2:setPosition(cc.p(stageViewBgSize.width-5-18, 0))
			stageViewBg:addChild(conveyerbeltSideLayer2, 1)
		end

		local gearCount = 11
		self.gearList = {}
		for i=1, gearCount do
			self.gearList[i] = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.conveyerBeltGearPic)))
			if self.gearList[i] ~= nil then
				self.gearList[i]:setAnchorPoint(cc.p(0.5,0.5))
				self.gearList[i]:setPosition(cc.p(((i-1)*stageViewBgSize.width-80)/(gearCount-1) + 14, 24))
				stageViewBg:addChild(self.gearList[i], 5)
			end
		end
		self.gearList[1]:setPosition(cc.p(self.gearList[1]:getPositionX()+9, self.gearList[1]:getPositionY()-15))
		self.gearList[gearCount]:setPosition(cc.p(self.gearList[gearCount]:getPositionX()-19, self.gearList[gearCount]:getPositionY()-15))

		--arrow
		self.leftArrow = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.btnLeftArrow)))
		if self.leftArrow ~= nil then
			self.leftArrow:setAnchorPoint(cc.p(0.5, 0))
			self.leftArrow:setPosition(cc.p(0, stageViewBgSize.height/2-20))
			stageViewBg:addChild(self.leftArrow, 14)
		end
		self.rightArrow = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.btnLeftArrow)))
		if self.rightArrow ~= nil then
			self.rightArrow:setAnchorPoint(cc.p(0.5, 0))
			self.rightArrow:setScaleX(-1)
			self.rightArrow:setPosition(cc.p(stageViewBgSize.width, stageViewBgSize.height/2-20))
			stageViewBg:addChild(self.rightArrow, 14)
		end

		--stages view content
		self:initData()
		self:initView()
		if self.tableView ~= nil then
			self.tableView:setPosition(cc.p(0, 35))
			stageViewBg:addChild(self.tableView, 10)
		end

		--world title
		local worldTitleBg = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.worldTitleBgPic)))
		if worldTitleBg ~= nil then
			worldTitleBg:setAnchorPoint(cc.p(0, 0))
			worldTitleBg:setPosition(cc.p(10, 160))
			stageViewBg:addChild(worldTitleBg, 15)

			local worldTitleLabel = display.newTTFLabel({
		        text = "World " .. self.worldIdx,
		        font = ResourceDef.FONT_GAME_MAIN,
		        size = 22,
		        color = cc.c3b(255,255,255),
		        align = cc.TEXT_ALIGNMENT_CENTER
		    })
		    if worldTitleLabel ~= nil then
		    	worldTitleLabel:setAnchorPoint(cc.p(0.5,0.5))
		    	worldTitleLabel:setPosition(cc.p(60, 45))
		    	worldTitleBg:addChild(worldTitleLabel)
		    end
		end
	end

end

function StageListViewLayer:initData()
	self.stageData = self.parent.parent.stageData[self.worldIdx]
end

function StageListViewLayer:refreshView()
	if self.tableView == nil then
		return
	end

	local curOffset = self.tableView:getContentOffset()

	self.parent.parent:initStageData()
	self:initData()
	self.tableView:reloadData()
	
	self.tableView:setContentOffset(curOffset)
end

function StageListViewLayer:initView()
	local viewSize = {width=display.width-150, height=170}
	local pageStageCount = 6

	self.flowerShakeAni = AnimationManager.getAniFromCacheByName("flower_fin_shake_ani")
	if self.flowerShakeAni == nil then
		AnimationManager.setAniToCache(ResourceDef.STAGE_SELECT_CONTENT.flowerShakeAniParam.res, ResourceDef.STAGE_SELECT_CONTENT.flowerShakeAniParam.start, ResourceDef.STAGE_SELECT_CONTENT.flowerShakeAniParam.count, ResourceDef.STAGE_SELECT_CONTENT.flowerShakeAniParam.time, "flower_fin_shake_ani")
		local ani = AnimationManager.getAniFromCacheByName("flower_fin_shake_ani")
		if ani ~= nil then
			self.flowerShakeAni = cc.RepeatForever:create(cc.Animate:create(ani))
			if self.flowerShakeAni ~= nil then
				self.flowerShakeAni:retain()
			end
		end
	end

	self.tableView = cc.TableView:create(cc.size(viewSize.width, viewSize.height))
   	if self.tableView ~= nil then
   		self.tableView:setPosition(cc.p(0, 0))
	    self.tableView:setAnchorPoint(cc.p(0, 0))
	    
	    self.tableView:setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL)
	   
	    self.tableView:setDelegate()
	    self.tableView:setDataSource()
	    self.tableView:setBounceable(true)
	    
	    self.tableView:registerScriptHandler(function(tbl, cell)
	    	if self.touchEnableFlag == false then
	    		return
	    	end
	    	self.touchEnableFlag = false

	    	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
	    	self:hideWorldArrow()

	    	--selected
	    	if self.selectedCell ~= nil then
	    		if self.selectedStageIdx == cell.idx then
	    			--start game
	    			self:startGame(self.stageData[cell.idx].stageId)
	    			return
	    		else
	    			--unselect cell
	    			self:clearSelectCell()
	    		end
	    	end

	    	if self.parent ~= nil then
	    		self.parent:HideRankInfo()
	    	end

	    	--selected cell
	    	if self.stageData[cell.idx].opened == false then
	    		self.touchEnableFlag = true
	    		return
	    	end

	    	self.selectedStageIdx = cell.idx
	    	self.selectedCell = cell

	    	if cell.selectedLight ~= nil then
	    		cell.selectedLight:setVisible(true)
	    	end
	    	if cell.selectedLight ~= nil then
	    		local curIsFin = (self.stageData[cell.idx].firstTime > 0)
    			if cell.selectedLightIsFin ~= curIsFin then
    				local tpFrame = nil
    				if curIsFin == true then
    					tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.stageSelectLightFinPic))
    				else
    					tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.stageSelectLightPic))
    				end
    				if tpFrame ~= nil then
    					cell.selectedLight:setSpriteFrame(tpFrame)
    				end
    				cell.selectedLightIsFin = curIsFin
    			end
    			cell.selectedLight:setVisible(true)
	    	end

	    	if cell.startLabel ~= nil then
	    		cell.startLabel:setString("start")
				cell.startLabel:setVisible(cell.idx ~= 1)
	    	end

	    	if cell.mainStageFlower ~= nil then
	    		if self.stageData[cell.idx].firstTime == 0 then
	    			local tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.stageStateResList.selected))
		    		if tpFrame ~= nil then
	    				cell.mainStageFlower:setSpriteFrame(tpFrame)
	    			end
	    			cell.isSelectedFlag = true
	    		end
	    	end

	    	if self.parent ~= nil then
	    		self.parent:requestRankInfo(self.stageData[cell.idx].stageId, function()
	    			self:hideWorldArrow()
	    			self.touchEnableFlag = true
	    		end)
	    	end
	    end, cc.TABLECELL_TOUCHED)
	    self.tableView:registerScriptHandler(function()
	    	return 80, viewSize.height
	    end, cc.TABLECELL_SIZE_FOR_INDEX)
	    self.tableView:registerScriptHandler(function()
     		return table.nums(self.stageData)
	    end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)

	    self.tableView:registerScriptHandler(function()
	    	--齿轮转动
	    	local nowX = self.tableView:getContentOffset().x
	    	if self.lastPosX ~= nil then
	    		local anger = 60
	    		if nowX < self.lastPosX then
	    			anger = -60
	    		end
		    	for i=1, #self.gearList do
		    		self.gearList[i]:setRotation(self.gearList[i]:getRotation()+anger)
		    	end
		    end
		    self.lastPosX = nowX


		    if #self.stageData <= pageStageCount then
		    	return
		    end

		    local offsetX = 30
		    local startPosX = 0
		    local endPosX = (pageStageCount-#self.stageData)*(viewSize.width/pageStageCount)
		    if nowX >= startPosX-offsetX then
		        if self.leftArrow ~= nil then
					self.leftArrow:setVisible(false)
				end
				if self.rightArrow ~= nil then
					self.rightArrow:setVisible(true)
				end
		    elseif nowX <= endPosX + offsetX then
		        if self.leftArrow ~= nil then
					self.leftArrow:setVisible(true)
				end
				if self.rightArrow ~= nil then
					self.rightArrow:setVisible(false)
				end
		    else
		    	if self.leftArrow ~= nil then
					self.leftArrow:setVisible(true)
				end
				if self.rightArrow ~= nil then
					self.rightArrow:setVisible(true)
				end
		    end
		    -- print("=======    ", endPosX, nowX)
	    end, cc.SCROLLVIEW_SCRIPT_SCROLL)

	    self.tableView:registerScriptHandler(function(tbl, idx)
			local keyIdx = idx + 1 
		    local cell = tbl:dequeueCell()
		    local isNewCell = false
		    if nil == cell then
		        cell = cc.TableViewCell:new()
		        isNewCell = true
		    end
		    
		    cell.idx = keyIdx

		    if isNewCell == true then
		    	cell.flowerpotPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.flowerpotPic)))
		    	if cell.flowerpotPic ~= nil then
		    		cell.flowerpotPic:setAnchorPoint(cc.p(0.5, 0))
		    		cell.flowerpotPic:setPosition(cc.p(40, 0))
		    		cell:addChild(cell.flowerpotPic, 5)
		    	end

		    	cell.mainStageFlower = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
		    	if cell.mainStageFlower ~= nil then
		    		cell.mainStageFlower:setAnchorPoint(cc.p(0.5, 0))
		    		cell.mainStageFlower:setPosition(cc.p(40, cell.flowerpotPic:getContentSize().height-1))
		    		cell:addChild(cell.mainStageFlower, 4)
		    	end

		    	cell.selectedLight = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.stageSelectLightPic)))
		    	if cell.selectedLight ~= nil then
		    		cell.selectedLightIsFin = false
		    		cell.selectedLight:setAnchorPoint(cc.p(0.5, 0))
		    		cell.selectedLight:setPosition(cc.p(40, 58))
		    		cell.selectedLight:setVisible(false)
		    		cell:addChild(cell.selectedLight, 3)
		    	end

		    	cell.startLabel = display.newTTFLabel({
			        text = "",
			        font = ResourceDef.FONT_GAME_MAIN,
			        size = 18,
			        color = cc.c3b(255,255,255),
			        align = cc.TEXT_ALIGNMENT_CENTER
			    })
			    if cell.startLabel ~= nil then
			    	cell.startLabel:setAnchorPoint(cc.p(0.5,0.5))
			    	cell.startLabel:setPosition(cc.p(40, 25))
			    	cell:addChild(cell.startLabel, 6)
			    end
		    else
		    	if self.selectedCell == cell then
		    		if self.selectedStageIdx ~= cell.idx then
		    			self.selectedCell = nil
		    		end
		    	end
		    end


		    if self.selectedStageIdx == cell.idx then
		    	self.selectedCell = cell
		    end

		    if self.stageData[keyIdx] ~= nil then
		    	local tpFrame = nil
		    	cell.isSelectedFlag = false
		    	if self.stageData[keyIdx].opened == false then
		    		tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.stageStateResList.disabled))
		    	elseif self.stageData[keyIdx].firstTime > 0 then
		    		tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.stageStateResList.finished))
		    	elseif self.selectedStageIdx == keyIdx then
		    		tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.stageStateResList.selected))
		    		cell.isSelectedFlag = true
		    	else
		    		tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.stageStateResList.normal))
		    	end
		    	if cell.mainStageFlower ~= nil then
		    		cell.mainStageFlower:stopAllActions()
	    			if tpFrame ~= nil then
	    				cell.mainStageFlower:setSpriteFrame(tpFrame)
	    			end
	    			if self.stageData[keyIdx].firstTime > 0 then
	    				cell.mainStageFlower:runAction(self.flowerShakeAni:clone())
	    			end
	    		end
		    end

		    if cell.flowerpotPic ~= nil then
		    	cell.flowerpotPic:setVisible(keyIdx ~= 1)
		    end
		    if cell.mainStageFlower ~= nil then
		    	cell.mainStageFlower:setVisible(keyIdx ~= 1)
		    end

	    	if cell.selectedLight ~= nil then
	    		if self.selectedStageIdx == keyIdx and keyIdx ~= 1 and self.stageData[keyIdx].opened == true then
	    			local curIsFin = (self.stageData[keyIdx].firstTime > 0)
	    			if cell.selectedLightIsFin ~= curIsFin then
	    				local tpFrame = nil
	    				if curIsFin == true then
	    					tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.stageSelectLightFinPic))
	    				else
	    					tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.stageSelectLightPic))
	    				end
	    				if tpFrame ~= nil then
	    					cell.selectedLight:setSpriteFrame(tpFrame)
	    				end
	    				cell.selectedLightIsFin = curIsFin
	    			end
	    			cell.selectedLight:setVisible(true)
	    		else
	    			cell.selectedLight:setVisible(false)
	    		end
	    	end

	    	if cell.startLabel ~= nil then
	    		if cell.selectedLight:isVisible() == true then
	    			cell.startLabel:setString("start")
	    		else
	    			cell.startLabel:setString(tostring(self.worldIdx) .. "-" .. tostring(cell.idx-1))
	    		end
	    		cell.startLabel:setVisible(cell.idx ~= 1)
	    	end
	    	

		    return cell

	    end, cc.TABLECELL_SIZE_AT_INDEX)

	    self.tableView:reloadData()

		--arrow
		if self.leftArrow ~= nil then
			self.leftArrow:setVisible(false)
		end
		if self.rightArrow ~= nil then
			self.rightArrow:setVisible(#self.stageData > pageStageCount)
		end
	end
end

function StageListViewLayer:hideWorldArrow()
	if self.parent ~= nil then
		if self.parent.parent ~= nil then
			if self.parent.parent.leftBtnNode ~= nil then
				self.parent.parent.leftBtnNode:setVisible(false)
			end
			if self.parent.parent.rightBtnNode ~= nil then
				self.parent.parent.rightBtnNode:setVisible(false)
			end
		end
	end
end

function StageListViewLayer:clearSelectCell()
	if self.selectedCell == nil then
		return
	end

	if self.selectedCell.selectedLight ~= nil then
		self.selectedCell.selectedLight:setVisible(false)
	end
	if self.selectedCell.startLabel ~= nil then
		self.selectedCell.startLabel:setString(tostring(self.worldIdx) .. "-" .. tostring(self.selectedCell.idx-1))
		self.selectedCell.startLabel:setVisible(self.selectedCell.idx ~= 1)
	end

	if self.selectedCell.isSelectedFlag == true then
		if self.selectedCell.mainStageFlower ~= nil then
			local tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.stageStateResList.normal))
    		if tpFrame ~= nil then
				self.selectedCell.mainStageFlower:setSpriteFrame(tpFrame)
			end
    	end
    	self.selectedCell.isSelectedFlag = false
	end

	self.selectedCell = nil
	self.selectedStageIdx = 0
end

function StageListViewLayer:startGame(stageId)
	-- print("----- start game: ", stageId)
	local curScene = display.getRunningScene()
	if curScene ~= nil then
		curScene:UITransition(function()
			curScene:enterGame(stageId)
		end)
	end
end

return StageListViewLayer
