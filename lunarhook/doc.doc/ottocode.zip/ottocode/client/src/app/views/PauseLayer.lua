local GameControlButton = import("app.views.GameControlButton")

local PauseLayer = class("PauseLayer",function()
	return display.newNode()
end)

function PauseLayer:ctor(parent)
	self.parent = parent
	self:initUI()
end

function PauseLayer:initUI()
	--black bg
	local bgColorLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 150), display.width, display.height)
	if bgColorLayer ~= nil then
		bgColorLayer:setAnchorPoint(cc.p(0, 0))
		bgColorLayer:setPosition(cc.p(0, 0))
		self:addChild(bgColorLayer, 1)
	end
	local bgCoverBtn = GameControlButton.new({
        btnBg = ResourceDef.IMAGE_TRANSPARENT,
        dstSize = {width=display.width, height=display.height},
        callback = function ()
        end
    })
    if bgCoverBtn ~= nil then
		bgCoverBtn:setAnchorPoint(cc.p(0.5, 0.5))
		bgCoverBtn:setPosition(cc.p(display.cx, display.cy))
	    self:addChild(bgCoverBtn, 2)
	end

	local titleBg = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.GAME_PAUSE_TITLE_BG)))
	if titleBg ~= nil then
		titleBg:setAnchorPoint(cc.p(0.5, 0.5))
		titleBg:setPosition(cc.p(display.cx, display.cy+350))
		self:addChild(titleBg, 10)

		-- title icon
		local titleIcon = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.GAME_TITLE_ICON_STAGE)))
		if titleIcon ~= nil then
			titleIcon:setAnchorPoint(cc.p(0.5, 0.5))
			titleIcon:setPosition(cc.p(titleBg:getPositionX()-50, titleBg:getPositionY()-10))
			self:addChild(titleIcon, 15)
		end

		-- title label
		self.titleLabel = display.newTTFLabel({
	        text = "",
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 30,
	        color = cc.c3b(90, 45, 3),
	        align = cc.TEXT_ALIGNMENT_CENTER
	    })
	    if self.titleLabel ~= nil then
	        self.titleLabel:setAnchorPoint(cc.p(0.5, 0.5))
	        self.titleLabel:setPosition(cc.p(titleBg:getPositionX()+30, titleBg:getPositionY()-10))
	        self:addChild(self.titleLabel, 15)
	    end
	end

	for i=1, 2 do
		local ganPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.PANEL_CONNECT_POLE3)))
		if ganPic ~= nil then
			ganPic:setAnchorPoint(cc.p(0.5, 0.5))
			ganPic:setPosition(cc.p(display.cx+math.pow((-1), i)*175, display.cy+350-55))
			self:addChild(ganPic, 12)
		end
	end

	local panelBg = cc.LayerColor:create(cc.c4b(132, 84, 12, 255), 400, 580)
	if panelBg ~= nil then
		panelBg:setAnchorPoint(cc.p(0, 0))
		panelBg:setPosition(cc.p(display.cx-200, display.cy-290-20))
		self:addChild(panelBg, 10)
	end


	local labelOffsetX = display.cx-100

	--control labels
	local controlLabel = display.newTTFLabel({
        text = LangStringDefine.CONTROL_LABEL,
        font = ResourceDef.FONT_GAME_MAIN,
        size = 30,
        color = cc.c3b(248, 201, 131),
        align = cc.TEXT_ALIGNMENT_CENTER
    })
    if controlLabel ~= nil then
        controlLabel:setAnchorPoint(cc.p(0.5, 0.5))
        controlLabel:setPosition(cc.p(labelOffsetX-50, display.cy+180))
        self:addChild(controlLabel, 15)
    end

    local controlSwitch = import("app.views.SwitchNode").new(self)
    if controlSwitch ~= nil then
    	local retFlag = true
    	if UserDataManager.PLAYER_SETTINGS.controlmode == "button" then
    		retFlag = false
    	end
    	controlSwitch:resetLayer({
    		showLeft = retFlag,
    		leftPic = ResourceDef.CONTROL_ICON_SLIDE,
    		rightPic = ResourceDef.CONTROL_ICON_PRESS,
    		leftStateLabel = LangStringDefine.CONTROL_LABEL_SLIDE,
    		rightStateLabel = LangStringDefine.CONTROL_LABEL_PRESS,
    		func = function(ret)
    			if ret == true then
    				UserDataManager.PLAYER_SETTINGS.controlmode = "slide"
    				if self.parent ~= nil and self.parent.controlNode ~= nil then
    					self.parent.controlNode:changeControlMode(1)
    				end
    			else
    				UserDataManager.PLAYER_SETTINGS.controlmode = "button"
    				if self.parent ~= nil and self.parent.controlNode ~= nil then
    					self.parent.controlNode:changeControlMode(2)
    				end 
    			end
    			UserDataManager.savePlayerSettings()
    			UserDataManager.refreshPlayerSetting()
    		end
    	})
    	controlSwitch:setPosition(cc.p(labelOffsetX+130, display.cy+180))
    	self:addChild(controlSwitch, 15)
    end

	--sound
	local soundLabel1 = display.newTTFLabel({
        text = LangStringDefine.SOUND_MUSIC_LABEL,
        font = ResourceDef.FONT_GAME_MAIN,
        size = 30,
        color = cc.c3b(248, 201, 131),
        align = cc.TEXT_ALIGNMENT_CENTER
    })
    if soundLabel1 ~= nil then
        soundLabel1:setAnchorPoint(cc.p(0.5, 0.5))
        soundLabel1:setPosition(cc.p(labelOffsetX-50, display.cy+80))
        self:addChild(soundLabel1, 15)
    end
    local soundMusicSwitch = import("app.views.SwitchNode").new(self)
    if soundMusicSwitch ~= nil then
    	local retFlag = true
    	if UserDataManager.PLAYER_SETTINGS.soundmusiconoff == "off" then
    		retFlag = false
    	end
    	soundMusicSwitch:resetLayer({
    		showLeft = retFlag,
    		leftPic = ResourceDef.SOUND_MUSIC_ON,
    		rightPic = ResourceDef.SOUND_MUSIC_OFF,
    		leftStateLabel = LangStringDefine.CONTROL_LABEL_OPEN,
    		rightStateLabel = LangStringDefine.CONTROL_LABEL_CLOSE,
    		func = function(ret)
    			if ret == true then
    				UserDataManager.PLAYER_SETTINGS.soundmusiconoff = "on"
    			else
    				UserDataManager.PLAYER_SETTINGS.soundmusiconoff = "off"
    			end
    			UserDataManager.savePlayerSettings()
    			UserDataManager.refreshPlayerSetting()
    		end
    	})
    	soundMusicSwitch:setPosition(cc.p(labelOffsetX+130, display.cy+80))
    	self:addChild(soundMusicSwitch, 15)
    end

    local soundLabel2 = display.newTTFLabel({
        text = LangStringDefine.SOUND_EFFECT_LABEL,
        font = ResourceDef.FONT_GAME_MAIN,
        size = 30,
        color = cc.c3b(248, 201, 131),
        align = cc.TEXT_ALIGNMENT_CENTER
    })
    if soundLabel2 ~= nil then
        soundLabel2:setAnchorPoint(cc.p(0.5, 0.5))
        soundLabel2:setPosition(cc.p(labelOffsetX-50, display.cy-20))
        self:addChild(soundLabel2, 15)
    end
    local soundEffectSwitch = import("app.views.SwitchNode").new(self)
    if soundEffectSwitch ~= nil then
    	local retFlag = true
    	if UserDataManager.PLAYER_SETTINGS.soundeffectonoff == "off" then
    		retFlag = false
    	end
    	soundEffectSwitch:resetLayer({
    		showLeft = retFlag,
    		leftPic = ResourceDef.SOUND_EFFECT_ON,
    		rightPic = ResourceDef.SOUND_EFFECT_OFF,
    		leftStateLabel = LangStringDefine.CONTROL_LABEL_OPEN,
    		rightStateLabel = LangStringDefine.CONTROL_LABEL_CLOSE,
    		func = function(ret)
    			if ret == true then
    				UserDataManager.PLAYER_SETTINGS.soundeffectonoff = "on"
    			else
    				UserDataManager.PLAYER_SETTINGS.soundeffectonoff = "off"
    			end
    			UserDataManager.savePlayerSettings()
    			UserDataManager.refreshPlayerSetting()
    		end
    	})
    	soundEffectSwitch:setPosition(cc.p(labelOffsetX+130, display.cy-20))
    	self:addChild(soundEffectSwitch, 15)
    end

	--seperate line
	local bgColorLayer = cc.LayerColor:create(cc.c4b(161, 86, 13, 255), 370, 2)
	if bgColorLayer ~= nil then
		bgColorLayer:setPosition(cc.p(display.cx-370/2, display.cy-120))
		self:addChild(bgColorLayer, 16)
	end

	--retry button
	self.buttonRetry = GameControlButton.new({
        btnBg = ResourceDef.COMMON_BUTTON_RES_RETRY,
        dstSize = {width=96, height=96},
        callback = function ()
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
        	self:gameRetry()
        end
    })
    if self.buttonRetry ~= nil then
		self.buttonRetry:setAnchorPoint(cc.p(0.5, 0.5))
		self.buttonRetry:setPosition(cc.p(display.cx-120, display.cy-220))
	    self:addChild(self.buttonRetry, 15)
	end

	local retryBtnLabel = display.newTTFLabel({
        text = LangStringDefine.BUTTON_LABEL_DESC_RETYR,
        font = ResourceDef.FONT_GAME_MAIN,
        size = 24,
        color = cc.c3b(248, 201, 131),
        align = cc.TEXT_ALIGNMENT_CENTER
    })
    if retryBtnLabel ~= nil then
        retryBtnLabel:setAnchorPoint(cc.p(0.5, 0.5))
        retryBtnLabel:setPosition(cc.p(self.buttonRetry:getPositionX(), self.buttonRetry:getPositionY()+96/2+20))
        self:addChild(retryBtnLabel, 15)
    end 

	--return list button
	self.buttonReturnWorld = GameControlButton.new({
        btnBg = ResourceDef.COMMON_BUTTON_RES_RETURN_LIST,
        dstSize = {width=96, height=96},
        callback = function ()
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
        	self:returnWorld()
        end
    })
    if self.buttonReturnWorld ~= nil then
		self.buttonReturnWorld:setAnchorPoint(cc.p(0.5, 0.5))
		self.buttonReturnWorld:setPosition(cc.p(display.cx, display.cy-220))
	    self:addChild(self.buttonReturnWorld, 15)
	end

	local returnBtnLabel = display.newTTFLabel({
        text = LangStringDefine.BUTTON_LABEL_DESC_RETURN,
        font = ResourceDef.FONT_GAME_MAIN,
        size = 24,
        color = cc.c3b(248, 201, 131),
        align = cc.TEXT_ALIGNMENT_CENTER
    })
    if returnBtnLabel ~= nil then
        returnBtnLabel:setAnchorPoint(cc.p(0.5, 0.5))
        returnBtnLabel:setPosition(cc.p(self.buttonReturnWorld:getPositionX(), self.buttonReturnWorld:getPositionY()+96/2+20))
        self:addChild(returnBtnLabel, 15)
    end 

	--continue button
	self.buttonContinue = GameControlButton.new({
        btnBg = ResourceDef.COMMON_BUTTON_RES_CONTINUE,
        dstSize = {width=96, height=96},
        callback = function ()
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
        	self:continueGame()
        end
    })
    if self.buttonContinue ~= nil then
		self.buttonContinue:setAnchorPoint(cc.p(0.5, 0.5))
		self.buttonContinue:setPosition(cc.p(display.cx+120, display.cy-220))
	    self:addChild(self.buttonContinue, 15)
	end

	local continueBtnLabel = display.newTTFLabel({
        text = LangStringDefine.BUTTON_LABEL_DESC_CONTINUE,
        font = ResourceDef.FONT_GAME_MAIN,
        size = 24,
        color = cc.c3b(248, 201, 131),
        align = cc.TEXT_ALIGNMENT_CENTER
    })
    if continueBtnLabel ~= nil then
        continueBtnLabel:setAnchorPoint(cc.p(0.5, 0.5))
        continueBtnLabel:setPosition(cc.p(self.buttonContinue:getPositionX(), self.buttonContinue:getPositionY()+96/2+20))
        self:addChild(continueBtnLabel, 15)
    end 


    local gameDescBg1 = cc.LayerColor:create(cc.c4b(174,138,90, 255), display.width, 250)
	if gameDescBg1 ~= nil then
		gameDescBg1:setAnchorPoint(cc.p(0, 0))
		gameDescBg1:setPosition(cc.p(0, 0))
		self:addChild(gameDescBg1, 10)
	end
	local gameDescBg2 = cc.LayerColor:create(cc.c4b(250,210,152, 255), display.width-10, 250-10)
	if gameDescBg2 ~= nil then
		gameDescBg2:setAnchorPoint(cc.p(0, 0))
		gameDescBg2:setPosition(cc.p(5, 5))
		self:addChild(gameDescBg2, 10)
	end

	local descWordPosYList = {
		80, 10, -70
	}
	for i=1, #descWordPosYList do
		local tpStr = LangStringDefine.GAME_DESC_STRING_LIST[i] or ""
		if i ~= 1 then
			tpStr = "        " .. tpStr
		end
		local gameDesc = display.newTTFLabel({
	        text = tpStr,
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 24,
	        color = cc.c3b(98, 54, 11),
	        align = cc.TEXT_ALIGNMENT_LEFT, -- 文字内部左对齐
		    valign = cc.VERTICAL_TEXT_ALIGNMENT_CENTER,
	        dimensions = cc.size(display.width-100, 250)
	    })
	    if gameDesc ~= nil then
	    	gameDesc:setLineHeight(30)
	        gameDesc:setAnchorPoint(cc.p(0, 0))
	        gameDesc:setPosition(cc.p(50, descWordPosYList[i]))
	        self:addChild(gameDesc, 15)
	    end
	end
	
end

function PauseLayer:resetLayer(id)
	if id ~= nil and id > 0 then
		if self.titleLabel ~= nil then
			local stageInfo = ConfigManager.stageTbl[tostring(id)]
			if stageInfo ~= nil then
				self.titleLabel:setString(stageInfo.worldId .. "-" .. stageInfo.stageIndex)
			else
				self.titleLabel:setString(id)
			end
		end
	elseif self.parent.isTest == true then
		if self.titleLabel ~= nil then
			self.titleLabel:setString(LangStringDefine.PLAYER_MADE_MAP)
		end
	end

	if self.buttonRetry ~= nil then
		self.buttonRetry:setVisible(self.parent.isTest == false)
	end
end

function PauseLayer:gameRetry()
	cc.Director:getInstance():resume()

	if self.parent == nil then
		return
	end
	if self.parent.stageId == nil or self.parent.isShopMap == nil or self.parent.mapNode == nil then
		return
	end
	self.parent.mapNode.stopUpdateFlag = true

	local curScene = display.getRunningScene()
	if curScene ~= nil then
		curScene:UITransition(function()
			self:closeLayer()
			curScene:enterGame(self.parent.stageId, self.parent.isShopMap)
		end)
	end
end

function PauseLayer:continueGame()
	cc.Director:getInstance():resume()
	self:closeLayer()
end

function PauseLayer:returnWorld()
	cc.Director:getInstance():resume()

	if self.parent == nil then
		return
	end
	if self.parent.stageId == nil or self.parent.isShopMap == nil or self.parent.mapNode == nil then
		return
	end
	self.parent.mapNode.stopUpdateFlag = true

	local curScene = display.getRunningScene()
	if curScene ~= nil then
		curScene:UITransition(function()
			self:closeLayer()
			if self.parent.isShopMap == true then
				curScene:openShop("bought")
				if UserDataManager.TMP_VALUE ~= nil then
					if curScene.ShopLayer ~= nil and curScene.ShopLayer.tableView ~= nil then
						curScene.ShopLayer.tableView:setContentOffset(UserDataManager.TMP_VALUE)
					end
					UserDataManager.TMP_VALUE = nil
				end
				AudioManager.stopBackgroundMusic(false)
				AudioManager.playBackgroundMusic(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.shopBgMusic), true)
			elseif self.parent.isTest == true then
				curScene:openEditor()
				if UserDataManager.TMP_VALUE ~= nil then
					if curScene.StageEditLayer ~= nil and curScene.StageEditLayer.myMakeListView ~= nil then
						curScene.StageEditLayer:openMyMakeList()
						curScene.StageEditLayer.myMakeListView:setContentOffset(UserDataManager.TMP_VALUE)
					end
					UserDataManager.TMP_VALUE = nil
				end
				AudioManager.stopBackgroundMusic(false)
				AudioManager.playBackgroundMusic(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.shopBgMusic), true)
			else
				local worldIdx = nil
				if self.parent.stageId ~= nil then
					worldIdx = math.floor(self.parent.stageId/100)
				end
				curScene:returnStageSelectLayer(worldIdx)
				AudioManager.stopBackgroundMusic(false)
				AudioManager.playBackgroundMusic(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.mainBGMusic), true)
			end
		end)
	end
end

function PauseLayer:openLayer()
	self:setVisible(true)
end

function PauseLayer:closeLayer()
	self:setVisible(false)
end

return PauseLayer
