

local RankDetailLayer = class("RankDetailLayer",function()
	return display.newNode()
end )

function RankDetailLayer:ctor()
	
	self:init()
end

function RankDetailLayer:init()
	
	self.worldRankBgPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.RANK_LIST_MAIN_BG)))
	if self.worldRankBgPic ~= nil then
		self.worldRankBgPic:setAnchorPoint(cc.p(0.5, 0.5))
		self.worldRankBgPic:setPosition(cc.p(-110, 0))
		self:addChild(self.worldRankBgPic, 1)
	end
	self.myBestRecordBgPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MY_BEST_RECORD_BG)))
	if self.myBestRecordBgPic ~= nil then
		self.myBestRecordBgPic:setAnchorPoint(cc.p(0.5, 0.5))
		self.myBestRecordBgPic:setPosition(cc.p(150, 50))
		self:addChild(self.myBestRecordBgPic, 1)
	end

	local titleSideFlower1 = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.RANK_TITLE_SMALL_FLOWER_PIC)))
	if titleSideFlower1 ~= nil then
		titleSideFlower1:setAnchorPoint(cc.p(0.5, 0.5))
		titleSideFlower1:setPosition(cc.p(-205, 100))
		self:addChild(titleSideFlower1, 5)
		titleSideFlower1:runAction(cc.RepeatForever:create(cc.RotateBy:create(0.8, 360)))
	end
	local titleSideFlower2 = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.RANK_TITLE_SMALL_FLOWER_PIC)))
	if titleSideFlower2 ~= nil then
		titleSideFlower2:setAnchorPoint(cc.p(0.5, 0.5))
		titleSideFlower2:setPosition(cc.p(78, 110))
		self:addChild(titleSideFlower2, 5)
		titleSideFlower2:runAction(cc.RepeatForever:create(cc.RotateBy:create(0.8, 360)))
	end

	local playerRankLabelPosList = {
		{nameX=-190, nameY=48, nameFontSize=20, nameFontColor=cc.c3b(0,0,0), stepX=-60, stepY=48, stepFontSize=20, stepFontColor=cc.c3b(0,0,0)},
		{nameX=-190, nameY=-5, nameFontSize=20, nameFontColor=cc.c3b(0,0,0), stepX=-60, stepY=-5, stepFontSize=20, stepFontColor=cc.c3b(0,0,0)},
		{nameX=-190, nameY=-55, nameFontSize=20, nameFontColor=cc.c3b(0,0,0), stepX=-60, stepY=-55, stepFontSize=20, stepFontColor=cc.c3b(0,0,0)},
	}

	self.rankPlayerNameList = {}
	self.rankPlayerStepList = {}
	for i=1, #playerRankLabelPosList do
		self.rankPlayerNameList[i] = display.newTTFLabel({
	        text = "",
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = playerRankLabelPosList[i].nameFontSize,
	        color = playerRankLabelPosList[i].nameFontColor,
	        align = cc.TEXT_ALIGNMENT_CENTER
	    })
	    if self.rankPlayerNameList[i] ~= nil then
	    	self.rankPlayerNameList[i]:setAnchorPoint(cc.p(0,0.5))
	    	self.rankPlayerNameList[i]:setPosition(cc.p(playerRankLabelPosList[i].nameX, playerRankLabelPosList[i].nameY))
	    	self:addChild(self.rankPlayerNameList[i], 10)
	    end

	    self.rankPlayerStepList[i] = display.newTTFLabel({
	        text = "",
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = playerRankLabelPosList[i].stepFontSize,
	        color = playerRankLabelPosList[i].stepFontColor,
	        align = cc.TEXT_ALIGNMENT_CENTER
	    })
	    if self.rankPlayerStepList[i] ~= nil then
	    	self.rankPlayerStepList[i]:setAnchorPoint(cc.p(0,0.5))
	    	self.rankPlayerStepList[i]:setPosition(cc.p(playerRankLabelPosList[i].stepX, playerRankLabelPosList[i].stepY))
	    	self:addChild(self.rankPlayerStepList[i], 10)
	    end
	end

	self.myRank = display.newTTFLabel({
        text = "",
        font = ResourceDef.FONT_GAME_MAIN,
        size = 24,
        color = cc.c3b(0,0,0),
        align = cc.TEXT_ALIGNMENT_CENTER
    })
    if self.myRank ~= nil then
    	self.myRank:setAnchorPoint(cc.p(0,0.5))
    	self.myRank:setPosition(cc.p(-80, -142))
    	self:addChild(self.myRank, 10)
    end

    self.myBestStep = display.newTTFLabel({
        text = "",
        font = ResourceDef.FONT_GAME_MAIN,
        size = 20,
        color = cc.c3b(0,0,0),
        align = cc.TEXT_ALIGNMENT_CENTER
    })
    if self.myBestStep ~= nil then
    	self.myBestStep:setAnchorPoint(cc.p(0,0.5))
    	self.myBestStep:setPosition(cc.p(168, 8))
    	self:addChild(self.myBestStep, 10)
    end

    self.myRecordTime = display.newTTFLabel({
        text = "",
        font = ResourceDef.FONT_GAME_MAIN,
        size = 20,
        color = cc.c3b(0,0,0),
        align = cc.TEXT_ALIGNMENT_CENTER
    })
    if self.myRecordTime ~= nil then
    	self.myRecordTime:setAnchorPoint(cc.p(0,0.5))
    	self.myRecordTime:setPosition(cc.p(168, 53))
    	self:addChild(self.myRecordTime, 10)
    end

end

function RankDetailLayer:setRankInfo(rankInfo)
	-- rankInfo = {
	-- 	myRank = 1,
	-- 	myRecordTime = "11111",
	-- 	myBestStep = "",
	-- 	stageRank = {
	-- 		{name="xxx", steps=5},
	-- 		{name="xxx", steps=5},
	-- 		{name="xxx", steps=5},
	-- 	}
	-- }

	self:reset()

	if rankInfo == nil then
		return
	end

	if self.myRank ~= nil then
		if rankInfo.myRank ~= nil and rankInfo.myRank > 0 then
			self.myRank:setString(rankInfo.myRank)
		else
			self.myRank:setString(LangStringDefine.NO_RANK_VALUE)
		end
	end

	if self.myRecordTime ~= nil then
		if rankInfo.myRecordTime ~= nil and rankInfo.myRecordTime ~= "" then
			local tmpVal = tonumber(rankInfo.myRecordTime)
			local useDays = math.floor(tmpVal/86400)
			tmpVal = tmpVal - useDays*86400
			local useHours = math.floor(tmpVal/3600)
			tmpVal = tmpVal - useHours*3600
			local useMinutes = math.floor(tmpVal/60)
			local useSeconds = tmpVal - useMinutes*60

			local showStr = tostring(useSeconds) .. LangStringDefine.STR_SECOND
			if useMinutes > 0 then
				showStr = tostring(useMinutes) .. LangStringDefine.STR_MINUTE .. showStr
			end
			if useHours > 0 then
				showStr = tostring(useHours) .. LangStringDefine.STR_HOUR .. showStr
			end
			if useDays > 0 then
				showStr = tostring(useDays) .. LangStringDefine.STR_DAY2 .. showStr
			end

			self.myRecordTime:setString(showStr)
		end
	end

	if self.myBestStep ~= nil then
		if rankInfo.myBestStep ~= nil and rankInfo.myBestStep ~= "" then
			self.myBestStep:setString(rankInfo.myBestStep)
		end
	end

	if rankInfo.stageRank ~= nil and type(rankInfo.stageRank) == "table" then
		for i=1, #rankInfo.stageRank do
			if self.rankPlayerNameList[i] ~= nil and rankInfo.stageRank[i].name ~= nil then
				self.rankPlayerNameList[i]:setString(rankInfo.stageRank[i].name)
			end

			if self.rankPlayerStepList[i] ~= nil and rankInfo.stageRank[i].steps ~= nil then
				self.rankPlayerStepList[i]:setString(rankInfo.stageRank[i].steps)
			end
		end
	end
end

function RankDetailLayer:reset()
	if self.myRank ~= nil then
		self.myRank:setString("")
	end

	if self.myBestStep ~= nil then
		self.myBestStep:setString("")
	end

	if self.myRecordTime ~= nil then
		self.myRecordTime:setString(showStr)
	end

	for i=1, 3 do
		if self.rankPlayerNameList[i] ~= nil then
			self.rankPlayerNameList[i]:setString("")
		end
		if self.rankPlayerStepList[i] ~= nil then
			self.rankPlayerStepList[i]:setString("")
		end
	end
end

return RankDetailLayer
