local GameControlButton = import("app.views.GameControlButton")
local WorldLayer = class("WorldLayer", BaseLayer)

function WorldLayer:ctor(worldIdx, parent)
	WorldLayer.super.ctor(self)

	self.worldIdx = worldIdx
	self.parent = parent

	self:initUI()
end

function WorldLayer:initUI()
	--ground hill
	local groundHill = cc.LayerColor:create(ResourceDef.STAGE_SELECT_CONTENT.worldGroundMainColorList[self.worldIdx], display.width+300, display.height/2)
	if groundHill ~= nil then
		groundHill:setAnchorPoint(cc.p(0, 0))
		groundHill:setPosition(cc.p(0-150, 0-display.height/4))
		self:addChild(groundHill, 30)
	end

	--hillSide
	local hillRightSide = cc.LayerColor:create(ResourceDef.STAGE_SELECT_CONTENT.worldGroundMainColorList[self.worldIdx], 150, 400)
	if hillRightSide ~= nil then
		hillRightSide:setAnchorPoint(cc.p(0, 0))
		hillRightSide:setRotation(30)
		hillRightSide:setPosition(cc.p(display.width-60, -60))
		self:addChild(hillRightSide, 31)
	end
	local hillLeftSide = cc.LayerColor:create(ResourceDef.STAGE_SELECT_CONTENT.worldGroundMainColorList[self.worldIdx], 150, 400)
	if hillLeftSide ~= nil then
		hillLeftSide:setAnchorPoint(cc.p(0, 0))
		hillLeftSide:setRotation(-30)
		hillLeftSide:setPosition(cc.p(-70, -140))
		self:addChild(hillLeftSide, 31)
	end


	--mountain top
	self.mountainTopPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.worldMountainResList[self.worldIdx])))
	if self.mountainTopPic ~= nil then
		self.mountainTopPic:setAnchorPoint(cc.p(0.5,0.5))
		self.mountainTopPic:setPosition(cc.p(display.cx, display.height/4+100))
		self:addChild(self.mountainTopPic, 25)
	end

	--ground shading
	local groundShadingPosList = {
		{
			{x=display.cx-300, y=display.height/4.5, resIdx=1, scale=0.55, opacity=255},
			{x=display.cx-220, y=display.height/3.3, resIdx=2, scale=0.8, opacity=255},
			{x=display.cx-100, y=display.height/2.8, resIdx=3, scale=0.4, opacity=200},
			{x=display.cx-50, y=display.height/3.5, resIdx=2, scale=0.7, opacity=255},
			{x=display.cx+50, y=display.height/12, resIdx=1, scale=0.6, opacity=255},
			{x=display.cx+100, y=display.height/7, resIdx=3, scale=0.4, opacity=255},
			{x=display.cx+200, y=display.height/4.7, resIdx=2, scale=0.6, opacity=255},
			{x=display.cx+300, y=display.height/10, resIdx=3, scale=0.9, opacity=200},
			{x=display.cx-280, y=display.height/14, resIdx=2, scale=0.8, opacity=255},
			{x=display.cx-150, y=display.height/9, resIdx=3, scale=0.6, opacity=255},
			{x=display.cx+150, y=display.height/3.4, resIdx=1, scale=0.4, opacity=255},
			{x=display.cx+20, y=display.height/2.7, resIdx=2, scale=0.3, opacity=200},
			{x=display.cx+50, y=display.height/12, resIdx=1, scale=0.6, opacity=255},
			{x=display.cx+280, y=display.height/3.6, resIdx=2, scale=0.4, opacity=255},
		},
		{
			{x=display.cx-300, y=display.height/4.5, resIdx=4, scale=0.55, opacity=255},
			{x=display.cx-220, y=display.height/3.3, resIdx=5, scale=0.8, opacity=255},
			{x=display.cx-100, y=display.height/2.8, resIdx=6, scale=0.4, opacity=200},
			{x=display.cx-50, y=display.height/3.5, resIdx=5, scale=0.7, opacity=255},
			{x=display.cx+50, y=display.height/12, resIdx=4, scale=0.6, opacity=255},
			{x=display.cx+100, y=display.height/7, resIdx=6, scale=0.4, opacity=255},
			{x=display.cx+200, y=display.height/4.7, resIdx=5, scale=0.6, opacity=255},
			{x=display.cx+300, y=display.height/10, resIdx=6, scale=0.9, opacity=200},
			{x=display.cx-280, y=display.height/14, resIdx=5, scale=0.8, opacity=255},
			{x=display.cx-150, y=display.height/9, resIdx=6, scale=0.6, opacity=255},
			{x=display.cx+150, y=display.height/3.4, resIdx=4, scale=0.4, opacity=255},
			{x=display.cx+20, y=display.height/2.7, resIdx=5, scale=0.3, opacity=200},
			{x=display.cx+50, y=display.height/12, resIdx=4, scale=0.6, opacity=255},
			{x=display.cx+280, y=display.height/3.6, resIdx=5, scale=0.4, opacity=255},
		},
		{
			{x=display.cx-300, y=display.height/4.5, resIdx=7, scale=0.55, opacity=255},
			{x=display.cx-220, y=display.height/3.3, resIdx=8, scale=0.8, opacity=255},
			{x=display.cx-100, y=display.height/2.8, resIdx=9, scale=0.4, opacity=200},
			{x=display.cx-50, y=display.height/3.5, resIdx=8, scale=0.7, opacity=255},
			{x=display.cx+50, y=display.height/12, resIdx=7, scale=0.6, opacity=255},
			{x=display.cx+100, y=display.height/7, resIdx=9, scale=0.4, opacity=255},
			{x=display.cx+200, y=display.height/4.7, resIdx=8, scale=0.6, opacity=255},
			{x=display.cx+300, y=display.height/10, resIdx=9, scale=0.9, opacity=200},
			{x=display.cx-280, y=display.height/14, resIdx=8, scale=0.8, opacity=255},
			{x=display.cx-150, y=display.height/9, resIdx=9, scale=0.6, opacity=255},
			{x=display.cx+150, y=display.height/3.4, resIdx=7, scale=0.4, opacity=255},
			{x=display.cx+20, y=display.height/2.7, resIdx=8, scale=0.3, opacity=200},
			{x=display.cx+50, y=display.height/12, resIdx=7, scale=0.6, opacity=255},
			{x=display.cx+280, y=display.height/3.6, resIdx=8, scale=0.4, opacity=255},
		},
	}
	if groundShadingPosList[self.worldIdx] ~= nil then
		for i=1, #groundShadingPosList[self.worldIdx] do
			local groundShadingPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.groundShadingResList[groundShadingPosList[self.worldIdx][i].resIdx])))
			if groundShadingPic ~= nil then
				groundShadingPic:setAnchorPoint(cc.p(0.5, 0.5))
				groundShadingPic:setPosition(cc.p(groundShadingPosList[self.worldIdx][i].x, groundShadingPosList[self.worldIdx][i].y))
				groundShadingPic:setOpacity(groundShadingPosList[self.worldIdx][i].opacity)
				groundShadingPic:setScale(groundShadingPosList[self.worldIdx][i].scale)
				self:addChild(groundShadingPic, 35)
			end
		end
	end

	--bg move flower
	local allBgWorldSceneResParamList = {
		{
			{x=display.cx-150, y=display.height/4+150, rotation=-20, scaleX=0.8, scaleY=0.8, rotateSpeed=5, rotateAnger=5, resIdx=1, zorder=20},
			{x=display.cx-120, y=display.height/4+180, rotation=-10, scaleX=0.8, scaleY=0.9, rotateSpeed=2, rotateAnger=3, resIdx=2, zorder=20},
			{x=display.cx+50, y=display.height/4+120, rotation=-5, scaleX=0.7, scaleY=1.2, rotateSpeed=5, rotateAnger=5, resIdx=1, zorder=20},
			{x=display.cx+150, y=display.height/4+100, rotation=30, scaleX=1.0, scaleY=0.8, rotateSpeed=2, rotateAnger=3, resIdx=2, zorder=20},
			{x=display.cx+180, y=display.height/4+95, rotation=0, scaleX=1.0, scaleY=1.0, rotateSpeed=7, rotateAnger=5, resIdx=3, zorder=28},
			{x=display.cx+120, y=display.height/4+95, rotation=-5, scaleX=0.8, scaleY=1.0, rotateSpeed=10, rotateAnger=3, resIdx=4, zorder=28},
			{x=display.cx-120, y=display.height/4+110, rotation=5, scaleX=-0.5, scaleY=0.6, rotateSpeed=10, rotateAnger=3, resIdx=4, zorder=28},
		},
		{
			{x=display.cx+80, y=display.height/4+135, rotation=0, scaleX=1.0, scaleY=1.0, rotateSpeed=0, rotateAnger=0, resIdx=5, zorder=22},
			{x=display.cx-100, y=display.height/4+300, rotation=0, scaleX=1, scaleY=1, rotateSpeed=0, rotateAnger=0, resIdx=9, zorder=21},
			{x=display.cx-20, y=display.height/4+255, rotation=0, scaleX=0.9, scaleY=0.9, rotateSpeed=0, rotateAnger=0, resIdx=8, zorder=19},
			{x=display.cx-30, y=display.height/4+330, rotation=0, scaleX=0.8, scaleY=0.8, rotateSpeed=0, rotateAnger=0, resIdx=9, zorder=20},
			{x=display.cx+50, y=display.height/4+310, rotation=0, scaleX=1, scaleY=1, rotateSpeed=0, rotateAnger=0, resIdx=7, zorder=18},
			{x=display.cx+35, y=display.height/4+400, rotation=0, scaleX=1, scaleY=1, rotateSpeed=0, rotateAnger=0, resIdx=10, zorder=21},
			{x=display.cx+77, y=display.height/4+475, rotation=0, scaleX=0.6, scaleY=0.6, rotateSpeed=0, rotateAnger=0, resIdx=7, zorder=20},
			{x=display.cx+57, y=display.height/4+510, rotation=0, scaleX=0.7, scaleY=0.7, rotateSpeed=0, rotateAnger=0, resIdx=11, zorder=19},
			{x=display.cx+105, y=display.height/4+430, rotation=0, scaleX=0.75, scaleY=0.75, rotateSpeed=0, rotateAnger=0, resIdx=6, zorder=22},
			{x=display.cx+150, y=display.height/4+335, rotation=0, scaleX=1, scaleY=1, rotateSpeed=0, rotateAnger=0, resIdx=10, zorder=21},
			{x=display.cx+170, y=display.height/4+270, rotation=0, scaleX=1, scaleY=1, rotateSpeed=0, rotateAnger=0, resIdx=6, zorder=20},
			{x=display.cx+240, y=display.height/4+240, rotation=0, scaleX=0.9, scaleY=0.9, rotateSpeed=0, rotateAnger=0, resIdx=6, zorder=19},
			{x=display.cx+230, y=display.height/4+330, rotation=0, scaleX=0.8, scaleY=0.8, rotateSpeed=0, rotateAnger=0, resIdx=7, zorder=18},
			{x=display.cx+35, y=display.height/4+295, rotation=0, scaleX=0.8, scaleY=0.8, rotateSpeed=0, rotateAnger=0, resIdx=12, zorder=22},
		},
		{
			{x=display.cx+90, y=display.height/4+55, rotation=5, scaleX=1.0, scaleY=1.0, rotateSpeed=0, rotateAnger=0, resIdx=13, zorder=22},
			{x=display.cx-100, y=display.height/4+115, rotation=-15, scaleX=1.0, scaleY=1.0, rotateSpeed=0, rotateAnger=0, resIdx=15, zorder=36},
			{x=display.cx+230, y=display.height/4+295, rotation=0, scaleX=1.0, scaleY=1.0, rotateSpeed=0, rotateAnger=0, resIdx=19, zorder=21},
			{x=display.cx-250, y=display.height/4+100, rotation=-13, scaleX=0.8, scaleY=0.8, rotateSpeed=0, rotateAnger=0, resIdx=17, zorder=20, opacity=120},
			{x=display.cx-150, y=display.height/4+140, rotation=-10, scaleX=0.5, scaleY=0.5, rotateSpeed=0, rotateAnger=0, resIdx=18, zorder=20, opacity=200},
			{x=display.cx, y=display.height/4+100, rotation= 12, scaleX=1.2, scaleY=1.2, rotateSpeed=0, rotateAnger=0, resIdx=18, zorder=20, opacity=100},
			{x=display.cx+150, y=display.height/4, rotation=12, scaleX=0.7, scaleY=0.7, rotateSpeed=0, rotateAnger=0, resIdx=18, zorder=20, opacity=100},
			{x=display.cx+190, y=display.height/4+100, rotation=20, scaleX=0.9, scaleY=0.9, rotateSpeed=0, rotateAnger=0, resIdx=17, zorder=20, opacity=200},
			{x=display.cx+250, y=display.height/4+100, rotation=45, scaleX=0.8, scaleY=0.8, rotateSpeed=0, rotateAnger=0, resIdx=17, zorder=20, opacity=100},

			{x=display.cx+260, y=display.height/4+385, rotation=0, scaleX=1.0, scaleY=-1.0, rotateSpeed=0, rotateAnger=0, resIdx=14, zorder=22},
			{x=display.cx+150, y=display.height/4+470, rotation=-60, scaleX=1.0, scaleY=-1.0, rotateSpeed=0, rotateAnger=0, resIdx=14, zorder=22},
			{x=display.cx+138, y=display.height/4+490, rotation=5, scaleX=1.0, scaleY=1.0, rotateSpeed=0, rotateAnger=0, resIdx=14, zorder=22},
			{x=display.cx+25, y=display.height/4+420, rotation=5, scaleX=1.0, scaleY=1.0, rotateSpeed=0, rotateAnger=0, resIdx=14, zorder=22},
			{x=display.cx-75, y=display.height/4+320, rotation=-60, scaleX=1.0, scaleY=-1.0, rotateSpeed=0, rotateAnger=0, resIdx=14, zorder=22},
		},
	}
	local bgWorldSceneResParamList = allBgWorldSceneResParamList[self.worldIdx]
	if bgWorldSceneResParamList ~= nil then
		for i=1, #bgWorldSceneResParamList do
			local bgFlower = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.worldSceneResList[bgWorldSceneResParamList[i].resIdx])))
			if bgFlower ~= nil then
				bgFlower:setAnchorPoint(cc.p(0.5,0))
				bgFlower:setPosition(cc.p(bgWorldSceneResParamList[i].x, bgWorldSceneResParamList[i].y))
				bgFlower:setRotation(bgWorldSceneResParamList[i].rotation)
				bgFlower:setScaleX(bgWorldSceneResParamList[i].scaleX)
				bgFlower:setScaleY(bgWorldSceneResParamList[i].scaleY)
				bgFlower:setOpacity(bgWorldSceneResParamList[i].opacity or 255)
				self:addChild(bgFlower, bgWorldSceneResParamList[i].zorder)

				if bgWorldSceneResParamList[i].rotateSpeed > 0 then
					bgFlower:runAction(cc.RepeatForever:create(cc.Sequence:create(
							cc.RotateBy:create(bgWorldSceneResParamList[i].rotateSpeed/4, 0-bgWorldSceneResParamList[i].rotateAnger/2),
							cc.RotateBy:create(bgWorldSceneResParamList[i].rotateSpeed/2, bgWorldSceneResParamList[i].rotateAnger),
							cc.RotateBy:create(bgWorldSceneResParamList[i].rotateSpeed/4, 0-bgWorldSceneResParamList[i].rotateAnger/2)
						)
					))
				end
			end
		end
	end

	--fg friend and monster
	local allSceneCharacterList = {
		{
			{res=4, x=-200, y=200, rotation=-5, zorder=29, ani={start=1, count=2, time=0.04}, scaleX=0.4, scaleY=0.4},
			{res=2, x=-40, y=60, rotation=0, zorder=29, ani={start=1, count=1, time=0.04}, scaleX=0.6, scaleY=0.6},
		},
		{
			{res=4, x=-200, y=200, rotation=-5, zorder=29, ani={start=1, count=2, time=0.04}, scaleX=0.4, scaleY=0.4},
		},
		{
			{res=5, x=-200, y=220, rotation=0, zorder=29, ani={start=1, count=7, time=0.2}, scaleX=0.4, scaleY=0.4},
			{res=5, x=-50, y=370, rotation=0, zorder=29, ani={start=1, count=7, time=0.2}, scaleX=-0.4, scaleY=0.4},
		},
	}
	local sceneCharacterList = allSceneCharacterList[self.worldIdx]
	if sceneCharacterList ~= nil and self.mountainTopPic ~= nil then
		for i=1, #sceneCharacterList do
			local char = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
			if char ~= nil then
				char:setAnchorPoint(cc.p(0.5, 0))
				char:setRotation(sceneCharacterList[i].rotation)
				char:setPosition(cc.p(sceneCharacterList[i].x + self.mountainTopPic:getPositionX(), sceneCharacterList[i].y + self.mountainTopPic:getPositionY()))
				char:setScaleX(sceneCharacterList[i].scaleX)
				char:setScaleY(sceneCharacterList[i].scaleY)
				self:addChild(char, sceneCharacterList[i].zorder)
				-- char:runAction()
				AnimationManager.setAniToCache( ConfigManager.monsterTbl[tostring(sceneCharacterList[i].res)].res, 
												sceneCharacterList[i].ani.start, sceneCharacterList[i].ani.count, 
												sceneCharacterList[i].ani.time, 
												"monster_stage_show_" .. sceneCharacterList[i].res )
				local showAni = AnimationManager.getAniFromCacheByName("monster_stage_show_" .. sceneCharacterList[i].res)
				if showAni ~= nil then
					local showAnimation = cc.RepeatForever:create(cc.Animate:create(showAni))
					if showAnimation ~= nil then
						char:runAction(showAnimation)
					end
				end

				if sceneCharacterList[i].res == 5 then
					local dirRate = 1
					if sceneCharacterList[i].scaleX < 0 then
						dirRate = -1
					end
					
					local moveSeq = cc.RepeatForever:create(cc.Sequence:create(cc.MoveBy:create(5, cc.p(-20*dirRate, 0)),
														   cc.CallFunc:create(function()
																char:setScaleX(char:getScaleX()*(-1))
														   end),
														   cc.MoveBy:create(10, cc.p(40*dirRate, 0)),
														   cc.CallFunc:create(function()
																char:setScaleX(char:getScaleX()*(-1))
														   end),
														   cc.MoveBy:create(5, cc.p(-20*dirRate, 0))
														   ))
					char:runAction(moveSeq)
				end
			end
		end
	end

	--fg black block covers
	local allFgBlackUnitCoverList = {
		{
			{x=display.cx-180, y=display.height/4+150, scale=0.5, rotateSpeed=1, resIdx=1},
			{x=display.cx+150, y=display.height/4+220, scale=0.5, rotateSpeed=1, resIdx=2},
			{x=display.cx-100, y=display.height/4+280, scale=0.6, rotateSpeed=1, resIdx=3},
			{x=display.cx+120, y=display.height/4+160, scale=0.8, rotateSpeed=1, resIdx=4},
			{x=display.cx-35, y=display.height/4+220, scale=0.6, rotateSpeed=1, resIdx=5},
		},
		{
			{x=display.cx+10, y=display.height/4+500, scale=0.5, rotateSpeed=1, resIdx=1},
			{x=display.cx+120, y=display.height/4+450, scale=0.6, rotateSpeed=1, resIdx=3},
			{x=display.cx-50, y=display.height/4+280, scale=0.6, rotateSpeed=1, resIdx=5},
			{x=display.cx+135, y=display.height/4+220, scale=0.7, rotateSpeed=1, resIdx=4},
			{x=display.cx+180, y=display.height/4+160, scale=0.5, rotateSpeed=1, resIdx=2},
			
		},
		{
			{x=display.cx-200, y=display.height/4+150, scale=0.5, rotateSpeed=1, resIdx=1},
			{x=display.cx+135, y=display.height/4+170, scale=0.5, rotateSpeed=1, resIdx=2},
			{x=display.cx-150, y=display.height/4+250, scale=0.6, rotateSpeed=1, resIdx=3},
			{x=display.cx+250, y=display.height/4+140, scale=0.8, rotateSpeed=1, resIdx=4},
			{x=display.cx, y=display.height/4+160, scale=0.6, rotateSpeed=1, resIdx=5},
		},
	}
	
	local fgBlackUnitCoverList = allFgBlackUnitCoverList[self.worldIdx]
	if fgBlackUnitCoverList ~= nil then
		for i=1, #fgBlackUnitCoverList do
			local fgBlackUnit = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.blackUnitResList[fgBlackUnitCoverList[i].resIdx])))
			if fgBlackUnit ~= nil then
				fgBlackUnit:setAnchorPoint(cc.p(0.5,0.5))
				fgBlackUnit:setPosition(cc.p(fgBlackUnitCoverList[i].x, fgBlackUnitCoverList[i].y))
				fgBlackUnit:setScale(fgBlackUnitCoverList[i].scale)
				self:addChild(fgBlackUnit, 30)

				--
				local randStart = math.random(1, 3)
				local frames = display.newFrames(ResourceManager.ImageName("pic_repeat_darkclouds_%.2d"), randStart, 5-randStart+1, false)
				if frames ~= nil then
					local ani = display.newAnimation(frames, math.random(7, 13)/100)
					if ani ~= nil then
						fgBlackUnit:runAction(cc.RepeatForever:create(cc.Animate:create(ani)))
					end
				end
			end
		end
	end

	--stages view bg
	self.stageListView = require("app.views.StageListViewLayer").new(self)
	if self.stageListView ~= nil then
		self.stageListView:setPosition(cc.p(display.cx - (display.width-150)/2, 100))
		self:addChild(self.stageListView, 50)
	end

	--rank detail layer
	self.rankNode = require("app.views.RankDetailLayer").new()
	if self.rankNode ~= nil then
		self.rankNode:setPosition(cc.p(display.cx, display.cy+300))
		self.rankNode:setVisible(false)
		self:addChild(self.rankNode, 40)
	end
	
	--fountain effect
	self.fountainEffect = self:makeFountainPaoPao()
	if self.fountainEffect ~= nil then
		self.fountainEffect:setPosition(cc.p(display.cx, 300))
		self.fountainEffect:setVisible(false)
		self:addChild(self.fountainEffect, 45)
	end

	--start challenge button
	self.startGameButton = GameControlButton.new({
        btnBg = ResourceDef.GAME_PAUSE_TITLE_BG,
	    dstSize = {width=380, height=125},
        callback = function ()
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
        	--todo
        	if self.stageListView ~= nil then
        		if self.stageListView.selectedCell ~= nil then
        			self.stageListView:startGame(self.stageListView.stageData[self.stageListView.selectedCell.idx].stageId)
        		end
        	end
        end
    })
    if self.startGameButton ~= nil then
		self.startGameButton:setAnchorPoint(cc.p(0.5, 0.5))
		self.startGameButton:setPosition(cc.p(display.cx, display.cy))
		self.startGameButton:setVisible(false)
	    self:addChild(self.startGameButton, 46)

	    local btnLabel = display.newTTFLabel({
	        text = LangStringDefine.STAGE_CHALLENGE_START,
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 48,
	        color = cc.c3b(140,83,66),
	        align = cc.TEXT_ALIGNMENT_CENTER
	    })
	    if btnLabel ~= nil then
	        btnLabel:setAnchorPoint(cc.p(0.5, 0.5))
	        btnLabel:setPosition(cc.p(0, -10))
	        self.startGameButton:addChild(btnLabel, 100)
	    end
	end

end

function WorldLayer:requestRankInfo(stageId, cb)
	if UserDataManager.RANK_LIST[tostring(stageId)] == nil or
       UserDataManager.RANK_LIST[tostring(stageId)].lastReqTime == nil or 
       UserDataManager.RANK_LIST[tostring(stageId)].lastReqTime < os.time() - 30 then

        --request for rank
        local params = {id = stageId}
        local ret, resp = GameNetWorker.createHttpRequestWithPostParam(GameConfig.SERVER_ADDRESS .. GameConfig.REQUEST_URL.rank, params, false)
        if ret == true then
            local respInfo = json.decode(resp)
            if respInfo ~= nil then
                -- dump(respInfo)
                if respInfo.errorId ~= nil then
                    display.getRunningScene():showTips(respInfo.errorMsg)
                else
                    UserDataManager.RANK_LIST[tostring(stageId)] = {
                        myRank = 0,
                        rankInfo = respInfo,
                        lastReqTime = os.time()
                    }

                    for i=1, #respInfo do
                        if tostring(respInfo[i].playerId) == tostring(UserDataManager.PLAYER_UID) then
                            UserDataManager.RANK_LIST[tostring(stageId)].myRank = i
                            break
                        end
                    end

                    if self.rankNode ~= nil then
				    	local rankInfo = {
				    		myRank = "",
							myRecordTime = "",
							myBestStep = "",
							stageRank = {}
				    	}

				    	if UserDataManager.RANK_LIST[tostring(stageId)] ~= nil then
							rankInfo.myRank =UserDataManager.RANK_LIST[tostring(stageId)].myRank

							for i=1, 3 do
								rankInfo.stageRank[i] = {}
					    		if UserDataManager.RANK_LIST[tostring(stageId)].rankInfo[i] ~= nil then
					    			rankInfo.stageRank[i].name = UserDataManager.RANK_LIST[tostring(stageId)].rankInfo[i].playerId
					    			rankInfo.stageRank[i].steps = UserDataManager.RANK_LIST[tostring(stageId)].rankInfo[i].steps
					    		else
					    			rankInfo.stageRank[i].name = ""
					    			rankInfo.stageRank[i].steps = ""
					    		end
					    	end
						end
						if UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(stageId)] ~= nil then
							rankInfo.myRecordTime = UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(stageId)].record_use_time
							rankInfo.myBestStep = UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(stageId)].step
						end
				    	
				    	self.rankNode:setRankInfo(rankInfo)
				    	self.rankNode:setVisible(true)
				    	if self.startGameButton ~= nil then
							self.startGameButton:setVisible(true)
						end
				    end

					if self.fountainEffect ~= nil then
						self.fountainEffect:setVisible(true)
					end
                end

                if cb ~= nil then
                	cb()
                end
            end
        end
    else
    	if self.rankNode ~= nil then
	    	local rankInfo = {
	    		myRank = "",
				myRecordTime = "",
				myBestStep = "",
				stageRank = {}
	    	}

	    	if UserDataManager.RANK_LIST[tostring(stageId)] ~= nil then
				rankInfo.myRank =UserDataManager.RANK_LIST[tostring(stageId)].myRank

				for i=1, 3 do
					rankInfo.stageRank[i] = {}
		    		if UserDataManager.RANK_LIST[tostring(stageId)].rankInfo[i] ~= nil then
		    			rankInfo.stageRank[i].name = UserDataManager.RANK_LIST[tostring(stageId)].rankInfo[i].playerId
		    			rankInfo.stageRank[i].steps = UserDataManager.RANK_LIST[tostring(stageId)].rankInfo[i].steps
		    		else
		    			rankInfo.stageRank[i].name = ""
		    			rankInfo.stageRank[i].steps = ""
		    		end
		    	end
			end
			if UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(stageId)] ~= nil then
				rankInfo.myRecordTime = UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(stageId)].record_use_time
				rankInfo.myBestStep = UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(stageId)].step
			end
	    	
	    	self.rankNode:setRankInfo(rankInfo)
	    	self.rankNode:setVisible(true)
	    	if self.startGameButton ~= nil then
				self.startGameButton:setVisible(true)
			end
	    end

		if self.fountainEffect ~= nil then
			self.fountainEffect:setVisible(true)
		end

		if cb ~= nil then
        	cb()
        end
    end
 
end

function WorldLayer:HideRankInfo(needRefreshArrowVisibleFlag)
	if self.rankNode ~= nil then
		self.rankNode:setVisible(false)
	end
	if self.fountainEffect ~= nil then
		self.fountainEffect:setVisible(false)
	end
	if self.startGameButton ~= nil then
		self.startGameButton:setVisible(false)
	end


	if self.stageListView ~= nil then
		self.stageListView:clearSelectCell()
	end

	if needRefreshArrowVisibleFlag == nil or needRefreshArrowVisibleFlag == false then
		if self.parent ~= nil then
			if self.parent.leftBtnNode ~= nil then
				self.parent.leftBtnNode:setVisible(true)
			end
			if self.parent.rightBtnNode ~= nil then
				self.parent.rightBtnNode:setVisible(true)
			end
		end
	end
end

function WorldLayer:showOrHideStageView(flag)
	if self.stageListView ~= nil then
		self.stageListView:setVisible(flag)
	end
end

function WorldLayer:makeFountainPaoPao()
	local paopaoNode = cc.ParticleSystemQuad:create(ResourceDef.FOUNTAIN_PAOPAO_EFFECT .. ".plist") 
	if paopaoNode == nil then
		return nil
	end

	paopaoNode:setPositionType(cc.POSITION_TYPE_RELATIVE)

	return paopaoNode
end

function WorldLayer:update(t)
	
end

function WorldLayer:onTouchBegan(touch, event)
	if self:isVisible() == false or self.parent.currentWorldIdx ~= self.worldIdx or self.parent.isChangingWorldFlag == true then
		return false
	end

	self.showingRankFlag = false
	if self.rankNode ~= nil then
		self.showingRankFlag = self.rankNode:isVisible()
	end

	if self.showingRankFlag == true then
		return true
	end

	self.touchBeganPoint = touch:getLocation()

	return true
end

function WorldLayer:onTouchMoved(touch, event)
	if self:isVisible() == false or self.parent.currentWorldIdx ~= self.worldIdx or self.parent.isChangingWorldFlag == true then
		return
	end
	if self.showingRankFlag == true then
		return
	end
end

function WorldLayer:onTouchEnded(touch, event)
	if self:isVisible() == false or self.parent.currentWorldIdx ~= self.worldIdx or self.parent.isChangingWorldFlag == true then
		return
	end

	if self.showingRankFlag == true then
		self:HideRankInfo()
	else
		local endPoint = touch:getLocation()
		local deltX = endPoint.x - self.touchBeganPoint.x
		if math.abs(deltX) >= 150 then
			if deltX > 0 then
				self.parent:goPrevWorld()
			else
				self.parent:goNextWorld()
			end
		end
	end
end

function WorldLayer:openLayer()
	self:showOrHideStageView(true)
	if self.stageListView ~= nil then
		self.stageListView.touchEnableFlag = true
	end
	self:HideRankInfo(true)
	self:setVisible(true)
end


function WorldLayer:closeLayer()
	self:setVisible(false)
	if self.stageListView ~= nil then
		self.stageListView.touchEnableFlag = false
	end
	self:showOrHideStageView(false)
end

return WorldLayer
