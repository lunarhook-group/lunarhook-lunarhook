
local Item = class("Item",function()
	return display.newNode()
end )

function Item:ctor(itemId, keepTime)
	self.itemId = itemId

	self.mapPosition = {x=0,y=0}
	self.enable = false

	self.keepTime = keepTime or GameConfig.DEFAULT_ITEM_KEEP_TIME
	self.recordTime = 0
	self.isBlinkingFlag = false

	self.recycledFlag = false

	self:init()
end

function Item:init()
	self.itemTblInfo = ConfigManager.itemTbl[tostring(self.itemId)]
	if self.itemTblInfo == nil then
		return
	end

	self.mainNode = display.newNode()
	if self.mainNode == nil then
		return
	end

	self.mainNode:setAnchorPoint(cc.p(0.5,0.5))
	self.mainNode:setPosition(cc.p(0,0))
	self:addChild(self.mainNode)


	--main pic
	self.mainPic = display.newSprite(ResourceManager.ImageName(self.itemTblInfo.res))
	if self.mainPic ~= nil then
		self.mainPic:setAnchorPoint(cc.p(0.5,0))
		self.mainPic:setPosition(cc.p(0,10))
		self.mainPic:setScaleX(80/self.mainPic:getContentSize().width)
		self.mainPic:setScaleY(80/self.mainPic:getContentSize().height)
		self.mainNode:addChild(self.mainPic, 1)
	end

	--appear ani pic
	self.appearAniPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
	if self.appearAniPic ~= nil then
		self.appearAniPic:setAnchorPoint(cc.p(0.5,0))
		self.appearAniPic:setPosition(cc.p(0,10))
		self.appearAniPic:setScaleX(self.mainPic:getScaleX())
		self.appearAniPic:setScaleY(self.mainPic:getScaleY())
		self.mainNode:addChild(self.appearAniPic, 2)
	end

	self.initShadowPosY = 0
	self.initShadowScale = 0.3
	self.mainShadowPic = display.newSprite(ResourceManager.ImageName(ResourceDef.PLAYER_SHADOW))
	if self.mainShadowPic ~= nil then
		self.mainShadowPic:setAnchorPoint(cc.p(0.5,0.5))
		self.mainShadowPic:setPosition(cc.p(0,self.initShadowPosY))
		self.mainShadowPic:setScale(self.initShadowScale)
		self.mainNode:addChild(self.mainShadowPic)
	end

	self.enable = true
	self:appear()
end

function Item:reuse(itemId, keepTime, pos)
	if self.recycledFlag == false then
		return
	end
	self.recycledFlag = false

	self.itemId = itemId
	self.mapPosition = {x=0,y=0}
	self.enable = false
	self.keepTime = keepTime or GameConfig.DEFAULT_ITEM_KEEP_TIME
	self.recordTime = 0
	self.isBlinkingFlag = false
	self.startFloatingFlag = false

	self.itemTblInfo = ConfigManager.itemTbl[tostring(self.itemId)]
	if self.itemTblInfo == nil then
		return
	end

	if self.mainNode ~= nil then
		self.mainNode:setPosition(cc.p(0,0))
	end

	if self.mainPic ~= nil then
		local tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(self.itemTblInfo.res))
		if tpFrame ~= nil then
			self.mainPic:setSpriteFrame(tpFrame)
		end
	end

	if self.mainShadowPic ~= nil then
		self.mainShadowPic:setPosition(cc.p(0,self.initShadowPosY))
		self.mainShadowPic:setScale(self.initShadowScale)
		self.mainShadowPic:setVisible(true)
	end

	self:setMapPosition(pos)

	self:setVisible(true)
	self.enable = true
	self:appear()
end

function Item:setMapPosition(pos)
	if pos == nil or pos.x == nil or pos.y == nil then
		return
	end

	self.mapPosition.x = pos.x
	self.mapPosition.y = pos.y
end

function Item:getMapPosition()
	return self.mapPosition
end

function Item:startFloat()
	if self.mainNode ~= nil then
		self.mainNode:runAction(cc.RepeatForever:create(cc.Sequence:create(
			cc.MoveBy:create(0.5, cc.p(0, 5)),
			cc.MoveBy:create(1.0, cc.p(0, -10)),
			cc.MoveBy:create(0.5, cc.p(0, 5))
		)))
	end
end

function Item:update(t)
	if self.enable == false then
		return
	end

	if self.startFloatingFlag == nil or self.startFloatingFlag == false then
		self.startFloatingFlag = true
		self:startFloat()
	end

	if self.mainShadowPic ~= nil then
		self.mainShadowPic:setPositionY(0-self.mainNode:getPositionY()+self.initShadowPosY)
		self.mainShadowPic:setScale(self.initShadowScale - (self.initShadowScale - 0.2) * (self.mainNode:getPositionY() / 5))
	end

	self.recordTime = self.recordTime + t
	if self.isBlinkingFlag == false and self.recordTime >= self.keepTime - GameConfig.ITEM_DISAPPEAR_WARNING_TIME then
		--blink
		self.mainPic:runAction(cc.Blink:create(GameConfig.ITEM_DISAPPEAR_WARNING_TIME, 10))
		self.isBlinkingFlag = true
	end

	if self.recordTime >= self.keepTime then
		--disappear
		self:disappear()
	end

end

function Item:beGot()
	self.enable = false
	self:setVisible(false)

	if self.itemTblInfo ~= nil and self.itemTblInfo.item_type ~= nil then
		AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.getItemEffect[self.itemTblInfo.item_type]), false)
		if self.itemTblInfo.item_type == GameDefine.ITEM_TYPE.ADD_COIN then
			if self.itemTblInfo.params ~= nil and type(self.itemTblInfo.params == "table") then
				if self.itemTblInfo.params[1] ~= nil and self.itemTblInfo.params[1] > 0 then
					UserDataManager.UM_COIN = UserDataManager.UM_COIN + self.itemTblInfo.params[1]
					UserDataManager.savePlayerBaseData()
				end
			end
		elseif self.itemTblInfo.item_type == GameDefine.ITEM_TYPE.ADD_CANDY then
			if self.itemTblInfo.params ~= nil and type(self.itemTblInfo.params == "table") then
				if self.itemTblInfo.params[1] ~= nil and self.itemTblInfo.params[1] > 0 then
					UserDataManager.UM_CANDY = UserDataManager.UM_CANDY + self.itemTblInfo.params[1]
					UserDataManager.savePlayerBaseData()
				end
			end
		end
		EventListener.dispatchEvent({name = GameDefine.GAME_EVENT_TYPE.GET_ITEM, item_id = self.itemId})
	end

	self:recycle()
end

function Item:appear()
	if self.appearAniPic == nil then
		return
	end

	local disappearAni = AnimationManager.getAniFromCacheByName("disappear_cover_ani")
	if disappearAni ~= nil then
		self.appearAniPic:runAction(
				cc.Sequence:create(cc.Animate:create(disappearAni),
									cc.CallFunc:create(function()
										local tpPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
										if tpPic ~= nil then
											self.appearAniPic:setSpriteFrame(tpPic:getSpriteFrame())
										end
									end)
				)
			)
	end
end

function Item:disappear()
	if self.enable == false then
		return
	end
	self.enable = false

	if self.mainPic ~= nil then
		self.mainPic:stopAllActions()
		self.mainPic:setVisible(false)
	end

	if self.appearAniPic ~= nil then
		local disappearAni = AnimationManager.getAniFromCacheByName("disappear_cover_ani")
		if disappearAni ~= nil then
			self.appearAniPic:runAction(
					cc.Sequence:create(cc.Animate:create(disappearAni),
										cc.CallFunc:create(function()
											local tpPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
											if tpPic ~= nil then
												self.appearAniPic:setSpriteFrame(tpPic:getSpriteFrame())
											end
											self:recycle()
										end)
					)
				)
		end
	end

	-- local disappearAnimation = nil
	-- local disappearAni = AnimationManager.getAniFromCacheByName("disappear_cover_ani")
	-- if disappearAni ~= nil then
	-- 	disappearAnimation = cc.Animate:create(disappearAni)
	-- else
	-- 	disappearAnimation = cc.FadeTo:create(GameConfig.ITEM_DISAPPEAR_ACTION_TIME, 0)
	-- end

	-- if disappearAnimation ~= nil then
	-- 	self.mainPic:stopAllActions()
	-- 	self.mainPic:runAction(cc.Sequence:create(disappearAnimation, cc.CallFunc:create(function()
	-- 		self:recycle()
	-- 	end)))
	-- end
end

function Item:recycle()
	self:stopAllActions()
	self:setVisible(false)
	if self.mainPic ~= nil then
		self.mainPic:setVisible(true)
	end
	self.isBlinkingFlag = false
	self.recordTime = 0
	self.startFloatingFlag = false
	self.recycledFlag = true


end



return Item
