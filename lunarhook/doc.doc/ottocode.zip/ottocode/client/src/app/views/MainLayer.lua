
local StageNode = import("app.views.StageNode")
local SmallBall = import("app.views.SmallBall")
local GameControlButton = import("app.views.GameControlButton")

local MainLayer = class("MainLayer", BaseLayer)

function MainLayer:ctor()
	MainLayer.super.ctor(self)

	self.gameLoginedFlag = false

	self:initUI()
end

function MainLayer:initUI()
	--nodes
	self.mainNode = display.newNode()
	if self.mainNode == nil then
		return
	end

	self.midSceneWidth = display.width*0.5
	local midSceneWidth = self.midSceneWidth

	self.mainNode:setAnchorPoint(cc.p(0.5,0.5))
	self.mainNode:setPosition(cc.p(0,0))
	self:addChild(self.mainNode)

	
	--bg
	-------bgcolorlayer
	local bgLayerSize = {width=display.width*3, height=display.height*2}
	local bgColorLayer = cc.LayerColor:create(cc.c4b(240, 240, 240, 255), bgLayerSize.width, bgLayerSize.height)
	if bgColorLayer ~= nil then
		bgColorLayer:setAnchorPoint(cc.p(0, 0))
		bgColorLayer:setPosition(cc.p(0, 0))
		self.mainNode:addChild(bgColorLayer, 10)
	end

	-------transparent bg pics
	local transparentBgPic1 = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.transparentBg1)))
	if transparentBgPic1 ~= nil then
		transparentBgPic1:setAnchorPoint(cc.p(0, 0))
		local scaleRate = display.height/transparentBgPic1:getContentSize().height
		transparentBgPic1:setScale(scaleRate)
		transparentBgPic1:setPosition(cc.p(0, 0))
		transparentBgPic1:setOpacity(150)
		self.mainNode:addChild(transparentBgPic1, 15)
	end
	local transparentBgPic2 = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.transparentBg2)))
	if transparentBgPic2 ~= nil then
		transparentBgPic2:setAnchorPoint(cc.p(0.5, 0))
		local scaleRate = display.height/transparentBgPic2:getContentSize().height
		transparentBgPic2:setScale(scaleRate)
		transparentBgPic2:setPosition(cc.p(display.width+midSceneWidth/2, 0))
		transparentBgPic2:setOpacity(150)
		self.mainNode:addChild(transparentBgPic2, 15)
	end

	-------clouds
	local cloudNode1 = GameTools.makeMoveClouds(0-display.cx, display.cy+150, display.width*3+midSceneWidth, display.cy-100)
	if cloudNode1 ~= nil then
		self.mainNode:addChild(cloudNode1, 17)
	end
	-- local cloudNode2 = GameTools.makeMoveClouds(display.width + midSceneWidth-300, display.height-180, display.width+150, 130)
	-- if cloudNode2 ~= nil then
	-- 	self.mainNode:addChild(cloudNode2, 17)
	-- end
	-- local cloudNode3 = GameTools.makeMoveClouds(display.width + midSceneWidth-300, display.height-180, display.width+150, 130)
	-- if cloudNode3 ~= nil then
	-- 	self.mainNode:addChild(cloudNode3, 17)
	-- end
	
	-------air ground content
	local airGround1 = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.airGround1)))
	if airGround1 ~= nil then
		airGround1:setAnchorPoint(cc.p(0.2, 0.95))
		airGround1:setPosition(cc.p(0, display.height))
		self.mainNode:addChild(airGround1, 20)
	end
	local airGround2 = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.airGround2)))
	if airGround2 ~= nil then
		airGround2:setAnchorPoint(cc.p(0.5, 0.9))
		airGround2:setScale(1)
		airGround2:setPosition(cc.p(display.width, display.height))
		self.mainNode:addChild(airGround2, 20)
	end
	local airGround3 = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.airGround3)))
	if airGround3 ~= nil then
		airGround3:setAnchorPoint(cc.p(0.3, 0.5))
		airGround3:setPosition(cc.p(display.width + midSceneWidth, display.cy+100))
		self.mainNode:addChild(airGround3, 20)
	end

	-------round small trees
	local offX = display.width + midSceneWidth
	local roundSmallTreePosList = {
		{x=-30, y=80, zOrder=18,resIdx=2,scale=0.9},
		{x=186, y=58, zOrder=18,resIdx=1,scale=0.8},
		{x=display.cx+36, y=75, zOrder=17,resIdx=2,scale=0.8},
		{x=display.cx+90, y=67, zOrder=18,resIdx=1,scale=0.8},
		{x=display.width-96, y=100, zOrder=18,resIdx=3,scale=0.8},
		{x=display.width-64, y=135, zOrder=17,resIdx=2,scale=0.7},
		{x=display.width-35, y=75, zOrder=17,resIdx=2,scale=0.7},
		{x=display.width-110, y=display.height-46, zOrder=18,resIdx=2,scale=0.7},
		{x=display.width-85, y=display.height+14, zOrder=17,resIdx=1,scale=0.8},

		{x=offX+23, y=display.height-16, zOrder=18,resIdx=2,scale=0.8},
		{x=offX-20, y=119, zOrder=18,resIdx=1,scale=0.8},
		{x=offX, y=200, zOrder=17,resIdx=2,scale=1},
		{x=offX+40, y=115, zOrder=16,resIdx=2,scale=1.5},
		{x=offX+140, y=53, zOrder=18,resIdx=1,scale=0.7},
		{x=offX+display.width-82, y=58, zOrder=18,resIdx=1,scale=1},
		{x=offX+display.width-13, y=131, zOrder=17,resIdx=2,scale=1},
		{x=offX+display.width-50, y=display.height+19, zOrder=18,resIdx=2,scale=0.8},
		{x=offX+display.width, y=display.height, zOrder=17,resIdx=1,scale=0.8},
	}
	for i=1, #roundSmallTreePosList do
		local roundTreePic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.roundSmallTree[roundSmallTreePosList[i].resIdx])))
		if roundTreePic ~= nil then
			roundTreePic:setAnchorPoint(cc.p(0.5, 0.5))
			roundTreePic:setPosition(cc.p(roundSmallTreePosList[i].x, roundSmallTreePosList[i].y))
			roundTreePic:setScale(roundSmallTreePosList[i].scale)
			self.mainNode:addChild(roundTreePic, roundSmallTreePosList[i].zOrder)
		end
	end

	-------ground
	local tmpPosX = 0
	for i=1, 10 do
		if tmpPosX >= display.width*2 + midSceneWidth then
			break
		end
		local resIdx = math.fmod(i-1, #ResourceDef.MAINSCENE_CONTENT.groundResList) + 1
		local ground = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.groundResList[resIdx])))
		if ground ~= nil then
			ground:setAnchorPoint(cc.p(0, 0))
			ground:setPosition(cc.p(tmpPosX, 0))
			self.mainNode:addChild(ground, 35)
			tmpPosX = tmpPosX + ground:getContentSize().width - 2
		end
	end

	-------big flower
	local bigFlowerResName = string.format("%s%0.2d", ResourceDef.MAINSCENE_CONTENT.bigFlower.res, ResourceDef.MAINSCENE_CONTENT.bigFlower.start)
	AnimationManager.setAniToCache(ResourceDef.MAINSCENE_CONTENT.bigFlower.res, ResourceDef.MAINSCENE_CONTENT.bigFlower.start, ResourceDef.MAINSCENE_CONTENT.bigFlower.count, ResourceDef.MAINSCENE_CONTENT.bigFlower.time, "bigflower_ani")
	local bigFlowerAni = AnimationManager.getAniFromCacheByName("bigflower_ani")
	local bigFlowerAnimation = nil
	if bigFlowerAni ~= nil then
		bigFlowerAnimation = cc.RepeatForever:create(cc.Animate:create(bigFlowerAni))
	end
	self.bigFlower = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(bigFlowerResName)))
	if self.bigFlower ~= nil then
		self.bigFlower:setAnchorPoint(cc.p(0.5, 0))
		self.bigFlower:setPosition(cc.p(60, 55))
		self.mainNode:addChild(self.bigFlower, 33)
		if bigFlowerAnimation ~= nil then
			self.bigFlower:runAction(bigFlowerAnimation:clone())
		end
	end

	-------big flower2
	self.bigFlower2 = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(bigFlowerResName)))
	if self.bigFlower2 ~= nil then
		self.bigFlower2:setAnchorPoint(cc.p(0.5, 0))
		self.bigFlower2:setPosition(cc.p(display.width*2 + midSceneWidth - 120, 45))
		self.bigFlower2:setScaleX(-0.7)
		self.bigFlower2:setScaleY(0.7)
		self.mainNode:addChild(self.bigFlower2, 34)
		if bigFlowerAnimation ~= nil then
			self.bigFlower2:runAction(bigFlowerAnimation:clone())
		end
	end

	--return login 
	local returnLoginButton = GameControlButton.new({
        btnBg = ResourceDef.IMAGE_TRANSPARENT,
	    dstSize = {width=77, height=112},
        callback = function ()
        	if self.gameLoginedFlag == false then
        		return 
        	end
        	if self.isMainLayerShowing == false then
        		return
        	end
        	self:returnLogin()
        end
    })
    if returnLoginButton ~= nil then
		returnLoginButton:setAnchorPoint(cc.p(0.5, 0.5))
		returnLoginButton:setPosition(cc.p(cc.p(display.width*2 + midSceneWidth - 120, 45+112/2)))
	    self.mainNode:addChild(returnLoginButton, 35)
	end

	-------stone
	local stone = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.stone)))
	if stone ~= nil then
		stone:setAnchorPoint(cc.p(1, 0))
		stone:setPosition(cc.p(display.width*2 + midSceneWidth + 10, 35))
		self.mainNode:addChild(stone, 33)
	end

	-------home carrot
	self.homeCarrot = require("app.views.CarrotNode").new(false)
	if self.homeCarrot ~= nil then
		self.homeCarrot:setPosition(cc.p(display.width*1.5 + midSceneWidth, 10))
		self.mainNode:addChild(self.homeCarrot, 32)
	end

	--game icon
	-------words
	local gameIconWordPosList = {
		{x=display.cx-170, y=display.cy+110}, {x=display.cx+20, y=display.cy+120}, 
		{x=display.cx-80, y=display.cy-80}, {x=display.cx+40, y=display.cy-80}, {x=display.cx+190, y=display.cy-80}, 
	}
	self.gameIconWordList = {}
	for i=1, #gameIconWordPosList do
		self.gameIconWordList[i] = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.gameNameWord[i])))
		if self.gameIconWordList[i] ~= nil then
			self.gameIconWordList[i]:setAnchorPoint(cc.p(0.5,0))
			self.gameIconWordList[i]:setPosition(cc.p(gameIconWordPosList[i].x, gameIconWordPosList[i].y))
			self.mainNode:addChild(self.gameIconWordList[i], 50)
		end
	end

	-------small flowers
	local smallFlowerPosList = {
		{x=-2, y=124, wordIdx=1, resIdx=3, scaleX=1, rotation=0, zOrder=-1},
		{x=85, y=157, wordIdx=1, resIdx=4, scaleX=1, rotation=0, zOrder=-1},
		{x=120, y=155, wordIdx=1, resIdx=8, scaleX=1, rotation=-30, zOrder=-1},
		{x=130, y=90, wordIdx=1, resIdx=6, scaleX=-1, rotation=-55, zOrder=-1}, 
		{x=113, y=1, wordIdx=1, resIdx=8, scaleX=1, rotation=0, zOrder=-1},

		{x=-10, y=10, wordIdx=2, resIdx=8, scaleX=-1, rotation=0, zOrder=-1},
		{x=35, y=60, wordIdx=2, resIdx=11, scaleX=1, rotation=0, zOrder=-1},
		{x=50, y=60, wordIdx=2, resIdx=6, scaleX=1, rotation=5, zOrder=-1},
		{x=95, y=100, wordIdx=2, resIdx=2, scaleX=1, rotation=5, zOrder=-1},
		{x=155, y=5, wordIdx=2, resIdx=10, scaleX=1, rotation=-20, zOrder=-1},
		{x=160, y=45, wordIdx=2, resIdx=6, scaleX=1, rotation=0, zOrder=-1},
		{x=205, y=50, wordIdx=2, resIdx=7, scaleX=1, rotation=0, zOrder=-1},

		{x=-10, y=40, wordIdx=3, resIdx=9, scaleX=1, rotation=0, zOrder=-1},
		{x=8, y=60, wordIdx=3, resIdx=2, scaleX=1, rotation=0, zOrder=-1},
		{x=85, y=70, wordIdx=3, resIdx=10, scaleX=1, rotation=15, zOrder=-1},

		{x=20, y=60, wordIdx=4, resIdx=5, scaleX=1, rotation=0, zOrder=-1},
		{x=70, y=70, wordIdx=4, resIdx=11, scaleX=-1, rotation=0, zOrder=-1},
		{x=115, y=38, wordIdx=4, resIdx=2, scaleX=-1, rotation=0, zOrder=-1},

		{x=30, y=75, wordIdx=5, resIdx=7, scaleX=1, rotation=-20, zOrder=1},
		{x=48, y=110, wordIdx=5, resIdx=3, scaleX=1, rotation=0, zOrder=-1},
		{x=80, y=115, wordIdx=5, resIdx=10, scaleX=1, rotation=0, zOrder=-1},
		{x=125, y=85, wordIdx=5, resIdx=1, scaleX=1, rotation=0, zOrder=-1},
	}
	self.iconSmallFlowerList = {}
	for i=1, #smallFlowerPosList do
		self.iconSmallFlowerList[i] = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.smallFlowerResList[smallFlowerPosList[i].resIdx])))
		if self.iconSmallFlowerList[i] ~= nil then
			self.iconSmallFlowerList[i]:setAnchorPoint(cc.p(0.5,0))
			self.iconSmallFlowerList[i]:setScaleX(smallFlowerPosList[i].scaleX)
			self.iconSmallFlowerList[i]:setRotation(smallFlowerPosList[i].rotation)
			self.iconSmallFlowerList[i]:setPosition(cc.p(smallFlowerPosList[i].x, smallFlowerPosList[i].y))
			self.gameIconWordList[smallFlowerPosList[i].wordIdx]:addChild(self.iconSmallFlowerList[i], smallFlowerPosList[i].zOrder)
		end
	end

	--function panel
	local tmpVal = display.width + midSceneWidth
	local funcPanelContentList = {
		{ganRes=1, ganPos={x=tmpVal+145,y=display.cy+100}, ganZOrder=19, panelPos={x=tmpVal+148,y=display.cy+180}, panelZOrder=35, panelRotation=0, cbIdx=4, word="个人"},
		{ganRes=2, ganPos={x=tmpVal+90,y=35}, ganZOrder=34, panelPos={x=tmpVal+90,y=160}, panelZOrder=35, panelRotation=0, cbIdx=1, word="关卡"},
		{ganRes=3, ganPos={x=tmpVal+display.width-105,y=180}, ganZOrder=32, panelPos={x=tmpVal+display.width-125,y=255}, panelZOrder=35, panelRotation=-10, cbIdx=3, word="地编"},
		{ganRes=4, ganPos={x=tmpVal+display.width-90,y=195}, ganZOrder=32, panelPos={x=tmpVal+display.width-100,y=380}, panelZOrder=35, panelRotation=5, cbIdx=2, word="商店"},
	}
	for i=1, #funcPanelContentList do
		local ganPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.funcPanelGanResList[funcPanelContentList[i].ganRes])))
		if ganPic ~= nil then
			ganPic:setAnchorPoint(cc.p(0.5, 0))
			ganPic:setPosition(cc.p(funcPanelContentList[i].ganPos.x, funcPanelContentList[i].ganPos.y))
			self.mainNode:addChild(ganPic, funcPanelContentList[i].ganZOrder)
		end

		local funcButton = GameControlButton.new({
	        btnBg = ResourceDef.MAINSCENE_CONTENT.funcPanelBtnRes,
		    dstSize = {width=158, height=90},
	        buttonFont = funcPanelContentList[i].word,
	        buttonFontSize = 48,
	        buttonFontColor = cc.c3b(255,255,255),
	        callback = function ()
		        if self.gameLoginedFlag == false then
	        		return 
	        	end
	        	if self.isMainLayerShowing == false then
	        		return
	        	end
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
	        	self:cbFunction(funcPanelContentList[i].cbIdx)
	        end
	    })
	    if funcButton ~= nil then
			funcButton:setAnchorPoint(cc.p(0.5, 0.5))
			funcButton:setPosition(cc.p(funcPanelContentList[i].panelPos.x, funcPanelContentList[i].panelPos.y))
			funcButton:setRotation(funcPanelContentList[i].panelRotation)
		    self.mainNode:addChild(funcButton, funcPanelContentList[i].panelZOrder)
		end
	end

	--other
	-------fly flowers
	self:makeFloatFlowers(self.mainNode, 30)

	-------rising paopao
	self:makeRisingPaoPao()

	-------balls
	self:createBallSprites()

	self.hasClickStart = false
	local startButton = GameControlButton.new({
        btnBg = ResourceDef.IMAGE_TRANSPARENT,
	    dstSize = {width=display.width, height=display.height*2},
        buttonFont = LangStringDefine.CHALLENGE_BEGIN,
        buttonFontSize = 48,
        buttonFontColor = cc.c3b(140,83,66),
        pressedScale = 1.0,
        pressDown = function ()
        	if self.hasClickStart == true then
        		return 
        	end
        	if self.isMainLayerShowing == false then
        		return
        	end
        	self.hasClickStart = true
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_begin), false)
        	self:gameLogin()
        end
    })
    if startButton ~= nil then
		startButton:setAnchorPoint(cc.p(0.5, 0.5))
		startButton:setPosition(cc.p(display.cx, display.cy/4+50))
	    self.mainNode:addChild(startButton, 100)
	end

	--game icon action
	local fastTime = 0.3
	local slowTime = 0.5
	local maxScaleY = 1.1
	local minScaleY = 0.9
	local offsetAnger = 5 
	local delay_time = 0.2
	local scaleAni = cc.Sequence:create(cc.ScaleTo:create(slowTime, 1, minScaleY), cc.DelayTime:create(delay_time), cc.ScaleTo:create(fastTime, 1, maxScaleY))
	local scaleAni2 = cc.Sequence:create(cc.ScaleTo:create(slowTime, -1, minScaleY), cc.DelayTime:create(delay_time), cc.ScaleTo:create(fastTime, -1, maxScaleY))
	local rotationAni = cc.Sequence:create(cc.RotateTo:create(delay_time+fastTime+slowTime, offsetAnger*2), cc.RotateTo:create(delay_time+fastTime+slowTime, 0-offsetAnger*2))
	scaleAni:retain()
	scaleAni2:retain()
	rotationAni:retain()
	for i=1,#self.gameIconWordList do
		self.gameIconWordList[i]:setScaleY(maxScaleY)
		self.gameIconWordList[i]:setRotation(0-offsetAnger)
		self.gameIconWordList[i]:runAction(cc.RepeatForever:create(scaleAni:clone()))
		self.gameIconWordList[i]:runAction(cc.RepeatForever:create(rotationAni:clone()))
	end
	for i=1, #self.iconSmallFlowerList do
		if self.iconSmallFlowerList[i]:getScaleX() > 0 then
			self.iconSmallFlowerList[i]:runAction(cc.RepeatForever:create(scaleAni:clone()))
		else
			self.iconSmallFlowerList[i]:runAction(cc.RepeatForever:create(scaleAni2:clone()))
		end
	end
	scaleAni:release()
	scaleAni2:release()
	rotationAni:release()

	AnimationManager.setAniToCache(ResourceDef.UI_FRIEND_ZHAOSHOU_RES_PARAM.res, 
								   ResourceDef.UI_FRIEND_ZHAOSHOU_RES_PARAM.start, 
								   ResourceDef.UI_FRIEND_ZHAOSHOU_RES_PARAM.count, 
								   ResourceDef.UI_FRIEND_ZHAOSHOU_RES_PARAM.time, 
								   "friend_zhaoshou")

end

function MainLayer:gameLogin()
	GameConfig.ISONLINE = true
	local curScene = display.getRunningScene()
	local params = {playerId=UserDataManager.PLAYER_UID}
	local ret, resp = GameNetWorker.createHttpRequestWithPostParam(GameConfig.SERVER_ADDRESS .. GameConfig.REQUEST_URL.login, params, false)
	if ret == true then
		local respInfo = json.decode(resp)
		-- dump(respInfo)
		if respInfo ~= nil then
			if respInfo.errorId ~= nil then
				if curScene ~= nil and curScene.showTips ~= nil then
					curScene:showTips(respInfo.errorMsg)
				end
			else
				if UserDataManager.PLAYER_UID == "0000" and respInfo.playerId ~= nil then
					UserDataManager.savePlayerUID(respInfo.playerId)
				end

				if respInfo.baseInfo ~= nil then
					if respInfo.baseInfo.model_id ~= nil then
						UserDataManager.PlayerModelID = respInfo.baseInfo.model_id
					end
					if respInfo.baseInfo.coin ~= nil then
						UserDataManager.UM_COIN = respInfo.baseInfo.coin
					end
					if respInfo.baseInfo.candy ~= nil then
						UserDataManager.UM_CANDY = respInfo.baseInfo.candy
					end
				end

				if respInfo.stageInfo ~= nil then
					UserDataManager.PLAYER_STAGES_STATE_LIST = respInfo.stageInfo
				end

				if respInfo.mapInfo ~= nil then
					UserDataManager.PLAYER_MAP_UPLOAD_LIST = respInfo.mapInfo.upload or {}
					UserDataManager.PLAYER_MAP_DOWNLOAD_LIST = respInfo.mapInfo.download or {}
				end

				--
				self.gameLoginedFlag = true
				self.fastMoveFlag = true
				self.mainNode:runAction(cc.MoveBy:create(GameConfig.LOGIN_TO_MAIN_TRANS_TIME, cc.p(0-display.width-self.midSceneWidth, 0)))

			end
		else
			if curScene ~= nil and curScene.showTips ~= nil then
				curScene:showTips("resp fromat error.")
			end
		end
	else
		if curScene ~= nil and curScene.showTips ~= nil then
			curScene:showTips("server fault.")
		end
	end

end

function MainLayer:returnLogin()
	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_begin), false)
	self.gameLoginedFlag = false
	self.fastMoveFlag = true
	self.mainNode:runAction(cc.Sequence:create(
			cc.MoveBy:create(GameConfig.LOGIN_TO_MAIN_TRANS_TIME, cc.p(display.width+self.midSceneWidth, 0)),
			cc.CallFunc:create(function()
				self.hasClickStart = false
			end))
	)
end

function MainLayer:makeFloatFlowers(node, zorder)
	if node == nil then
		return
	end
	if zorder == nil then
		zorder = 1
	end

	local totalCountRow = 4
	local totalCountColumn = 4
	for i=1, totalCountRow*totalCountColumn do
		local randIdx = math.random(1, #ResourceDef.MAINSCENE_CONTENT.floatFlowers)
		local flower = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.floatFlowers[randIdx])))
		if flower ~= nil then
			flower:setAnchorPoint(cc.p(0.5,0.5))
			flower:setScale(math.random(100, 120)/100)
			node:addChild(flower, zorder)
			flower:runAction(cc.RepeatForever:create(cc.RotateBy:create(1, 360)))

			local rowIdx = math.floor(i/totalCountRow)
			local columnIdx = math.fmod(i, totalCountColumn) + 1
			flower:setPosition(cc.p(math.random(display.width*columnIdx/totalCountColumn, display.width*(columnIdx+1)/totalCountColumn), math.random(display.height*rowIdx/totalCountRow, display.height*(rowIdx+1)/totalCountRow)))

			local offval = 5
			local bez = {
				cc.p(math.random(31-offval, 31+offval), math.random(-124-offval, -124+offval)),
				cc.p(math.random(100-offval, 100+offval), math.random(-138-offval, -138+offval)),
				cc.p(math.random(95-offval, 95+offval), math.random(-100-offval, -100+offval))
			}
			flower:runAction(cc.RepeatForever:create(cc.Sequence:create(
				cc.BezierBy:create(math.random(50, 100) / 10, bez), 
				cc.CallFunc:create(function()
					if flower:getPositionY() < 0 then
						if self.gameLoginedFlag == true then
							flower:setPosition(cc.p(math.random(display.width+self.midSceneWidth-150, display.width+self.midSceneWidth+display.cx-100), math.random(display.height, display.height+100)))
						else
							flower:setPosition(cc.p(math.random(-150, display.cx-100), math.random(display.height, display.height+100)))
						end
					end
				end)
			)))
		end
	end
end

function MainLayer:makeRisingPaoPao()
	local paopaoNode = cc.ParticleSystemQuad:create(ResourceDef.RISING_PAOPAO_EFFECT .. ".plist") 
	if paopaoNode == nil then
		return
	end
	if self.mainNode == nil then
		return
	end

	paopaoNode:setPositionType(cc.POSITION_TYPE_RELATIVE)
	paopaoNode:setPosition(cc.p(display.width - 50, 50))
	self.mainNode:addChild(paopaoNode, 30)
end

function MainLayer:createBallSprites()
	self.ballSpriteList = {}
	self.fastMoveFlag = false
	for i=1, 10 do
		local randIdx = math.random(1, #ResourceDef.MAINSCENE_CONTENT.groundBallResList)
		self.ballSpriteList[i] = SmallBall.new(self, i, randIdx)
		if self.ballSpriteList[i] ~= nil then
			self.ballSpriteList[i]:setAnchorPoint(cc.p(0.5,0.5))
			self.ballSpriteList[i]:setPosition(cc.p(0+math.random(0, 640), 50+math.random(0,10)))
			self.ballSpriteList[i].nodePosX = self.ballSpriteList[i]:getPositionX()
			self.mainNode:addChild(self.ballSpriteList[i], 37)
		end
	end
end

function MainLayer:update(t)
	
	if self.ballSpriteList ~= nil then
		for i=1, #self.ballSpriteList do
			self.ballSpriteList[i]:update(t)
		end
	end
	
end

function MainLayer:cbFunction(funcIdx)
	if funcIdx == 1 then
		self:openStageSelect()
	elseif funcIdx == 2 then
		self:openShop()
	elseif funcIdx == 3 then
		self:openEditor()
	elseif funcIdx == 4 then
		self:openPlayerInfo()
	end
end

function MainLayer:openShop()
	local curScene = display.getRunningScene()
	if curScene ~= nil then
		curScene:UITransition(function()
			curScene:openShop()
		end)
	end
end

function MainLayer:openEditor()
	local curScene = display.getRunningScene()
	if curScene ~= nil then
		curScene:UITransition(function()
			curScene:openEditor()
		end)
	end
end

function MainLayer:openStageSelect()
	local curScene = display.getRunningScene()
	if curScene ~= nil then
		curScene:UITransition(function()
			curScene:returnStageSelectLayer()
		end)
	end
end

function MainLayer:openPlayerInfo()
	local curScene = display.getRunningScene()
	if curScene ~= nil then
		curScene:UITransition(function()
			curScene:openPlayerInfo()
		end)
	end
end


function MainLayer:onTouchBegan(touch, event)
	if self:isVisible() == false or self.gameLoginedFlag == false or self.isMainLayerShowing == false then
		return false
	end

	self.touchBeganPoint = touch:getLocation()

	return true
end

function MainLayer:onTouchMoved(touch, event)
	if self:isVisible() == false or self.gameLoginedFlag == false or self.isMainLayerShowing == false then
		return
	end

end

function MainLayer:onTouchEnded(touch, event)
	if self:isVisible() == false or self.gameLoginedFlag == false or self.isMainLayerShowing == false then
		return
	end

	local endPoint = touch:getLocation()
	local deltX = endPoint.x - self.touchBeganPoint.x
	if math.abs(deltX) >= 150 then
		if deltX > 0 then
			self:returnLogin()
		end
	end
end


function MainLayer:openLayer()
	self.isMainLayerShowing = true
	self:setVisible(true)
end


function MainLayer:closeLayer()
	self:setVisible(false)
end

return MainLayer
