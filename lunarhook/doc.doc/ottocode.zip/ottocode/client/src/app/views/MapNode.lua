
local MapUnit = import("app.views.MapUnit")
local Player = import("app.views.Player")
local Monster = import("app.views.Monster")
local MonsterFly = import("app.views.MonsterFly")
local MonsterBoss = import("app.views.MonsterBoss")
local Item = import("app.views.Item")
local GameAI = import("app.views.GameAI")

local MapNode = class("MapNode",function()
	return display.newNode()
end )

function MapNode:ctor(parent)
	self.parent = parent
	self.stageId = nil

	self.bornPoint = {x=1, y=1}
	self.stopUpdateFlag = true
	self.mapUnitList = {}
	self.monsterList = {}
	self.itemList = {}

	self.dominGroup = {}

	self.GameVictoryNeedCount = 0
	self.GameStatusCount = 0

	--item effect
	self.god_leftTime = 0
	self.bigfoot_leftTime = 0
	self.extra_life = 0
	self.bigfoot_is_next_block = false

	self.isBossStage = false
	self.waitKeyBlockAppearTimeRecord = 0
	self.bossShakeGroundTimeRecord = 0
	self.isKeyBlockShowFlag = false
	self.bossStageBlockGroup = {basic={},trap={}}

	self:initNode()
end

function MapNode:initNode()
	self.difficultType = UserDataManager.PLAYER_SETTINGS.gamespeed

	local xx = GameDefine.GROUND_BLOCK_WIDTH/2
	local yy = GameDefine.GROUND_BLOCK_HEIGHT/2


	self.groundNode = display.newNode()
	if self.groundNode == nil then
		return
	end
	self.groundNode:setAnchorPoint(cc.p(0.5,0.5))
	self.groundNode:setPosition(cc.p(0, 0))
	self:addChild(self.groundNode)

	--make ground
	self.mapUnitList = {}
	for i=1, GameDefine.MAX_GROUND_X do
		self.mapUnitList[i] = {}
		for j=1, GameDefine.MAX_GROUND_Y do
			self.mapUnitList[i][j] = MapUnit.new(self)
			if self.mapUnitList[i][j] ~= nil then
				self.mapUnitList[i][j]:setAnchorPoint(cc.p(0.5,0.5))

				local x = (i-1)*xx + (j-1)*xx
				local y = (i-1)*(0-yy) + (j-1)*yy
				self.mapUnitList[i][j]:setPosition(cc.p(x, y))
				self.groundNode:addChild(self.mapUnitList[i][j], (i-j+GameDefine.ZORDER_BASE_VALUE))
			end
		end
	end

	self.mainPlayer = Player.new(self)
	if self.mainPlayer ~= nil then
		self.mainPlayer:setAnchorPoint(cc.p(0.5,0.5))
		self.mainPlayer:setPosition(cc.p(0,0+GameDefine.GROUND_OBJ_OFFSET_Y))
		self.groundNode:addChild(self.mainPlayer, GameDefine.MAX_GROUND_X+GameDefine.MAX_GROUND_Y+GameDefine.ZORDER_BASE_VALUE)
	end

	AnimationManager.setAniToCache(ResourceDef.MONSTER_FIND_TARGET_WARNING_ANI_PARAM.res, 
								   ResourceDef.MONSTER_FIND_TARGET_WARNING_ANI_PARAM.start, 
								   ResourceDef.MONSTER_FIND_TARGET_WARNING_ANI_PARAM.count, 
								   ResourceDef.MONSTER_FIND_TARGET_WARNING_ANI_PARAM.time, 
								   "monster_find_target_warning")

	AnimationManager.setAniToCache(ResourceDef.DISAPPEAR_COVER_ANI_PARAM.res, 
								   ResourceDef.DISAPPEAR_COVER_ANI_PARAM.start, 
								   ResourceDef.DISAPPEAR_COVER_ANI_PARAM.count, 
								   ResourceDef.DISAPPEAR_COVER_ANI_PARAM.time, 
								   "disappear_cover_ani")
	AnimationManager.setAniToCache(ResourceDef.MONSTER_THUNDER_DIE_ANI_RES_PARAM.res, 
								   ResourceDef.MONSTER_THUNDER_DIE_ANI_RES_PARAM.start, 
								   ResourceDef.MONSTER_THUNDER_DIE_ANI_RES_PARAM.count, 
								   ResourceDef.MONSTER_THUNDER_DIE_ANI_RES_PARAM.time, 
								   "monster_thunder_ani")

end

function MapNode:initWithStageID(stageId, isShopMap, isTestMap, mapData)
	if stageId == nil then
		return
	end
	if isTestMap == nil then
		isTestMap = false
	end

	self.stageId = stageId
	self.difficultType = UserDataManager.PLAYER_SETTINGS.gamespeed

	local stageTblInfo = nil
	if isShopMap == true then
		stageTblInfo = UserDataManager.PLAYER_MAP_DOWNLOAD_LIST[tostring(stageId)].mapData
	elseif isTestMap == true then
		stageTblInfo = mapData
	else
		stageTblInfo = ConfigManager.stageTbl[tostring(stageId)]		
	end
	if stageTblInfo == nil or stageTblInfo.map == nil then
		return
	end

	if stageTblInfo.bossNeedHurtCount ~= nil and stageTblInfo.bossNeedHurtCount > 0 then
		self.isBossStage = true
		self.GameVictoryNeedCount = stageTblInfo.bossNeedHurtCount
		self.GameStatusCount = 0
	else
		self.GameVictoryNeedCount = 0
		self.GameStatusCount = 0
	end

	self.mapRowCnt = #stageTblInfo.map.ground
	if self.mapRowCnt > GameDefine.MAX_GROUND_X then
		self.mapRowCnt = GameDefine.MAX_GROUND_X
	end
	self.mapColumnCnt = #stageTblInfo.map.ground[1]
	if self.mapColumnCnt > GameDefine.MAX_GROUND_Y then
		self.mapColumnCnt = GameDefine.MAX_GROUND_Y
	end

	local base_zorder = GameDefine.MAX_GROUND_X + GameDefine.MAX_GROUND_Y + GameDefine.ZORDER_BASE_VALUE

	if stageTblInfo.map.born ~= nil then
		self.bornPoint.x = stageTblInfo.map.born.x
		self.bornPoint.y = stageTblInfo.map.born.y

		if self.mainPlayer ~= nil then
			self.mainPlayer:setPositionX(self.mapUnitList[self.bornPoint.x][self.bornPoint.y]:getPositionX())
			self.mainPlayer:setPositionY(self.mapUnitList[self.bornPoint.x][self.bornPoint.y]:getPositionY() + GameDefine.GROUND_OBJ_OFFSET_Y)
			self.mainPlayer:setMapPosition({x=self.bornPoint.x, y=self.bornPoint.y})
			self.mainPlayer:setLocalZOrder(base_zorder + self:calcCharacterZorderAddValue(self.bornPoint.x, self.bornPoint.y))
		end

		self.groundNode:setPositionX(0-self.mapUnitList[self.bornPoint.x][self.bornPoint.y]:getPositionX())
		self.groundNode:setPositionY(0-self.mapUnitList[self.bornPoint.x][self.bornPoint.y]:getPositionY())
	end

	self.bossStageBlockGroup = {basic={},trap={}}

	local tmpCacheMap = {}
	if stageTblInfo.map.ground ~= nil then
		for k,v in pairs(stageTblInfo.map.ground) do
			if k <= GameDefine.MAX_GROUND_X then
				for kk,zz in pairs(v) do
					local vv = math.fmod(math.abs(zz), 1000)
					local dominId = math.floor(math.abs(zz) / 1000)
					local showFlag = (zz >= 0)

					if vv ~= 0 then
						if tmpCacheMap[tostring(vv)] == nil then
							tmpCacheMap[tostring(vv)] = true
							local mapBlockTblInfo = ConfigManager.mapBlockTbl[tostring(vv)]
							if mapBlockTblInfo ~= nil then
								AnimationManager.setAniToCache(	mapBlockTblInfo.res, 
																mapBlockTblInfo.animation.start, 
																mapBlockTblInfo.animation.count, 
																mapBlockTblInfo.animation.time / mapBlockTblInfo.animation.count, 
																GameDefine.MAP_BLOCK_ANIMATION_PREFIX .. tostring(mapBlockTblInfo.id))
							end
						end
					end

					if kk <= GameDefine.MAX_GROUND_Y then
						local mapBlockTblInfo = ConfigManager.mapBlockTbl[tostring(vv)]
						if mapBlockTblInfo ~= nil and mapBlockTblInfo.id ~= nil and mapBlockTblInfo.id > 0 then
							if dominId > 0 then
								if self.dominGroup[tostring(dominId)] == nil then
									self.dominGroup[tostring(dominId)] = {}
								end
								if mapBlockTblInfo.type ~= GameDefine.GROUND_BLOCK_TYPE.SHOW_HIDE then
									table.insert(self.dominGroup[tostring(dominId)], self.mapUnitList[k][kk])
								end
							end

							self.mapUnitList[k][kk]:reset()

							if self.isBossStage == true then
								self.mapUnitList[k][kk]:initWithData(mapBlockTblInfo, dominId, true)
								if showFlag == true then
									if mapBlockTblInfo.type ~= GameDefine.GROUND_BLOCK_TYPE.ICE then
										table.insert(self.bossStageBlockGroup.basic, {k,kk})
									end
								else
									table.insert(self.bossStageBlockGroup.trap, {k,kk})
								end
							else
								self.mapUnitList[k][kk]:initWithData(mapBlockTblInfo, dominId, showFlag)
								self.GameVictoryNeedCount = self.GameVictoryNeedCount + 1
								if mapBlockTblInfo.target == 0 then
									self:addVictoryCount()
								end
							end
						end
					end
				end
			end
		end
	end

	if self.isBossStage == true then
		if tmpCacheMap[tostring(GameConfig.BOSS_STAGE_KEY_BLOCK_ID)] == nil then
			tmpCacheMap[tostring(GameConfig.BOSS_STAGE_KEY_BLOCK_ID)] = true
			local mapBlockTblInfo = ConfigManager.mapBlockTbl[tostring(GameConfig.BOSS_STAGE_KEY_BLOCK_ID)]
			if mapBlockTblInfo ~= nil then
				AnimationManager.setAniToCache(	mapBlockTblInfo.res, 
												mapBlockTblInfo.animation.start, 
												mapBlockTblInfo.animation.count, 
												mapBlockTblInfo.animation.time / mapBlockTblInfo.animation.count, 
												GameDefine.MAP_BLOCK_ANIMATION_PREFIX .. tostring(mapBlockTblInfo.id))
			end
		end
	end

	self.monsterList = {}
	if stageTblInfo.map.monster ~= nil then
		for k,v in pairs(stageTblInfo.map.monster) do
			local monsterInfoTbl = ConfigManager.monsterTbl[tostring(k)]
			if monsterInfoTbl ~= nil then
				for kk,vv in pairs(v) do
					local targetIndex = #self.monsterList + 1
					if monsterInfoTbl.type == GameDefine.MONSTER_TYPE.FLY then
						self.monsterList[targetIndex] = MonsterFly.new(tonumber(k), self, vv.dir, targetIndex)
						if self.monsterList[targetIndex] ~= nil then
							self.monsterList[targetIndex]:setAnchorPoint(cc.p(0.5,0.5))

							local x = (vv.x-1)*GameDefine.GROUND_BLOCK_WIDTH/2 + (vv.y-1)*GameDefine.GROUND_BLOCK_WIDTH/2
							local y = (vv.x-1)*(0-GameDefine.GROUND_BLOCK_HEIGHT/2) + (vv.y-1)*GameDefine.GROUND_BLOCK_HEIGHT/2

							self.monsterList[targetIndex]:setPositionX(x)
							self.monsterList[targetIndex]:setPositionY(y + GameDefine.GROUND_OBJ_OFFSET_Y)
							self.groundNode:addChild(self.monsterList[targetIndex], base_zorder + self:calcCharacterZorderAddValue(vv.x, vv.y) - 1)

							self.monsterList[targetIndex]:setMapPosition({x=vv.x, y=vv.y})
							self.monsterList[targetIndex].initPos = {x=vv.x, y=vv.y}
						end
					else
						self.monsterList[targetIndex] = Monster.new(tonumber(k), self, targetIndex)
						if self.monsterList[targetIndex] ~= nil then
							self.monsterList[targetIndex]:setAnchorPoint(cc.p(0.5,0.5))
							self.monsterList[targetIndex]:setPositionX(self.mapUnitList[vv.x][vv.y]:getPositionX())
							self.monsterList[targetIndex]:setPositionY(self.mapUnitList[vv.x][vv.y]:getPositionY() + GameDefine.GROUND_OBJ_OFFSET_Y)
							self.groundNode:addChild(self.monsterList[targetIndex], base_zorder + self:calcCharacterZorderAddValue(vv.x, vv.y) - 1)

							self.monsterList[targetIndex]:setMapPosition({x=vv.x, y=vv.y})
							self.monsterList[targetIndex].needReviveFlag = true
							self.monsterList[targetIndex].initPos = {x=vv.x, y=vv.y}
						end
					end
				end
			end
		end
	end

	if self.isBossStage == true then
		self.monsterBoss = MonsterBoss.new(self)
		if self.monsterBoss ~= nil then
			self.monsterBoss:setPositionX(self.mapUnitList[self.bornPoint.x][self.bornPoint.y]:getPositionX())
			self.monsterBoss:setPositionY(self.mapUnitList[self.bornPoint.x][self.bornPoint.y]:getPositionY())
			self.groundNode:addChild(self.monsterBoss, base_zorder + 1000)
		end
	end

	self.itemList = {}
	if stageTblInfo.map.item ~= nil then
		for k,v in pairs(stageTblInfo.map.item) do
			for kk,vv in pairs(v) do
				if self.mapUnitList[vv.x][vv.y] ~= nil then
					local targetIndex = vv.x * 100 + vv.y
					self.itemList[targetIndex] = Item.new(tonumber(k))
					if self.itemList[targetIndex] ~= nil then
						self.itemList[targetIndex]:setAnchorPoint(cc.p(0.5,0.5))
						self.itemList[targetIndex]:setPositionX(self.mapUnitList[vv.x][vv.y]:getPositionX())
						self.itemList[targetIndex]:setPositionY(self.mapUnitList[vv.x][vv.y]:getPositionY() + GameDefine.GROUND_OBJ_OFFSET_Y)
						self.groundNode:addChild(self.itemList[targetIndex], base_zorder + self:calcCharacterZorderAddValue(vv.x, vv.y) - 1)
						self.itemList[targetIndex]:setMapPosition({x=vv.x, y=vv.y})
					end
				end
			end
		end
	end

	self.gameAI = nil
	if isShopMap == false and isTestMap == false then
		self.gameAI = GameAI.new(self, stageTblInfo.aiIDList)
	else
		--自己做的地图的场景ai定义
		self.gameAI = GameAI.new(self, GameConfig.USER_MAKE_MAP_SCENE_AI_LIST)
	end

end

function MapNode:update(t)
	if self.stopUpdateFlag == true then
		return
	end

	if self.gameAI ~= nil then
		self.gameAI:update(t)
	end

	if self.mainPlayer ~= nil and self.mainPlayer.update ~= nil then
		self.mainPlayer:update(t)
	end

	if self.monsterList ~= nil and type(self.monsterList) == "table" then
		for k,v in pairs(self.monsterList) do
			if v.update ~= nil then
				v:update(t)
			end
		end
	end

	if self.isBossStage == true then
		if self.monsterBoss ~= nil and self.monsterBoss.update ~= nil then
			self.monsterBoss:update(t)
		end
	end

	if self.itemList ~= nil and type(self.itemList) == "table" then
		for k,v in pairs(self.itemList) do
			if v.update ~= nil then
				v:update(t)
			end
		end
	end

	if self.isBossStage == true then
		if self.isKeyBlockShowFlag == false then
			self.waitKeyBlockAppearTimeRecord = self.waitKeyBlockAppearTimeRecord + t
			if self.waitKeyBlockAppearTimeRecord >= GameConfig.WAIT_KEY_BLOCK_APPEAR_NEED_TIME then
				self.waitKeyBlockAppearTimeRecord = 0
				self.isKeyBlockShowFlag = self:bossStageMakeKeyBlock()
			end
		end

		self.bossShakeGroundTimeRecord = self.bossShakeGroundTimeRecord + t 
		if self.bossShakeGroundTimeRecord >= GameConfig.BOSS_STAGE_SHAKE_GROUND_TIME_INTERNAL then
			self.bossShakeGroundTimeRecord = self.bossShakeGroundTimeRecord - GameConfig.BOSS_STAGE_SHAKE_GROUND_TIME_INTERNAL
			self:bossShakeMap() 
		end
	end

	if self.god_leftTime > 0 then
		self.god_leftTime = self.god_leftTime - t
		if self.god_leftTime < 0 then
			self.god_leftTime = 0
			if self.mainPlayer ~= nil and self.mainPlayer.playerHeadLabel ~= nil then
				self.mainPlayer.playerHeadLabel:setString("")
			end
			if self.mainPlayer ~= nil and self.mainPlayer.playerHeadPic ~= nil then
		    	local tpPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
		    	if tpPic ~= nil then
		    		self.mainPlayer.playerHeadPic:setSpriteFrame(tpPic:getSpriteFrame())
		    	end
			end

			-- if self.mainPlayer.ItemStateEffectPic ~= nil then
			-- 	local tpFrame = nil
			-- 	if self.extra_life > 0 then
			-- 		tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.ITEM_EFFECT_PIC_SHIELD))
			-- 	else
			-- 		local tpPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
			--     	if tpPic ~= nil then
			--     		tpFrame = tpPic:getSpriteFrame()
			--     	end
			-- 	end
			-- 	if tpFrame ~= nil then
		 --    		self.mainPlayer.ItemStateEffectPic:setSpriteFrame(tpFrame)
		 --    	end
			-- end

			if self.parent.playingClockSoundEffectId ~= nil then
                AudioManager.stopEffect(self.parent.playingClockSoundEffectId)
                self.parent.playingClockSoundEffectId = nil
            end
		else
			if self.mainPlayer ~= nil and self.mainPlayer.playerHeadLabel ~= nil then
				self.mainPlayer.playerHeadLabel:setString(tostring(math.ceil(self.god_leftTime)))
			end
		end
	end
	if self.bigfoot_leftTime > 0 then
		self.bigfoot_leftTime = self.bigfoot_leftTime - t
		if self.bigfoot_leftTime < 0 then
			self.bigfoot_leftTime = 0
			if self.mainPlayer ~= nil and self.mainPlayer.playerHeadLabel ~= nil then
				self.mainPlayer.playerHeadLabel:setString("")
			end
			if self.mainPlayer ~= nil and self.mainPlayer.playerHeadPic ~= nil then
		    	local tpPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
		    	if tpPic ~= nil then
		    		self.mainPlayer.playerHeadPic:setSpriteFrame(tpPic:getSpriteFrame())
		    	end
			end
			if self.parent.playingClockSoundEffectId ~= nil then
                AudioManager.stopEffect(self.parent.playingClockSoundEffectId)
                self.parent.playingClockSoundEffectId = nil
            end
		else
			if self.mainPlayer ~= nil and self.mainPlayer.playerHeadLabel ~= nil then
				self.mainPlayer.playerHeadLabel:setString(tostring(math.ceil(self.bigfoot_leftTime)))
			end
		end
	end
end

function MapNode:bossStageMakeKeyBlock()
	--todo
	if self.isKeyBlockShowFlag == true then
		return true
	end

	local cnt = #self.bossStageBlockGroup.basic
	if cnt <= 0 then
		return false
	end

	local dstIndex = math.random(1, cnt)
	local dstRowIdx = self.bossStageBlockGroup.basic[dstIndex][1]
	local dstColumnIdx = self.bossStageBlockGroup.basic[dstIndex][2]

	if self.mapUnitList == nil or
	   self.mapUnitList[dstRowIdx] == nil or
	   self.mapUnitList[dstRowIdx][dstColumnIdx] == nil or
	   self.mapUnitList[dstRowIdx][dstColumnIdx].id == 0 then
		return false
	end

	if self.mapUnitList[dstRowIdx][dstColumnIdx]:change2BossKeyBlock() == true then
		return true
	end

	return false
end

function MapNode:bossShakeMap()
	if self.monsterBoss == nil or self.monsterBoss.playShakeAni == nil then
		return
	end

	local cnt = #self.bossStageBlockGroup.trap
	if cnt <= 0 then
		return
	end
	local dstIndex = math.random(1, cnt)
	local dstRowIdx = self.bossStageBlockGroup.trap[dstIndex][1]
	local dstColumnIdx = self.bossStageBlockGroup.trap[dstIndex][2]

	if self.mapUnitList == nil or
	   self.mapUnitList[dstRowIdx] == nil or
	   self.mapUnitList[dstRowIdx][dstColumnIdx] == nil or
	   self.mapUnitList[dstRowIdx][dstColumnIdx].id == 0 then
		return
	end

	self.monsterBoss:playShakeAni(function()
		self.mapUnitList[dstRowIdx][dstColumnIdx]:fall()
	end)

end

function MapNode:hurtBoss()
	self:addVictoryCount()

	self.bossShakeGroundTimeRecord = 0
	self:playBossBeHurtAni()

	if self:checkVictory() == true then
		self.stopUpdateFlag = true

		self:runAction(cc.Sequence:create(
			cc.DelayTime:create(1),
			cc.CallFunc:create(
				function()
					if self.mainPlayer ~= nil then
						self.mainPlayer:showWinAni()
					end
				end
			),
			cc.DelayTime:create(1),
			cc.CallFunc:create(
				function()
					self.parent:GameEnd(true)
				end)
			)
		)
	end
end

function MapNode:playBossBeHurtAni()
	--todo



end

function MapNode:addNewMonster(monsterId, posX, posY, needRevive)
	if needRevive == nil then
		needRevive = false
	end

	if monsterId == nil or posX == nil or posY == nil then
		return
	end

	local monsterInfoTbl = ConfigManager.monsterTbl[tostring(monsterId)]
	if monsterInfoTbl == nil then
		return
	end

	if monsterInfoTbl.type == GameDefine.MONSTER_TYPE.FLY then
		return
	end

	posX, posY = self:findRightPostion(posX, posY)
	if posX == nil or posY == nil then
		return
	end

	if self.mapUnitList == nil or
	   self.mapUnitList[posX] == nil or
	   self.mapUnitList[posX][posY] == nil or
	   self.mapUnitList[posX][posY].id == 0 then
		return
	end

	local playerMapPos = self.mainPlayer:getMapPosition()
	if math.abs(playerMapPos.x - posX) <= 1 and math.abs(playerMapPos.y - posY) <= 1 then
		return
	end

	local base_zorder = GameDefine.MAX_GROUND_X + GameDefine.MAX_GROUND_Y + GameDefine.ZORDER_BASE_VALUE
	local targetIndex = #self.monsterList + 1
	self.monsterList[targetIndex] = Monster.new(tonumber(monsterId), self, targetIndex)
	if self.monsterList[targetIndex] ~= nil then
		self.monsterList[targetIndex]:setAnchorPoint(cc.p(0.5,0.5))
		self.monsterList[targetIndex]:setPositionX(self.mapUnitList[posX][posY]:getPositionX())
		self.monsterList[targetIndex]:setPositionY(self.mapUnitList[posX][posY]:getPositionY() + GameDefine.GROUND_OBJ_OFFSET_Y)
		self.groundNode:addChild(self.monsterList[targetIndex], base_zorder + self:calcCharacterZorderAddValue(posX, posY) - 1)
		self.monsterList[targetIndex]:setMapPosition({x=posX, y=posY})
		self.monsterList[targetIndex].needReviveFlag = needRevive
		self.monsterList[targetIndex].initPos = {x=posX, y=posY}
		self.monsterList[targetIndex]:appear()
	end

end

function MapNode:addNewFlyMonster(monsterId, posX, posY, dir)
	if monsterId == nil or posX == nil or posY == nil then
		return
	end
	if dir == nil or dir < GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_TOP or dir > GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_BOTTOM then
		return
	end

	local monsterInfoTbl = ConfigManager.monsterTbl[tostring(monsterId)]
	if monsterInfoTbl == nil then
		return
	end
	
	local base_zorder = GameDefine.MAX_GROUND_X + GameDefine.MAX_GROUND_Y + GameDefine.ZORDER_BASE_VALUE
	local targetIndex = #self.monsterList + 1
	if monsterInfoTbl.type == GameDefine.MONSTER_TYPE.FLY then
		self.monsterList[targetIndex] = MonsterFly.new(tonumber(monsterId), self, dir, targetIndex)
		if self.monsterList[targetIndex] ~= nil then
			self.monsterList[targetIndex]:setAnchorPoint(cc.p(0.5,0.5))

			local x = (posX-1)*GameDefine.GROUND_BLOCK_WIDTH/2 + (posY-1)*GameDefine.GROUND_BLOCK_WIDTH/2
			local y = (posX-1)*(0-GameDefine.GROUND_BLOCK_HEIGHT/2) + (posY-1)*GameDefine.GROUND_BLOCK_HEIGHT/2

			self.monsterList[targetIndex]:setPositionX(x)
			self.monsterList[targetIndex]:setPositionY(y + GameDefine.GROUND_OBJ_OFFSET_Y)
			self.groundNode:addChild(self.monsterList[targetIndex], base_zorder + self:calcCharacterZorderAddValue(posX, posY) - 1)

			self.monsterList[targetIndex]:setMapPosition({x=posX, y=posY})
			self.monsterList[targetIndex]:appear()
		end
	end
end

function MapNode:addNewItem(itemId, posX, posY, keepTime)
	if itemId == nil or posX == nil or posY == nil then
		return
	end

	posX, posY = self:findRightPostion(posX, posY)
	if posX == nil or posY == nil then
		return
	end

	if self.mapUnitList == nil or
	   self.mapUnitList[posX] == nil or
	   self.mapUnitList[posX][posY] == nil or
	   self.mapUnitList[posX][posY].id == 0 then
		return
	end

	local targetIndex = posX * 100 + posY
	local reuseFlag = false
	if self.itemList[targetIndex] ~= nil then
		if self.itemList[targetIndex].enable == true then
			return
		else
			reuseFlag = true
			self.itemList[targetIndex]:reuse(itemId, keepTime, {x=posX,y=posY})
		end
	else
		self.itemList[targetIndex] = Item.new(itemId, keepTime)
	end
	if self.itemList[targetIndex] ~= nil then
		self.itemList[targetIndex]:setAnchorPoint(cc.p(0.5,0.5))
		self.itemList[targetIndex]:setPositionX(self.mapUnitList[posX][posY]:getPositionX())
		self.itemList[targetIndex]:setPositionY(self.mapUnitList[posX][posY]:getPositionY() + GameDefine.GROUND_OBJ_OFFSET_Y)
		local base_zorder = GameDefine.MAX_GROUND_X + GameDefine.MAX_GROUND_Y + GameDefine.ZORDER_BASE_VALUE
		if reuseFlag == true then
			self.itemList[targetIndex]:setLocalZOrder(base_zorder + self:calcCharacterZorderAddValue(posX, posY) - 1)
		else
			self.groundNode:addChild(self.itemList[targetIndex], base_zorder + self:calcCharacterZorderAddValue(posX, posY) - 1)
		end
		self.itemList[targetIndex]:setMapPosition({x=posX, y=posY})
	end

end

function MapNode:findRightPostion(x, y)
	if x == nil or y == nil then
		return nil, nil
	end
	if x > 0 and y > 0 then
		return x, y
	end

	if x == 0 and y == 0 then
		local randVal = math.random(1, self.GameVictoryNeedCount)
		local tmpVal = 0
		local cycleIdx = 0
		while(true)
		do
			cycleIdx = cycleIdx + 1
			for i=1, GameDefine.MAX_GROUND_X do
				if self.mapUnitList[i] ~= nil then
					for j=1, GameDefine.MAX_GROUND_Y do
						if self.mapUnitList[i][j] ~= nil then
							if self.mapUnitList[i][j].id ~= 0 and self.mapUnitList[i][j].showFlag == true then
								tmpVal = tmpVal + 1
								if tmpVal == randVal then
									return i, j
								end
							end
						end
					end
				end
			end
			if cycleIdx >= 5 then
				break
			end
		end
	elseif x == 0 then
		local randVal = math.random(1, GameDefine.MAX_GROUND_X)
		local tmpVal = 0
		local cycleIdx = 0
		while(true)
		do
			cycleIdx = cycleIdx + 1
			for i=1, GameDefine.MAX_GROUND_X do
				if self.mapUnitList[i] ~= nil then
					if self.mapUnitList[i][y] ~= nil then
						if self.mapUnitList[i][y].id ~= 0 then
							tmpVal = tmpVal + 1
							if tmpVal == randVal then
								return i, y
							end
						end
					end
				else
					break
				end
			end
			if cycleIdx >= 5 then
				break
			end
		end
	elseif y == 0 then
		local randVal = math.random(1, GameDefine.MAX_GROUND_Y)
		local tmpVal = 0
		local cycleIdx = 0
		while(true)
		do
			cycleIdx = cycleIdx + 1
			for i=1, GameDefine.MAX_GROUND_Y do
				if self.mapUnitList[x] ~= nil then
					if self.mapUnitList[x][i] ~= nil then
						if self.mapUnitList[x][i].id ~= 0 then
							tmpVal = tmpVal + 1
							if tmpVal == randVal then
								return x, i
							end
						end
					end
				else
					break
				end
			end
			if cycleIdx >= 5 then
				break
			end
		end
	end
	
	return nil, nil
end

function MapNode:addVictoryCount()
	self.GameStatusCount = self.GameStatusCount + 1
end

function MapNode:calcCharacterZorderAddValue(mapPosX, mapPosY)
	local val = mapPosX + self.mapColumnCnt + 1 - mapPosY 
	return val
end

function MapNode:checkGroundIsIce()
	if self.mainPlayer == nil then
		return false
	end

	local playerMapPos = self.mainPlayer:getMapPosition()
	if self.mapUnitList[playerMapPos.x] == nil or self.mapUnitList[playerMapPos.x][playerMapPos.y] == nil or self.mapUnitList[playerMapPos.x][playerMapPos.y].id == 0 then
		return false
	end

	local mapBlockTbl = ConfigManager.mapBlockTbl[tostring(self.mapUnitList[playerMapPos.x][playerMapPos.y].id)]
	if mapBlockTbl ~= nil and mapBlockTbl.type ~= nil and mapBlockTbl.type == GameDefine.GROUND_BLOCK_TYPE.ICE then
		return true
	end

	return false
end

function MapNode:checkFall(character)
	if character == nil then
		return true
	end

	local characterMapPos = character:getMapPosition()
	if characterMapPos.x <= 0 or characterMapPos.y > GameDefine.MAX_GROUND_Y then
		character:setLocalZOrder(0)
		return true
	end

	if characterMapPos.y <= 0 or characterMapPos.x > GameDefine.MAX_GROUND_X then
		character:setLocalZOrder(GameDefine.MAX_GROUND_X+GameDefine.MAX_GROUND_Y+GameDefine.ZORDER_BASE_VALUE)
		return true
	end

	if self.mapUnitList[characterMapPos.x] == nil or self.mapUnitList[characterMapPos.x][characterMapPos.y] == nil then
		return true
	end

	if self.mapUnitList[characterMapPos.x][characterMapPos.y].id == 0 then
		character:setLocalZOrder(characterMapPos.x-characterMapPos.y+GameDefine.ZORDER_BASE_VALUE)
		return true
	end

	if self.mapUnitList[characterMapPos.x][characterMapPos.y].showFlag == false then
		character:setLocalZOrder(characterMapPos.x-characterMapPos.y+GameDefine.ZORDER_BASE_VALUE)
		return true
	end

	return false
end

function MapNode:checkFallByMapPosition(pos)
	if pos == nil or pos.x == nil or pos.y == nil then
		return true
	end

	if pos.x <= 0 or pos.y > GameDefine.MAX_GROUND_Y or pos.y <= 0 or pos.x > GameDefine.MAX_GROUND_X then
		return true
	end

	if self.mapUnitList[pos.x] == nil or self.mapUnitList[pos.x][pos.y] == nil then
		return true
	end

	if self.mapUnitList[pos.x][pos.y].id == 0 then
		return true
	end

	if self.mapUnitList[pos.x][pos.y].showFlag == false then
		return true
	end 

	return false
end

function MapNode:checkMeeting()
	if self.mainPlayer == nil then
		return true
	end

	local playerPosNumber = self.mainPlayer:getMapPosition().x * 100 + self.mainPlayer:getMapPosition().y

	if self.protectPosNumber ~= nil then
		if self.protectPosNumber == playerPosNumber then
			return false
		else
			self.protectPosNumber = nil
		end
	end

	--check monster
	for k,v in pairs(self.monsterList) do
		if v.isAlive == true then
			if self.protectPosNumber == nil or self.protectPosNumber ~= playerPosNumber then
				local monsterPosNumber = v:getMapPosition().x * 100 + v:getMapPosition().y
				if monsterPosNumber == playerPosNumber then
					if self.god_leftTime <= 0 then
						if self.extra_life <= 0 then
							self.mainPlayer:beCaught()
							return true
						else
							self.extra_life = self.extra_life - 1
							self.protectPosNumber = playerPosNumber

							if self.extra_life <= 0 then
								if self.mainPlayer.ItemStateEffectPic ~= nil then
									local tpPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
							    	if tpPic ~= nil then
							    		self.mainPlayer.ItemStateEffectPic:setSpriteFrame(tpPic:getSpriteFrame())
							    	end
								end
							end

							--
							v:die()
						end
					else
						v:die()
					end
				end
			end
		end
	end

	return false
end

function MapNode:checkItemPicking()
	if self.mainPlayer == nil then
		return true
	end

	local playerPosNumber = self.mainPlayer:getMapPosition().x * 100 + self.mainPlayer:getMapPosition().y

	--check item
	for k,v in pairs(self.itemList) do
		if v.enable == true then
			local itemPosNumber = v:getMapPosition().x * 100 + v:getMapPosition().y
			if itemPosNumber == playerPosNumber then
				v:beGot()
			end
		end
	end

	return false
end

function MapNode:changeGround()
	if self.mainPlayer == nil then
		return
	end

	local playerMapPos = self.mainPlayer:getMapPosition()
	if self.mapUnitList[playerMapPos.x] == nil or self.mapUnitList[playerMapPos.x][playerMapPos.y] == nil or self.mapUnitList[playerMapPos.x][playerMapPos.y].id == 0 then
		return
	end

	if self.isBossStage == true then
		if self.mapUnitList[playerMapPos.x][playerMapPos.y].id == GameConfig.BOSS_STAGE_KEY_BLOCK_ID then
			self.mapUnitList[playerMapPos.x][playerMapPos.y]:checkAndChangeGround(true)
			self:hurtBoss()
		end
		return
	end

	self.mapUnitList[playerMapPos.x][playerMapPos.y]:checkAndChangeGround(true)
	
	if self.bigfoot_leftTime > 0 then
		self.mapUnitList[playerMapPos.x][playerMapPos.y]:playShakeAction(false)
		if self.bigfoot_is_next_block == true then
			if self.mapUnitList[playerMapPos.x+1] ~= nil and self.mapUnitList[playerMapPos.x+1][playerMapPos.y] ~= nil and self.mapUnitList[playerMapPos.x+1][playerMapPos.y].id ~= 0 then
				self.mapUnitList[playerMapPos.x+1][playerMapPos.y]:checkAndChangeGround()
				self.mapUnitList[playerMapPos.x+1][playerMapPos.y]:playShakeAction(true)
			end
			if self.mapUnitList[playerMapPos.x-1] ~= nil and self.mapUnitList[playerMapPos.x-1][playerMapPos.y] ~= nil and self.mapUnitList[playerMapPos.x-1][playerMapPos.y].id ~= 0 then
				self.mapUnitList[playerMapPos.x-1][playerMapPos.y]:checkAndChangeGround()
				self.mapUnitList[playerMapPos.x-1][playerMapPos.y]:playShakeAction(true)
			end
			if self.mapUnitList[playerMapPos.x] ~= nil and self.mapUnitList[playerMapPos.x][playerMapPos.y+1] ~= nil and self.mapUnitList[playerMapPos.x][playerMapPos.y+1].id ~= 0 then
				self.mapUnitList[playerMapPos.x][playerMapPos.y+1]:checkAndChangeGround()
				self.mapUnitList[playerMapPos.x][playerMapPos.y+1]:playShakeAction(true)
			end
			if self.mapUnitList[playerMapPos.x] ~= nil and self.mapUnitList[playerMapPos.x][playerMapPos.y-1] ~= nil and self.mapUnitList[playerMapPos.x][playerMapPos.y-1].id ~= 0 then
				self.mapUnitList[playerMapPos.x][playerMapPos.y-1]:checkAndChangeGround()
				self.mapUnitList[playerMapPos.x][playerMapPos.y-1]:playShakeAction(true)
			end
		else
			self.bigfoot_is_next_block = true
		end
	end

	if self.stopUpdateFlag == true then
		return
	end

	if self:checkVictory() == true then
		self.stopUpdateFlag = true
		self.parent:GameEnd(true)
	end
end

function MapNode:showHideGroundBlocks(dominId)
	if dominId == nil or dominId <= 0 then
		return
	end

	local dominIdStr = tostring(dominId)
	if self.dominGroup[dominIdStr] == nil then
		return
	end

	for i=1, #self.dominGroup[dominIdStr] do
		self.dominGroup[dominIdStr][i]:changeShowHideByDomin(dominId)
	end

end

function MapNode:checkVictory()
	return (self.GameStatusCount >= self.GameVictoryNeedCount)
end

function MapNode:gameFailed()
	if self.isBossStage == true then
		if self.monsterBoss ~= nil then
			self.monsterBoss:playWin()
		end
	end
	self.parent:GameEnd(false)
end

function MapNode:allMonsterDisappear()
	if self.monsterList ~= nil and type(self.monsterList) == "table" then
		for k,v in pairs(self.monsterList) do
			if v.die ~= nil then
				v:die()
			end
		end
	end
end

function MapNode:allItemDisappear()
	if self.itemList ~= nil and type(self.itemList) == "table" then
		for k,v in pairs(self.itemList) do
			if v.disappear ~= nil then
				v:disappear()
			end
		end
	end
end

function MapNode:syncMove2MakePlayerCenter(movex, movey)
	if self.groundNode == nil then
		return
	end

	self.groundNode:setPositionX(self.groundNode:getPositionX() + movex)
	self.groundNode:setPositionY(self.groundNode:getPositionY() + movey)
end

function MapNode:reset()
	if self.mainPlayer ~= nil then
		self.mainPlayer:reset()
	end

	for k,v in pairs(self.monsterList) do
		v:removeFromParent(true)
		self.monsterList[k] = nil
	end
	self.monsterList = {}

	if self.monsterBoss ~= nil then
		self.monsterBoss:removeFromParent(true)
		self.monsterBoss = nil
	end

	for k,v in pairs(self.itemList) do
		v:removeFromParent(true)
		self.itemList[k] = nil
	end
	self.itemList = {}

	for k,v in pairs(self.mapUnitList) do
		for kk,vv in pairs(v) do
			vv:reset()
		end
	end

	self.dominGroup = {}

	self.GameVictoryNeedCount = 0
	self.GameStatusCount = 0

	self.god_leftTime = 0
	self.bigfoot_leftTime = 0
	self.extra_life = 0
	self.bigfoot_is_next_block = false

	self.isBossStage = false
	self.bossNeedHurtCount = 0
	self.waitKeyBlockAppearTimeRecord = 0
	self.bossShakeGroundTimeRecord = 0
	self.isKeyBlockShowFlag = false
	self.bossStageBlockGroup = {basic={},trap={}}
end

function MapNode:addItemEffectShow(itemInfo)
	if itemInfo == nil or itemInfo.item_type == nil then
		return
	end

	if itemInfo.item_type == GameDefine.ITEM_TYPE.MAGIC_BALL then
		return  -- no need effect
	end

	if itemInfo.item_type == GameDefine.ITEM_TYPE.THUNDER then
		--

	else
		if self.mainPlayer ~= nil and self.mainPlayer.addItemEffectShow ~= nil then
			self.mainPlayer:addItemEffectShow(itemInfo)
		end
	end
end

function MapNode:killAllMonster()
	if self.parent ~= nil and self.parent.playSceneThunderEffect ~= nil then
		self.parent:playSceneThunderEffect()
	end

	local tpIdx = 1
	for k,v in pairs(self.monsterList) do
		v:beKilled(tpIdx)
		tpIdx = tpIdx + 1
	end

end

function MapNode:monstersWin()
	for k,v in pairs(self.monsterList) do
		v:win()
	end
end

function MapNode:WinImmediately()
	self.stopUpdateFlag = true
	for k,v in pairs(self.mapUnitList) do
		for kk,vv in pairs(v) do
			vv:change2FinalGround()
		end
	end

	self:runAction(cc.Sequence:create(
		cc.DelayTime:create(0.5),
		cc.CallFunc:create(
			function()
				if self.mainPlayer ~= nil then
					self.mainPlayer:showWinAni()
				end
			end
		),
		cc.DelayTime:create(1),
		cc.CallFunc:create(
			function()
				if self:checkVictory() == true then
					self.parent:GameEnd(true)
				end
			end)
		)
	)
end

return MapNode
