local GameControlButton = import("app.views.GameControlButton")

local MyMakeCell = class("MyMakeCell",function()
	return display.newNode()
end )

function MyMakeCell:ctor(parent)
	self.parent = parent

	self:init()
end

function MyMakeCell:init()
	--bgs 
	local layerSize = {width=420, height=170}
	local bgLayer = cc.LayerColor:create(cc.c4b(174,138,90,255), layerSize.width, layerSize.height)
	if bgLayer ~= nil then
		bgLayer:setAnchorPoint(cc.p(0,0))
		bgLayer:setPosition(cc.p(0, 0))
		self:addChild(bgLayer, 1)
	end
	local layerSize2 = {width=410, height=160}
	local bgLayer2 = cc.LayerColor:create(cc.c4b(250,205,137,255), layerSize2.width, layerSize2.height)
	if bgLayer2 ~= nil then
		bgLayer2:setAnchorPoint(cc.p(0,0))
		bgLayer2:setPosition(cc.p(5, 5))
		self:addChild(bgLayer2, 2)
	end

	local layerSize3 = {width=150, height=150}
	local bgLayer3_L = cc.LayerColor:create(cc.c4b(174,138,90,255), layerSize3.width, layerSize3.height)
	if bgLayer3_L ~= nil then
		bgLayer3_L:setAnchorPoint(cc.p(0,0))
		bgLayer3_L:setPosition(cc.p(15, 10))
		self:addChild(bgLayer3_L, 3)
	end

	--main pic
	self.mainPic = display.newSprite(ResourceManager.ImageName(ResourceDef.DEFAULT_SHOP_MAP_PIC))
	if self.mainPic ~= nil then
		self.mainPic:setAnchorPoint(cc.p(0.5,0.5))
		self.mainPic:setPosition(cc.p(15+layerSize3.width/2, 10+layerSize3.height/2))
		self:addChild(self.mainPic, 5)
	end

	--maker name
	self.makerTime = display.newTTFLabel({
        text = "",
        font = ResourceDef.FONT_GAME_MAIN,
        size = 20,
        align = cc.TEXT_ALIGNMENT_CENTER,
        color = cc.c3b(90,45,3)
    })
    if self.makerTime ~= nil then
        self.makerTime:setAnchorPoint(cc.p(0.5,0.5))
        self.makerTime:setPosition(cc.p(300, 140))
        self:addChild(self.makerTime, 5)
    end

    --test button
	self.testBtn = GameControlButton.new({
        btnBg = ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[7],
        dstSize = {width=100, height=45},
        buttonFont = LangStringDefine.TEST_LABEL,
		buttonFontSize = 22,
		buttonFontColor = cc.c3b(90,45,3),
        callback = function ()
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
        	self:testMap()
        end
    })
    if self.testBtn ~= nil then
		self.testBtn:setAnchorPoint(cc.p(0.5, 0.5))
		self.testBtn:setPosition(cc.p(240,80))
	    self:addChild(self.testBtn, 5)
	end

	--modify button
	self.modifyBtn = GameControlButton.new({
        btnBg = ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[7],
        dstSize = {width=100, height=45},
        buttonFont = LangStringDefine.MODIFY_LABEL,
		buttonFontSize = 22,
		buttonFontColor = cc.c3b(90,45,3),
        callback = function ()
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
        	self:modifyMap()
        end
    })
    if self.modifyBtn ~= nil then
		self.modifyBtn:setAnchorPoint(cc.p(0.5, 0.5))
		self.modifyBtn:setPosition(cc.p(360,80))
	    self:addChild(self.modifyBtn, 5)
	end

	--upload button
	self.uploadBtn = GameControlButton.new({
        btnBg = ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[7],
        dstSize = {width=100, height=45},
        buttonFont = LangStringDefine.UPLOAD_LABEL,
		buttonFontSize = 22,
		buttonFontColor = cc.c3b(90,45,3),
        callback = function ()
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
        	display.getRunningScene():showConfirmLayer(LangStringDefine.CONFIRM_CONTENT_LABEL[4], function()
        		self:uploadMap()
        	end)
        end
    })
    if self.uploadBtn ~= nil then
		self.uploadBtn:setAnchorPoint(cc.p(0.5, 0.5))
		self.uploadBtn:setPosition(cc.p(240,30))
	    self:addChild(self.uploadBtn, 5)
	end

	--del button
	self.delBtn = GameControlButton.new({
        btnBg = ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[7],
        dstSize = {width=100, height=45},
        buttonFont = LangStringDefine.DELETE_LABEL,
		buttonFontSize = 22,
		buttonFontColor = cc.c3b(90,45,3),
        callback = function ()
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
        	display.getRunningScene():showConfirmLayer(LangStringDefine.CONFIRM_CONTENT_LABEL[3], function()
        		self:delMap()
        	end)
        end
    })
    if self.delBtn ~= nil then
		self.delBtn:setAnchorPoint(cc.p(0.5, 0.5))
		self.delBtn:setPosition(cc.p(360,30))
	    self:addChild(self.delBtn, 5)
	end
end

function MyMakeCell:delMap()
	if self.idx == nil then
		return
	end

	UserDataManager.PLAYER_MAP_MAKE_LIST[self.idx] = nil
	if self.parent ~= nil and self.parent.myMakeListView ~= nil then
		local offset = self.parent.myMakeListView:getContentOffset()
		self.parent.myMakeListView:reloadData()
		self.parent.myMakeListView:setContentOffset(offset)
	end
	UserDataManager.savePlayerMakeMapList()

	os.remove(self.data.picname)
end

function MyMakeCell:uploadMap()
	if self.idx == nil or self.data == nil then
		return
	end

	self:delMap()

	if self.parent ~= nil then
		self.data.picname = nil
		self.parent:uploadMap(self.data)
	end
end

function MyMakeCell:testMap()
	local mapData = self.data
	mapData.pic = nil
	UserDataManager.TMP_VALUE = self.parent.myMakeListView:getContentOffset()
	display.getRunningScene():enterGame(0, false, true, mapData)
end

function MyMakeCell:modifyMap()
	display.getRunningScene():showTips(LangStringDefine.FUNC_NOT_OPEN)
end

function MyMakeCell:resetCell(idx, data)
	if data == nil or type(data) ~= "table" then
		return
	end

	self.idx = idx
	self.data = data
	
	-- if self.mainPic ~= nil then
	-- 	local tpPic = display.newSprite(self.data.picname)
	-- 	if tpPic ~= nil then
	-- 		self.mainPic:setSpriteFrame(tpPic:getSpriteFrame())
	-- 	end
	-- end

	if self.makerTime ~= nil then
		self.makerTime:setString(self.data.title)--self.data.makeTime or "")
	end

end


return MyMakeCell
