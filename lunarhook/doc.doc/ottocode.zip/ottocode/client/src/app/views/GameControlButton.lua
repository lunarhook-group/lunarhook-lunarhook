
local GameControlButton = class("GameControlButton", function()
    return display.newNode()
end)
function GameControlButton:ctor(options)
	self.options = options or {}

    local normalImage = self.options.btnBg or ResourceDef.IMAGE_TRANSPARENT
    self.normalImg = ResourceManager.ImageName(normalImage)
    
	self.picSize = {width=0, height=0}
    if self.options.dstSize ~= nil then
        self.picSize.width = self.options.dstSize.width or 0
        self.picSize.height = self.options.dstSize.height or 0
	elseif self.normalImg ~= nil then
		local tpPic = display.newSprite(self.normalImg)
		if tpPic ~= nil then
			self.picSize.width = tpPic:getContentSize().width
			self.picSize.height = tpPic:getContentSize().height
		end
	end
	if self.picSize.width == 0 or self.picSize.height == 0 then
		return
	end

	
    self.delaying = false
    self.enabled = true
    if self.options.enabled~=nil then
        self.enabled = self.options.enabled
    end
    self:setImgButtonEnabled(self.enabled)
    self:setScale(self.options.normalScale or 1)

    local pBgButtonPic = display.newScale9Sprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT),0,0,cc.size(self.picSize.width,self.picSize.height))
    local pBgButtonPic2 = display.newScale9Sprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT),0,0,cc.size(self.picSize.width,self.picSize.height))
    local pBgButtonPic3 = display.newScale9Sprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT),0,0,cc.size(self.picSize.width,self.picSize.height))
    local buttonFont = options.buttonFont or ""
    local buttonFontSize = options.buttonFontSize or 24
    local buttonColor = options.buttonFontColor or cc.c3b(255,255,255)
    --local pTitleButtonLabel = cc.Label:createWithSystemFont(buttonFont, ResourceDef.FONT_GAME_MAIN, buttonFontSize)
    local pTitleButtonLabel = display.newTTFLabel({
        text = buttonFont,
        font = ResourceDef.FONT_GAME_MAIN,
        size = buttonFontSize,
        align = cc.TEXT_ALIGNMENT_CENTER
    })
    if (pBgButtonPic ~= nil) and (pTitleButtonLabel ~= nil) then
        pTitleButtonLabel:setColor(buttonColor)

        self.mainButton = cc.ControlButton:create(pTitleButtonLabel, pBgButtonPic)
        if self.mainButton ~= nil then
            if pBgButtonPic2 ~= nil then
                -- pBgButtonPic2:setScale(0.9)
                self.mainButton:setBackgroundSpriteForState(pBgButtonPic2, cc.CONTROL_STATE_HIGH_LIGHTED)
            end
            if pBgButtonPic3 ~= nil then
                self.mainButton:setBackgroundSpriteForState(pBgButtonPic3, cc.CONTROL_STATE_DISABLED)
            end
            self.mainButton:setZoomOnTouchDown(false)
            self.mainButton:setPreferredSize(cc.size(self.picSize.width,self.picSize.height))
            self.mainButton:setAnchorPoint(cc.p(0.5, 0.5))
            self.mainButton:setPosition(cc.p(0, 0))

            self.mainButton:registerControlEventHandler(function()
                --按下
                if self.enabled == true then
		            self:setScale(self.options.pressedScale or 0.9)
                    if self.options.pressDown ~= nil then      
                        self.options.pressDown()
                    end
		        end
            end, cc.CONTROL_EVENTTYPE_TOUCH_DOWN)
            self.mainButton:registerControlEventHandler(function()
                --抬起外
                if self.enabled == true then
		            self:setScale(self.options.normalScale or 1)
		        end
                if self.options.releaseOutsideButton ~= nil then      
                    self.options.releaseOutsideButton()
                end
            end, cc.CONTROL_EVENTTYPE_TOUCH_UP_OUTSIDE)
            self.mainButton:registerControlEventHandler(function()
                --抬起里
                if self.enabled == true then
		            self:setScale(self.options.normalScale or 1)
		        end
		        if self.enabled == true then
		            if self.options.callback ~= nil then      
		                self.options.callback({target=self})
		            end
		        else
		            if self.options.disabledCb ~= nil then      
		                self.options.disabledCb()
		            end
		        end
            end, cc.CONTROL_EVENTTYPE_TOUCH_UP_INSIDE)

            self:addChild(self.mainButton, 2)

            --btn bg
            self.buttonBG = display.newSprite(self.normalImg)
            if self.buttonBG ~= nil then
                self.buttonBG:setAnchorPoint(cc.p(0.5,0.5))
                self.buttonBG:setContentSize(cc.size(self.picSize.width,self.picSize.height))
                self.buttonBG:setPosition(cc.p(0,0))
                self:addChild(self.buttonBG, 1)
            end

            local btnLabelRes = self.options.textImg or ResourceDef.IMAGE_TRANSPARENT
            self.titleImg = display.newSprite(ResourceManager.ImageName(btnLabelRes))
            if self.titleImg ~= nil then
                self.titleImg:setAnchorPoint(cc.p(0.5,0.5))
                self.titleImg:setPosition(cc.p(0,0))
                self:addChild(self.titleImg, 4)
                if self.options.textImgOffset ~= nil then
                	self:setTextImgOffset(self.options.textImgOffset)
                end
            end
        end
    end
end


function GameControlButton:setButtonFlippedX()
    self.buttonBG:setFlippedX( true )
end

function GameControlButton:setTitleImgPos( offsetX,offsetY )
    if self.titleImg == nil then
        return
    end
    local posx,posy = self.titleImg:getPosition()
    posx = posx + offsetX
    posy = posy + offsetY
    self.titleImg:setPosition( posx,posy )
end

function GameControlButton:setImgButtonEnabled(enabled)
    if enabled == nil then
        return
    end

    self.enabled = enabled

    -- if self.enabled == true then
    --     if self.buttonBG ~= nil then
    --         local tpPic = display.newSprite(self.normalImg)
    --         if tpPic ~= nil then
    --             self.buttonBG:setSpriteFrame(tpPic:getSpriteFrame())
    --         end
    --     end
    -- else
    --     if self.buttonBG ~= nil then
    --         local tpPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_COMMON_BUTTON_DISABLE))
    --         if tpPic ~= nil then
    --             self.buttonBG:setSpriteFrame(tpPic:getSpriteFrame())
    --         end
    --     end
    -- end
end


function GameControlButton:setEnabled(bRet)
    if self.mainButton ~= nil then
        self.mainButton:setEnabled(bRet)
    end
end

function GameControlButton:setTextImgOffset(p)
    if p == nil or self.titleImg == nil then
        return
    end
    if p.x == nil or p.y == nil then
        return
    end
    self.titleImg:setPosition(p.x,p.y)
end

function GameControlButton:changeBgImg(image)
    if image == nil then
        return
    end
    
    local tpPic = display.newSprite(ResourceManager.ImageName(image))
	if tpPic ~= nil then
		self.picSize.width = tpPic:getContentSize().width
		self.picSize.height = tpPic:getContentSize().height
        if self.buttonBG ~= nil then
            self.buttonBG:setSpriteFrame(tpPic:getSpriteFrame())
        end
	else
		return
	end

    if self.mainButton ~= nil then
    	self.mainButton:setPreferredSize(cc.size(self.picSize.width,self.picSize.height))
    end
end

function GameControlButton:changeTitleImg(image)
    if image ~= nil and self.titleImg ~= nil then
        local tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(image))
        if tpFrame ~= nil then
            self.titleImg:setSpriteFrame(tpFrame)
        end
    end
end

function GameControlButton:onButtonPressed(func)
    self.options.pressDown = func
    return self
end

function GameControlButton:onButtonRelease(func)
    self.options.releaseOutsideButton = func
    return self
end

function GameControlButton:onButtonClicked(func)
    self.options.callback = func
    return self
end

function GameControlButton:getMainButton()
    return self.mainButton
end

return GameControlButton
