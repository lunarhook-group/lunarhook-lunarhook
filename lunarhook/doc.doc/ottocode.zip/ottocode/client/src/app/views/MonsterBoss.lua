

local MonsterBoss = class("MonsterBoss",function()
	return display.newNode()
end )

function MonsterBoss:ctor(parent)
	self.parentMap = parent

	self.monsterId = GameConfig.BOSS_STAGE_BOSS_MONSTER_ID
	self.isAlive = true
	self.calcNextPosTimeRecord = 0
	self.nextMoveParam = {x=0, y=0}

	self:init()
end

function MonsterBoss:init()
	

	self.monsterTblInfo = ConfigManager.monsterTbl[tostring(GameConfig.BOSS_STAGE_BOSS_MONSTER_ID)]
	if self.monsterTblInfo == nil then
		return
	end

	self.mainPic = display.newSprite(ResourceManager.ImageName(string.format("%s%.2d", self.monsterTblInfo.res, self.monsterTblInfo.animation.jump.begin.start)))
	if self.mainPic ~= nil then
		self.mainPic:setAnchorPoint(cc.p(0.5,0.5))
		self.mainPic:setPosition(cc.p(0,200))
		self.mainPic:setOpacity(170)
		self:addChild(self.mainPic)
	end


	if self.monsterTblInfo.animation.jump.begin.start > 0 and self.monsterTblInfo.animation.jump.begin.count > 0 then
		AnimationManager.setAniToCache(self.monsterTblInfo.res, self.monsterTblInfo.animation.jump.begin.start, self.monsterTblInfo.animation.jump.begin.count, self.monsterTblInfo.animation.internal*self.monsterTblInfo.animation.jump.begin.count, "monster_idle_" .. tostring(self.monsterId))
	end
	if self.monsterTblInfo.animation.thunder.count > 0 and self.monsterTblInfo.animation.thunder.time > 0 then
		AnimationManager.setAniToCache(self.monsterTblInfo.res, self.monsterTblInfo.animation.thunder.start, self.monsterTblInfo.animation.thunder.count, self.monsterTblInfo.animation.thunder.time, "monster_die_" .. tostring(self.monsterId))
	end
	if self.monsterTblInfo.animation.victory.count > 0 and self.monsterTblInfo.animation.victory.time > 0 then
		AnimationManager.setAniToCache(self.monsterTblInfo.res, self.monsterTblInfo.animation.victory.start, self.monsterTblInfo.animation.victory.count, self.monsterTblInfo.animation.victory.time, "monster_victory_" .. tostring(self.monsterId))
	end
	if self.monsterTblInfo.animation.fall.count > 0 and self.monsterTblInfo.animation.fall.time > 0 then
		AnimationManager.setAniToCache(self.monsterTblInfo.res, self.monsterTblInfo.animation.fall.start, self.monsterTblInfo.animation.fall.count, self.monsterTblInfo.animation.fall.time, "monster_fall_" .. tostring(self.monsterId))
	end

	local idleAni = AnimationManager.getAniFromCacheByName("monster_idle_" .. tostring(self.monsterId))
	if idleAni ~= nil then
		self.idleAnimation = cc.RepeatForever:create(cc.Sequence:create(cc.Animate:create(idleAni), cc.DelayTime:create(3)))
		self.idleAnimation:retain()
	end
	local shakeAni = AnimationManager.getAniFromCacheByName("monster_fall_" .. tostring(self.monsterId))
	if shakeAni ~= nil then
		self.shakeAnimation = cc.Animate:create(shakeAni)
		self.shakeAnimation:retain()
	end
	
	self:playIdle()
end

function MonsterBoss:update(t)
	if self.isAlive == false then
		return
	end

	self.calcNextPosTimeRecord = self.calcNextPosTimeRecord + t
	if self.calcNextPosTimeRecord >= GameConfig.BOSS_CALC_NEXT_POS_TIME then
		self.calcNextPosTimeRecord = self.calcNextPosTimeRecord - GameConfig.BOSS_CALC_NEXT_POS_TIME
		self:calcNextPos()
	end

	self:move()
end

function MonsterBoss:calcNextPos()
	if self.parentMap == nil or self.parentMap.mainPlayer == nil then
		return
	end

	local myPosX = self:getPositionX()
	local myPosY = self:getPositionY()
	local playerPosX = self.parentMap.mainPlayer:getPositionX()
	local playerPosY = self.parentMap.mainPlayer:getPositionY()

	if math.pow(myPosX-playerPosX, 2) + math.pow(myPosY-playerPosY, 2) <= 10*10 then
		return
	end

	local anger = math.atan(math.abs(myPosY-playerPosY) / math.abs(myPosX-playerPosX))
	self.nextMoveParam.y = math.sin(anger) * GameConfig.BOSS_MOVE_SPEED
	self.nextMoveParam.x = math.cos(anger) * GameConfig.BOSS_MOVE_SPEED

	if myPosX > playerPosX then
		self.nextMoveParam.x = self.nextMoveParam.x * (-1)
	end
	if myPosY > playerPosY then
		self.nextMoveParam.y = self.nextMoveParam.y * (-1)
	end
end

function MonsterBoss:move()
	if self.nextMoveParam.x == 0 and self.nextMoveParam.y == 0 then
		return
	end

	self:setPositionX(self:getPositionX() + self.nextMoveParam.x)
	self:setPositionY(self:getPositionY() + self.nextMoveParam.y)

	self.nextMoveParam.x = 0
	self.nextMoveParam.y = 0
end

function MonsterBoss:playIdle()
	if self.mainPic ~= nil then
		if self.idleAnimation ~= nil then
			self.mainPic:stopAllActions()
			self.mainPic:runAction(self.idleAnimation:clone())
		end
	end
end

function MonsterBoss:playWin()
	if self.mainPic ~= nil then
		local winAni = AnimationManager.getAniFromCacheByName("monster_victory_" .. tostring(self.monsterId))
		if winAni ~= nil then
			self.mainPic:stopAllActions()
			self.mainPic:runAction(cc.Animate:create(winAni))
		end
	end
end

function MonsterBoss:playDie()
	if self.mainPic ~= nil then
		local dieAni = AnimationManager.getAniFromCacheByName("monster_die_" .. tostring(self.monsterId))
		if dieAni ~= nil then
			self.mainPic:stopAllActions()
			self.mainPic:runAction(cc.Sequence:create(cc.Animate:create(dieAni), cc.CallFunc:create(function()
				self.isAlive = false
				self.mainPic:setVisible(false)
			end)))
		end
	end
end

function MonsterBoss:playShakeAni(cb)
	if self.mainPic ~= nil then
		self.mainPic:stopAllActions()
		local seq = cc.Sequence:create(
			self.shakeAnimation:clone(), 
			cc.DelayTime:create(1), 
			cc.CallFunc:create(function()
				if cb ~= nil then
					cb()
				end
			end),
			cc.DelayTime:create(0.5), 
			cc.CallFunc:create(function()
				if self.mainPic ~= nil then
					self.mainPic:stopAllActions()
					self:playIdle()
				end
			end))
		if seq ~= nil then
			self.mainPic:runAction(seq)
		end
	end
end

return MonsterBoss
