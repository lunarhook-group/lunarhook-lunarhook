local GameControlButton = import("app.views.GameControlButton")

local LoadingLayer = class("LoadingLayer",function()
	return display.newNode()
end )

function LoadingLayer:ctor()
	
	self:init()
end

function LoadingLayer:init()
	--black bg
	local bgColorLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 120), display.width, display.height)
	if bgColorLayer ~= nil then
		bgColorLayer:setAnchorPoint(cc.p(0, 0))
		bgColorLayer:setPosition(cc.p(0, 0))
		self:addChild(bgColorLayer, 1)
	end

	local strLabel = display.newTTFLabel({
        text = LangStringDefine.LABEL_IS_LOADING,
        font = ResourceDef.FONT_GAME_MAIN,
        size = 30,
        color = cc.c3b(255, 255, 255),
        align = cc.TEXT_ALIGNMENT_CENTER
    })
    if strLabel ~= nil then
        strLabel:setAnchorPoint(cc.p(0.5, 0.5))
        strLabel:setPosition(cc.p(display.cx, display.cy))
        self:addChild(strLabel, 2)
    end

    local bgCoverBtn = GameControlButton.new({
        btnBg = ResourceDef.IMAGE_TRANSPARENT,
        dstSize = {width=display.width, height=display.height},
        callback = function ()
        end
    })
    if bgCoverBtn ~= nil then
		bgCoverBtn:setAnchorPoint(cc.p(0.5, 0.5))
		bgCoverBtn:setPosition(cc.p(display.cx, display.cy))
	    self:addChild(bgCoverBtn, 5)
	end
end

return LoadingLayer
