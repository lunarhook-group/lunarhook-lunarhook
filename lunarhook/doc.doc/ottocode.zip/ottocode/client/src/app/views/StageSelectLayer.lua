local GameControlButton = import("app.views.GameControlButton")
local WorldLayer = require("app.views.WorldLayer")

local StageSelectLayer = class("StageSelectLayer", BaseLayer)

function StageSelectLayer:ctor()
	StageSelectLayer.super.ctor(self)

	self.currentWorldIdx = 0
	self.isChangingWorldFlag = false

	self:initStageData()
	self:initUI()
end

function StageSelectLayer:initStageData()
	self.maxActiveWorldID = 1
	self.curStageId = 101
	self.stageData = {}

	for worldIndex=1, 20 do
		if worldIndex > self.maxActiveWorldID then
			break
		end

		local hasDataFlag = false
		self.stageData[worldIndex] = {{stageId = 0, firstTime = 0, steps = 0, recordTime = 0, opened = false}}

		for stageIndex=1, 99 do
			local stageId = worldIndex*100+stageIndex
			local tblInfo = ConfigManager.stageTbl[tostring(stageId)]
			if tblInfo == nil then
				if (self.stageData[worldIndex][stageIndex].firstTime ~= 0 or GameConfig.DEBUG_MODE == true) and stageIndex > 1 then
					self.maxActiveWorldID = worldIndex + 1
				end
				break
			end
			hasDataFlag = true

			self.stageData[worldIndex][stageIndex+1] = {
				stageId = stageId, 
				firstTime = 0, 
				steps = 0, 
				recordTime = 0, 
				opened = false,
			}

			local myStageData = UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(stageId)]
			if myStageData ~= nil then
				self.stageData[worldIndex][stageIndex+1].firstTime = myStageData.firstTime
				self.stageData[worldIndex][stageIndex+1].recordTime = myStageData.record_time
				self.stageData[worldIndex][stageIndex+1].steps = myStageData.step
				self.stageData[worldIndex][stageIndex+1].opened = true

				if myStageData.firstTime == 0 then
					self.maxActiveWorldID = worldIndex
					self.curStageId = stageId
				end
			else
				self.maxActiveWorldID = worldIndex
			end

			if GameConfig.DEBUG_MODE == true then
				self.stageData[worldIndex][stageIndex+1].opened = true
				self.maxActiveWorldID = worldIndex
			end
		end

		if hasDataFlag == false then
			self.stageData[worldIndex] = nil
			if self.maxActiveWorldID == worldIndex then
				self.maxActiveWorldID = worldIndex - 1
			end
			break
		end
	end
end

function StageSelectLayer:initUI()
	--bg
	local bgPicParam = {
		{res=1, pos=cc.p(0,display.height), anchorPoint=cc.p(0,1), zorder=6, scale=0.8},
		{res=2, pos=cc.p(0,display.height), anchorPoint=cc.p(0,1), zorder=5, scale=0.8},
		{res=3, pos=cc.p(display.width,display.height), anchorPoint=cc.p(1,1), zorder=5, scale=0.8},
	}
	self.layerBgPicList = {}
	for i=1, #bgPicParam do
		self.layerBgPicList[i] = display.newSprite(ResourceManager.ImageName(ResourceDef.WORLD_LAYER_BG[bgPicParam[i].res]))
		if self.layerBgPicList[i] ~= nil then
			self.layerBgPicList[i]:setAnchorPoint(bgPicParam[i].anchorPoint)
			self.layerBgPicList[i]:setPosition(bgPicParam[i].pos)
			self.layerBgPicList[i]:setScale(bgPicParam[i].scale)
			self:addChild(self.layerBgPicList[i], bgPicParam[i].zorder)
		end
	end

	-------clouds
	self.cloudNode = GameTools.makeMoveClouds(0-display.width, (display.cy+200)*2, display.width*3, display.cy-100)
	if self.cloudNode ~= nil then
		self.cloudNode:setScale(0.5)
		self:addChild(self.cloudNode, 2)
	end

	self:makeFloatFlowers(self, 5)

	--earth
	self.earth = display.newNode()
	if self.earth ~= nil then
		self.earth:setAnchorPoint(cc.p(0.5, 0.5))
		self.earth:setPosition(cc.p(display.cx, -800))
		self:addChild(self.earth, 10)
	end

	--world content
	self.worldPosList = {
		left = {x=-853, y=123, anger=-60},
		middle = {x=0-display.cx, y=800, anger=0},
		right = {x=533, y=677, anger=60}
	}

	local bgLayerSize = {width=display.width*3, height=display.height}
	self.bgColorLayerList = {}
	self.worldLayerList = {}
	for i=1, self.maxActiveWorldID do
		self.worldLayerList[i] = WorldLayer.new(i, self)
		if self.worldLayerList[i] ~= nil then
			self.worldLayerList[i]:closeLayer()
			self.earth:addChild(self.worldLayerList[i], 10)
		end

		self.bgColorLayerList[i] = cc.LayerColor:create(ResourceDef.STAGE_SELECT_CONTENT.worldMainBgColorList[i], bgLayerSize.width, bgLayerSize.height)
		if self.bgColorLayerList[i] ~= nil then
			self.bgColorLayerList[i]:setAnchorPoint(cc.p(0, 0))
			self.bgColorLayerList[i]:setPosition(cc.p(0-display.width, 0))
			self.bgColorLayerList[i]:setOpacity(0)
			self:addChild(self.bgColorLayerList[i], 1)
		end
	end

	if self.worldLayerList[1] ~= nil then
		self.worldLayerList[1]:setPosition(cc.p(self.worldPosList.middle.x, self.worldPosList.middle.y))
		self.worldLayerList[1]:setRotation(self.worldPosList.middle.anger)
	end

	if self.bgColorLayerList[1] ~= nil then
		self.bgColorLayerList[1]:setOpacity(255)
	end

	--return main layer
	self.homeCarrotNode = GameControlButton.new({
        btnBg = ResourceDef.MAINSCENE_CONTENT.homeCarrot,
        dstSize = {width=76, height=92},
        pressDown = function ()
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_small), false)
        	self:returnMainLayer()
        end
    })
	if self.homeCarrotNode ~= nil then
		self.homeCarrotNode:setAnchorPoint(cc.p(0.5, 0.5))
		self.homeCarrotNode:setPosition(cc.p(50, display.height-50))
		self:addChild(self.homeCarrotNode, 50)
	end


	--side buttons
	self.leftBtnNode = display.newNode()
	if self.leftBtnNode ~= nil then
		self.leftBtnNode:setAnchorPoint(cc.p(0.5,0.5))
		self.leftBtnNode:setPosition(cc.p(40, display.cy+180))
		self:addChild(self.leftBtnNode, 50)

		local leftButton = GameControlButton.new({
	        btnBg = ResourceDef.WORLD_CHANGE_ARROW_RES,
	        dstSize = {width=40, height=77},
	        pressDown = function ()
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_small), false)
	        	if self.isChangingWorldFlag == true then
	        		return
	        	end
	        	self:goPrevWorld()
	        end
	    })
	    if leftButton ~= nil then
			leftButton:setAnchorPoint(cc.p(0.5, 0.5))
			leftButton:setPosition(cc.p(0, 0))
		    self.leftBtnNode:addChild(leftButton)
		end
	end
	
	self.rightBtnNode = display.newNode()
	if self.rightBtnNode ~= nil then
		self.rightBtnNode:setAnchorPoint(cc.p(0.5,0.5))
		self.rightBtnNode:setPosition(cc.p(display.width-40, display.cy+180))
		self.rightBtnNode:setScaleX(-1)
		self:addChild(self.rightBtnNode, 50)

		rightButton = GameControlButton.new({
	        btnBg = ResourceDef.WORLD_CHANGE_ARROW_RES,
	        dstSize = {width=40, height=77},
	        pressDown = function ()
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_small), false)
	        	if self.isChangingWorldFlag == true then
	        		return
	        	end
	        	self:goNextWorld()
	        end
	    })
	    if rightButton ~= nil then
			rightButton:setAnchorPoint(cc.p(0.5, 0.5))
			rightButton:setPosition(cc.p(0, 0))
		    self.rightBtnNode:addChild(rightButton)
		end
	end
end

function StageSelectLayer:goNextWorld()
	-- print("---- next")
	self.isChangingWorldFlag = true
	local maxWorldIndex = #self.stageData

	if self.currentWorldIdx == maxWorldIndex then
		display.getRunningScene():showTips(LangStringDefine.WORLD_IS_LOCK)
		self.isChangingWorldFlag = false
	else
		if self.bgColorLayerList[self.currentWorldIdx] ~= nil then
			self.bgColorLayerList[self.currentWorldIdx]:runAction(cc.FadeTo:create(GameConfig.WORLD_TRANSITION_ROTATION_TIME, 0))
		end
		if self.bgColorLayerList[self.currentWorldIdx+1] ~= nil then
			self.bgColorLayerList[self.currentWorldIdx+1]:runAction(cc.FadeTo:create(GameConfig.WORLD_TRANSITION_ROTATION_TIME, 255))
		end

		if self.cloudNode ~= nil then
			if self.currentWorldIdx + 1 == 3 then
				for k,v in pairs(self.cloudNode:getChildren()) do
					v:runAction(cc.FadeTo:create(GameConfig.WORLD_TRANSITION_ROTATION_TIME, 10))
				end
			elseif self.currentWorldIdx + 1 == 4 then
				for k,v in pairs(self.cloudNode:getChildren()) do
					v:runAction(cc.FadeTo:create(GameConfig.WORLD_TRANSITION_ROTATION_TIME, 255))
				end
			end
		end

		if self.flowerList ~= nil and type(self.flowerList) == "table" then
			if self.currentWorldIdx + 1 == 3 then
				for k,v in pairs(self.flowerList) do
					v:runAction(cc.FadeTo:create(GameConfig.WORLD_TRANSITION_ROTATION_TIME, 100))
				end
			elseif self.currentWorldIdx + 1 == 4 then
				for k,v in pairs(self.flowerList) do
					v:runAction(cc.FadeTo:create(GameConfig.WORLD_TRANSITION_ROTATION_TIME, 255))
				end
			end
		end

		local dstOpacity = 255
		if self.currentWorldIdx+1 == 3 then
			dstOpacity = 50
		end
		for i=1, 3 do
			if self.layerBgPicList[i] ~= nil then
				self.layerBgPicList[i]:runAction(cc.FadeTo:create(GameConfig.WORLD_TRANSITION_ROTATION_TIME, dstOpacity))
			end
		end

		self.earth:runAction(cc.Sequence:create(
			cc.CallFunc:create(function()
				if self.leftBtnNode ~= nil then
					self.leftBtnNode:setVisible(false)
				end
				if self.rightBtnNode ~= nil then
					self.rightBtnNode:setVisible(false)
				end

				--current
				local curLayer = self.worldLayerList[self.currentWorldIdx]
				if self.worldLayerList[self.currentWorldIdx] ~= nil then
					self.worldLayerList[self.currentWorldIdx]:showOrHideStageView(false)
				end

				--next
				if self.worldLayerList[self.currentWorldIdx+1] == nil then
					self.worldLayerList[self.currentWorldIdx+1] = WorldLayer.new(self.currentWorldIdx+1, self)
					if self.worldLayerList[self.currentWorldIdx+1] ~= nil then
						self.worldLayerList[self.currentWorldIdx+1]:closeLayer()
						self.earth:addChild(self.worldLayerList[self.currentWorldIdx+1], 10)
					end
				end
				if self.worldLayerList[self.currentWorldIdx+1] ~= nil then
					self.worldLayerList[self.currentWorldIdx+1]:setPosition(cc.p(self.worldPosList.right.x, self.worldPosList.right.y))
					self.worldLayerList[self.currentWorldIdx+1]:setRotation(self.worldPosList.right.anger)
					self.worldLayerList[self.currentWorldIdx+1]:openLayer()
					self.worldLayerList[self.currentWorldIdx+1]:showOrHideStageView(false)
				end
			end),
			cc.RotateBy:create(GameConfig.WORLD_TRANSITION_ROTATION_TIME, -60),
			cc.CallFunc:create(function()
				--current
				if self.worldLayerList[self.currentWorldIdx] ~= nil then
					self.worldLayerList[self.currentWorldIdx]:setPosition(cc.p(self.worldPosList.left.x, self.worldPosList.left.y))
					self.worldLayerList[self.currentWorldIdx]:setRotation(self.worldPosList.left.anger)
					self.worldLayerList[self.currentWorldIdx]:showOrHideStageView(true)
					self.worldLayerList[self.currentWorldIdx]:closeLayer()
				end

				--next
				if self.worldLayerList[self.currentWorldIdx+1] ~= nil then
					self.worldLayerList[self.currentWorldIdx+1]:setPosition(cc.p(self.worldPosList.middle.x, self.worldPosList.middle.y))
					self.worldLayerList[self.currentWorldIdx+1]:setRotation(self.worldPosList.middle.anger)
					self.worldLayerList[self.currentWorldIdx+1]:showOrHideStageView(true)
				end
				--earth reset rotation
				self.earth:setRotation(0)

				--change current index
				self.currentWorldIdx = self.currentWorldIdx + 1

				if self.leftBtnNode ~= nil then
					self.leftBtnNode:setVisible(true)
				end
				if self.rightBtnNode ~= nil then
					self.rightBtnNode:setVisible(true)
				end

				self.isChangingWorldFlag = false
			end)
		))		
	end
end

function StageSelectLayer:goPrevWorld()
	-- print("---- prev")
	self.isChangingWorldFlag = true

	if self.currentWorldIdx == 1 then
		self:returnMainLayer()
	else
		if self.bgColorLayerList[self.currentWorldIdx] ~= nil then
			self.bgColorLayerList[self.currentWorldIdx]:runAction(cc.FadeTo:create(GameConfig.WORLD_TRANSITION_ROTATION_TIME, 0))
		end
		if self.bgColorLayerList[self.currentWorldIdx-1] ~= nil then
			self.bgColorLayerList[self.currentWorldIdx-1]:runAction(cc.FadeTo:create(GameConfig.WORLD_TRANSITION_ROTATION_TIME, 255))
		end

		if self.cloudNode ~= nil then
			if self.currentWorldIdx - 1 == 3 then
				for k,v in pairs(self.cloudNode:getChildren()) do
					v:runAction(cc.FadeTo:create(GameConfig.WORLD_TRANSITION_ROTATION_TIME, 10))
				end
			elseif self.currentWorldIdx - 1 == 2 then
				for k,v in pairs(self.cloudNode:getChildren()) do
					v:runAction(cc.FadeTo:create(GameConfig.WORLD_TRANSITION_ROTATION_TIME, 255))
				end
			end
		end

		if self.flowerList ~= nil and type(self.flowerList) == "table" then
			if self.currentWorldIdx + 1 == 3 then
				for k,v in pairs(self.flowerList) do
					v:runAction(cc.FadeTo:create(GameConfig.WORLD_TRANSITION_ROTATION_TIME, 100))
				end
			elseif self.currentWorldIdx - 1 == 2 then
				for k,v in pairs(self.flowerList) do
					v:runAction(cc.FadeTo:create(GameConfig.WORLD_TRANSITION_ROTATION_TIME, 255))
				end
			end
		end

		local dstOpacity = 255
		if self.currentWorldIdx-1 == 3 then
			dstOpacity = 100
		end
		for i=1, 3 do
			if self.layerBgPicList[i] ~= nil then
				self.layerBgPicList[i]:runAction(cc.FadeTo:create(GameConfig.WORLD_TRANSITION_ROTATION_TIME, dstOpacity))
			end
		end

		self.earth:runAction(cc.Sequence:create(
			cc.CallFunc:create(function()
				if self.leftBtnNode ~= nil then
					self.leftBtnNode:setVisible(false)
				end
				if self.rightBtnNode ~= nil then
					self.rightBtnNode:setVisible(false)
				end

				--current
				local curLayer = self.worldLayerList[self.currentWorldIdx]
				if self.worldLayerList[self.currentWorldIdx] ~= nil then
					self.worldLayerList[self.currentWorldIdx]:showOrHideStageView(false)
				end

				--prev
				if self.worldLayerList[self.currentWorldIdx-1] == nil then
					self.worldLayerList[self.currentWorldIdx-1] = WorldLayer.new(self.currentWorldIdx-1, self)
					if self.worldLayerList[self.currentWorldIdx-1] ~= nil then
						self.worldLayerList[self.currentWorldIdx-1]:closeLayer()
						self.earth:addChild(self.worldLayerList[self.currentWorldIdx-1], 10)
					end
				end
				if self.worldLayerList[self.currentWorldIdx-1] ~= nil then
					self.worldLayerList[self.currentWorldIdx-1]:setPosition(cc.p(self.worldPosList.left.x, self.worldPosList.left.y))
					self.worldLayerList[self.currentWorldIdx-1]:setRotation(self.worldPosList.left.anger)
					self.worldLayerList[self.currentWorldIdx-1]:openLayer()
					self.worldLayerList[self.currentWorldIdx-1]:showOrHideStageView(false)
				end
			end),
			cc.RotateBy:create(GameConfig.WORLD_TRANSITION_ROTATION_TIME, 60),
			cc.CallFunc:create(function()
				--current
				if self.worldLayerList[self.currentWorldIdx] ~= nil then
					self.worldLayerList[self.currentWorldIdx]:setPosition(cc.p(self.worldPosList.right.x, self.worldPosList.right.y))
					self.worldLayerList[self.currentWorldIdx]:setRotation(self.worldPosList.right.anger)
					self.worldLayerList[self.currentWorldIdx]:showOrHideStageView(true)
					self.worldLayerList[self.currentWorldIdx]:closeLayer()
				end

				--prev
				if self.worldLayerList[self.currentWorldIdx-1] ~= nil then
					self.worldLayerList[self.currentWorldIdx-1]:setPosition(cc.p(self.worldPosList.middle.x, self.worldPosList.middle.y))
					self.worldLayerList[self.currentWorldIdx-1]:setRotation(self.worldPosList.middle.anger)
					self.worldLayerList[self.currentWorldIdx-1]:showOrHideStageView(true)
				end
				--earth reset rotation
				self.earth:setRotation(0)

				--change current index
				self.currentWorldIdx = self.currentWorldIdx - 1

				if self.leftBtnNode ~= nil then
					self.leftBtnNode:setVisible(true)
				end
				if self.rightBtnNode ~= nil then
					self.rightBtnNode:setVisible(true)
				end

				self.isChangingWorldFlag = false
			end)
		))
	end

	
end

function StageSelectLayer:update(t)
	
end

function StageSelectLayer:returnMainLayer()
	local curScene = display.getRunningScene()
	if curScene ~= nil and curScene.returnMainLayer ~= nil then
		curScene:UITransition(function()
			curScene:returnMainLayer()
		end)
	end
end

function StageSelectLayer:makeFloatFlowers(node, zorder)
	if node == nil then
		return
	end
	if zorder == nil then
		zorder = 1
	end

	self.flowerList = {}
	local totalCountRow = 4
	local totalCountColumn = 4
	for i=1, totalCountRow*totalCountColumn do
		local randIdx = math.random(1, #ResourceDef.MAINSCENE_CONTENT.floatFlowers)
		local flower = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.floatFlowers[randIdx])))
		if flower ~= nil then
			flower:setAnchorPoint(cc.p(0.5,0.5))
			flower:setScale(math.random(60, 80)/100)
			node:addChild(flower, zorder)
			flower:runAction(cc.RepeatForever:create(cc.RotateBy:create(1, 360)))

			local rowIdx = math.floor(i/totalCountRow)
			local columnIdx = math.fmod(i, totalCountColumn) + 1
			flower:setPosition(cc.p(math.random(display.width*columnIdx/totalCountColumn, display.width*(columnIdx+1)/totalCountColumn), math.random(display.height*rowIdx/totalCountRow, display.height*(rowIdx+1)/totalCountRow)))

			local offval = 5
			local bez = {
				cc.p(math.random(31-offval, 31+offval), math.random(-124-offval, -124+offval)),
				cc.p(math.random(100-offval, 100+offval), math.random(-138-offval, -138+offval)),
				cc.p(math.random(95-offval, 95+offval), math.random(-100-offval, -100+offval))
			}
			flower:runAction(cc.RepeatForever:create(cc.Sequence:create(
				cc.BezierBy:create(math.random(50, 100) / 10, bez), 
				cc.CallFunc:create(function()
					if flower:getPositionY() < 0 then
						flower:setPosition(cc.p(math.random(-150, display.cx-100), math.random(display.height, display.height+100)))
					end
				end)
			)))
			self.flowerList[#self.flowerList+1] = flower
		end
	end
end

function StageSelectLayer:openLayer(idx)
	if idx == nil then
		idx = 1
	end

	if self.worldLayerList[idx] == nil then
		print("----- error! no world exist, index: ", idx)
		return
	end

	if self.worldLayerList[idx] ~= nil then
		self.worldLayerList[idx]:setPosition(cc.p(self.worldPosList.middle.x, self.worldPosList.middle.y))
		self.worldLayerList[idx]:setRotation(self.worldPosList.middle.anger)
		self.worldLayerList[idx]:openLayer()
		self.currentWorldIdx = idx
	end

	for i=1, #self.bgColorLayerList do
		if i == self.currentWorldIdx then
			self.bgColorLayerList[i]:setOpacity(255)
		else
			self.bgColorLayerList[i]:setOpacity(0)
		end
	end

	if self.cloudNode ~= nil then
		if self.currentWorldIdx == 3 then
			for k,v in pairs(self.cloudNode:getChildren()) do
				v:setOpacity(10)
			end
		else
			for k,v in pairs(self.cloudNode:getChildren()) do
				v:setOpacity(255)
			end
		end
	end

	if self.flowerList ~= nil and type(self.flowerList) == "table" then
		if self.currentWorldIdx == 3 then
			for k,v in pairs(self.flowerList) do
				v:setOpacity(100)
			end
		else
			for k,v in pairs(self.flowerList) do
				v:setOpacity(255)
			end
		end
	end

	local dstOpacity = 255
	if self.currentWorldIdx == 3 then
		dstOpacity = 50
	end
	for i=1, 3 do
		if self.layerBgPicList[i] ~= nil then
			self.layerBgPicList[i]:setOpacity(dstOpacity)
		end
	end


	if self.leftBtnNode ~= nil then
		self.leftBtnNode:setVisible(true)
	end
	if self.rightBtnNode ~= nil then
		self.rightBtnNode:setVisible(true)
	end
	
	self.isChangingWorldFlag = false
	self:setVisible(true)
end


function StageSelectLayer:closeLayer()
	self.isChangingWorldFlag = true
	self:setVisible(false)
	for k,v in pairs(self.worldLayerList) do
		v:closeLayer()
	end
end

return StageSelectLayer
