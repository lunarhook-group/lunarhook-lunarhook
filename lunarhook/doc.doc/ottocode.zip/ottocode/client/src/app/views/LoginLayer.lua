local GameControlButton = import("app.views.GameControlButton")

local LoginLayer = class("LoginLayer", BaseLayer)

local GAME_LAYER_ZORDER_DEFINE = {
	BG = 1,
	UI_POP = 2,
	TIPS = 3,
	NOTICE = 4,
}

function LoginLayer:ctor()
	LoginLayer.super.ctor(self)
	
	self:initUI()
end

function LoginLayer:initUI()
	--bg
	self.bgNode = display.newNode()
	if self.bgNode ~= nil then
		self.bgNode:setAnchorPoint(cc.p(0.5,0.5))
		self.bgNode:setPosition(cc.p(display.cx, display.cy))
		self:addChild(self.bgNode, GAME_LAYER_ZORDER_DEFINE.BG)

		local bgPic = display.newSprite(ResourceManager.ImageName(ResourceDef.MAIN_BG))
		if bgPic ~= nil then
			bgPic:setAnchorPoint(cc.p(0.5,0.5))
			bgPic:setPosition(cc.p(0,0))
			bgPic:setScaleX(display.width/bgPic:getContentSize().width)
			bgPic:setScaleY(display.height/bgPic:getContentSize().height)
			self.bgNode:addChild(bgPic)
		end

	end

	--ui node
	self.uiNode = display.newNode()
	if self.uiNode ~= nil then
		self.uiNode:setAnchorPoint(cc.p(0.5,0.5))
		self.uiNode:setPosition(cc.p(0, 0))
		self:addChild(self.uiNode, GAME_LAYER_ZORDER_DEFINE.UI_POP)


		--login button
		self.loginButton = GameControlButton.new({
	        btnBg = ResourceDef.BUTTON_LONG,
	        dstSize = {width=240, height=68},
	        buttonFont = LangStringDefine.LOGIN_LABEL,
	        buttonFontSize = 36,
	        buttonFontColor = cc.c3b(0,0,255),
	        callback = function ()
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_begin), false)
	        	self:loginGame()
	        end
	    })
	    if self.loginButton ~= nil then
			self.loginButton:setAnchorPoint(cc.p(0.5, 0.5))
			self.loginButton:setPosition(cc.p(display.cx, display.cy-150))
		    self.uiNode:addChild(self.loginButton)
		end
	end
	
end

function LoginLayer:loginGame()
	GameConfig.ISONLINE = true

	local curScene = display.getRunningScene()

	local params = {playerId=UserDataManager.PLAYER_UID}
	local ret, resp = GameNetWorker.createHttpRequestWithPostParam(GameConfig.SERVER_ADDRESS .. GameConfig.REQUEST_URL.login, params, false)
	-- dump(resp)
	if ret == true then
		local respInfo = json.decode(resp)
		if respInfo ~= nil then
			if respInfo.errorId ~= nil then
				if curScene ~= nil and curScene.showTips ~= nil then
					curScene:showTips(respInfo.errorMsg)
				end
			else
				if UserDataManager.PLAYER_UID == "0000" and respInfo.playerId ~= nil then
					UserDataManager.savePlayerUID(respInfo.playerId)
				end

				if respInfo.baseInfo ~= nil then
					if respInfo.baseInfo.model_id ~= nil then
						UserDataManager.PlayerModelID = respInfo.baseInfo.model_id
					end
					if respInfo.baseInfo.coin ~= nil then
						UserDataManager.UM_COIN = respInfo.baseInfo.coin
					end
					if respInfo.baseInfo.candy ~= nil then
						UserDataManager.UM_CANDY = respInfo.baseInfo.candy
					end
				end

				if respInfo.stageInfo ~= nil then
					UserDataManager.PLAYER_STAGES_STATE_LIST = respInfo.stageInfo
				end

				if respInfo.mapInfo ~= nil then
					UserDataManager.PLAYER_MAP_UPLOAD_LIST = respInfo.mapInfo.upload or {}
					UserDataManager.PLAYER_MAP_DOWNLOAD_LIST = respInfo.mapInfo.download or {}
				end

				if curScene ~= nil and curScene.returnMainLayer ~= nil then
					curScene:returnMainLayer()
				end
			end
		else
			if curScene ~= nil and curScene.showTips ~= nil then
				curScene:showTips("resp fromat error.")
			end
		end
	else
		if curScene ~= nil and curScene.showTips ~= nil then
			curScene:showTips("server fault.")
		end
	end
end


function LoginLayer:showServerList()
	
end

function LoginLayer:update(t)
	
end

function LoginLayer:openLayer()
	self:setVisible(true)
end


function LoginLayer:closeLayer()
	self:setVisible(false)
end


return LoginLayer
