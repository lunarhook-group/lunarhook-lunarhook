
local MapUnit = class("MapUnit",function()
	return display.newNode()
end )

local shakeActUnitTime = GameConfig.BIG_FOOT_GROUND_FLOAT_UNIT_TIME
local shakeActOffsetY = GameConfig.BIG_FOOT_GROUND_FLOAT_OFFSETY

function MapUnit:ctor(parentNode)
	
	self.parentMapNode = parentNode

	self.id = 0
	self.mapBlockType = nil
	self.nextId = 0
	self.dominId = 0
	self.showFlag = true

	self.isBossStage = false
	self.isKeyBlock = false

	self:preInitGround()
end

function MapUnit:preInitGround()

	self.groundPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
	if self.groundPic ~= nil then
		self.groundPic:setAnchorPoint(cc.p(0.5,0.5))
		self.groundPic:setPosition(cc.p(0,0))
		self:addChild(self.groundPic)
	end

end


function MapUnit:initWithData(mapTblInfo, dominId, showFlag)
	if dominId ~= nil then
		self.dominId = dominId
	end
	if showFlag ~= nil then
		self.showFlag = showFlag
	end

	if mapTblInfo ~= nil then
		self:changeGroundPic(ResourceManager.ImageName(string.format("%s%0.2d", mapTblInfo.res, mapTblInfo.animation.start)))
		self.id = mapTblInfo.id
		self.mapBlockType = mapTblInfo.type or GameDefine.GROUND_BLOCK_TYPE.NORMAL
		self.nextId = mapTblInfo.target
	else
		self:changeGroundPic(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
	end

	if self.dominId > 0 and self.mapBlockType ~= GameDefine.GROUND_BLOCK_TYPE.SHOW_HIDE then
		self:setVisible(self.showFlag)
	end

	if self.mapBlockType == GameDefine.GROUND_BLOCK_TYPE.ICE then
		self:playChangeGroundAnimation(true)
	end
end

function MapUnit:playShakeAction(halfFlag)
	if halfFlag == nil then
		halfFlag = false
	end

	if self.groundPic ~= nil and self.mapBlockType ~= GameDefine.GROUND_BLOCK_TYPE.FALL then
		local actSeq = nil
		if halfFlag == true then
			actSeq = cc.Sequence:create(
				cc.MoveBy:create(shakeActUnitTime, cc.p(0, 0-shakeActOffsetY/2)),
				cc.MoveBy:create(shakeActUnitTime, cc.p(0, shakeActOffsetY/2))
			)
		else
			actSeq = cc.Sequence:create(
				cc.MoveBy:create(shakeActUnitTime, cc.p(0, 0-shakeActOffsetY)),
				cc.MoveBy:create(shakeActUnitTime, cc.p(0, shakeActOffsetY))
			)
		end
		if actSeq ~= nil then
			self.groundPic:runAction(actSeq)
		end
	end
end

function MapUnit:checkAndChangeGround(playEffectFlag)
	if playEffectFlag == nil then
		playEffectFlag = false
	end

	if self.parentMapNode.bigfoot_leftTime > 0 then
		if playEffectFlag == true then
			AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.playerTurnBigEffect), false)
			self.parentMapNode.parent.commonJumpSoundEffectIndex = 1
			playEffectFlag = false
		end
	elseif self.parentMapNode.god_leftTime > 0 then
		if playEffectFlag == true then
			AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.playerTurnGodEffect), false)
			self.parentMapNode.parent.commonJumpSoundEffectIndex = 1
			playEffectFlag = false
		end
	end

	if self.mapBlockType == GameDefine.GROUND_BLOCK_TYPE.NORMAL then
		if self.nextId == 0 then
			if playEffectFlag == true then
				AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.groundBlockHasChangedEffect), false)
			end
			self.parentMapNode.parent.commonJumpSoundEffectIndex = 1
			return
		end

		local mapBlockTbl = ConfigManager.mapBlockTbl[tostring(self.nextId)]
		if mapBlockTbl == nil then
			return
		end

		if self.parentMapNode.isBossStage == false then
			if mapBlockTbl.target == 0 then
				if self.parentMapNode ~= nil and self.parentMapNode.addVictoryCount ~= nil then
					self.parentMapNode:addVictoryCount()
				end
			end
		end

		self.id = mapBlockTbl.id
		self.mapBlockType = mapBlockTbl.type or GameDefine.GROUND_BLOCK_TYPE.NORMAL
		self.nextId = mapBlockTbl.target

		--player sound effect
		if playEffectFlag == true then
			AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.groundBlockChangeEffect[self.parentMapNode.parent.commonJumpSoundEffectIndex]), false)
			self.parentMapNode.parent.commonJumpSoundEffectIndex = self.parentMapNode.parent.commonJumpSoundEffectIndex + 1
			if self.parentMapNode.parent.commonJumpSoundEffectIndex > #ResourceDef.GAME_SOUND_LIST.groundBlockChangeEffect then
				self.parentMapNode.parent.commonJumpSoundEffectIndex = 1
			end
		end

		self:changeGroundPic(ResourceManager.ImageName(string.format("%s%0.2d", mapBlockTbl.res, mapBlockTbl.animation.start)))
		self:playChangeGroundAnimation()

		if self.parentMapNode.isBossStage == true then
			self.parentMapNode.isKeyBlockShowFlag = false
		end

	elseif self.mapBlockType == GameDefine.GROUND_BLOCK_TYPE.ICE then


	elseif self.mapBlockType == GameDefine.GROUND_BLOCK_TYPE.FALL then
		if self.nextId ~= nil and self.nextId ~= 0 then
			local mapBlockTbl = ConfigManager.mapBlockTbl[tostring(self.nextId)]
			if mapBlockTbl == nil or mapBlockTbl.target == nil or mapBlockTbl.target ~= 0 then
				if self.parentMapNode ~= nil and self.parentMapNode.addVictoryCount ~= nil then
					self.parentMapNode:addVictoryCount()
				end
			end
		end

		self:fall()

	elseif self.mapBlockType == GameDefine.GROUND_BLOCK_TYPE.SHOW_HIDE then
		local mapBlockTbl = ConfigManager.mapBlockTbl[tostring(self.id)]
		if mapBlockTbl == nil then
			return
		end

		self:changeGroundPic(ResourceManager.ImageName(string.format("%s%0.2d", mapBlockTbl.res, mapBlockTbl.animation.start)))
		self:playChangeGroundAnimation()

		if self.parentMapNode ~= nil and self.parentMapNode.showHideGroundBlocks ~= nil then
			self.parentMapNode:showHideGroundBlocks(self.dominId)
		end
	end

end

function MapUnit:fall()
	self.id = 0

	if self.groundPic ~= nil then
		self.groundPic:runAction(
			cc.Sequence:create(
				cc.MoveBy:create(1.0, cc.p(0, 0-display.height)),
				cc.CallFunc:create(function()
					self.showFlag = false
					self:setVisible(false)
					self.groundPic:setPosition(cc.p(0,0))
				end)
			)
		)
	end
end

function MapUnit:changeShowHideByDomin(id)
	if id == nil or id == 0 then
		return
	end
	if id ~= self.dominId then
		return
	end

	self.showFlag = not self.showFlag
	self:setVisible(self.showFlag)
end

function MapUnit:change2FinalGround()
	if self.id == 0 then
		return
	end

	local blockId = self.id
	local breakFlag = true
	local finalResStr = ""
	while (breakFlag)
	do
		local mapBlockTbl = ConfigManager.mapBlockTbl[tostring(blockId)]
		if mapBlockTbl ~= nil then
			if mapBlockTbl.target == 0 then
				if self.parentMapNode ~= nil and self.parentMapNode.addVictoryCount ~= nil then
					self.parentMapNode:addVictoryCount()
				end
				breakFlag = false
				self.id = mapBlockTbl.id
				finalResStr = string.format("%s%0.2d", mapBlockTbl.res, mapBlockTbl.animation.start)
			else
				blockId = mapBlockTbl.target
			end
		else
			breakFlag = false
			print("----- There is some ground block not found in config table: ", blockId, self.id)
		end
	end

	if finalResStr ~= nil and finalResStr ~= "" then
		self:changeGroundPic(ResourceManager.ImageName(finalResStr))
		self:playChangeGroundAnimation()
	end

end

function MapUnit:change2BossKeyBlock()
	local mapBlockTbl = ConfigManager.mapBlockTbl[tostring(GameConfig.BOSS_STAGE_KEY_BLOCK_ID)]
	if mapBlockTbl == nil or mapBlockTbl.id == nil then
		return false
	end

	if self:changeGroundPic(ResourceManager.ImageName(string.format("%s%0.2d", mapBlockTbl.res, mapBlockTbl.animation.start))) == true then
		self.parentMapNode.isKeyBlockShowFlag = true
		self.nextId = self.id
		self.id = mapBlockTbl.id
		self.mapBlockType = mapBlockTbl.type
		self:playChangeGroundAnimation()
		return true
	end

	return false
end


function MapUnit:changeGroundPic(picFilename)
	if picFilename == nil then
		return false
	end

	if self.groundPic == nil then
		return false
	end

	local tpFrame = ResourceManager.getSpriteFrameFromCache(picFilename)
	if tpFrame ~= nil then
		self.groundPic:setSpriteFrame(tpFrame)
		return true
	end

	return false
end

function MapUnit:playChangeGroundAnimation(repeatFlag)
	if self.groundPic == nil then
		return
	end

	local mapInfo = ConfigManager.mapBlockTbl[tostring(self.id)]
	local aniRes = AnimationManager.getAniFromCacheByName(GameDefine.MAP_BLOCK_ANIMATION_PREFIX .. tostring(self.id))
	if aniRes == nil then
		if mapInfo ~= nil then
			AnimationManager.setAniToCache(	mapInfo.res, 
											mapInfo.animation.start, 
											mapInfo.animation.count, 
											mapInfo.animation.time / mapInfo.animation.count, 
											GameDefine.MAP_BLOCK_ANIMATION_PREFIX .. tostring(self.id))
			aniRes = AnimationManager.getAniFromCacheByName(GameDefine.MAP_BLOCK_ANIMATION_PREFIX .. tostring(self.id))
			if aniRes == nil then
				return
			end
		end
	end

	if aniRes == nil then
		return
	end

	if repeatFlag == nil or repeatFlag == false then
		self.groundPic:runAction(cc.Animate:create(aniRes))
	elseif repeatFlag == true then
		self.groundPic:runAction(cc.RepeatForever:create(cc.Animate:create(aniRes)))
	end
end

function MapUnit:reset()
	self.id = 0
	self.nextId = 0
	self.dominId = 0

	if self.groundPic ~= nil then
		self.groundPic:stopAllActions()
		local tmpPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
		if tmpPic ~= nil then
			self.groundPic:setSpriteFrame(tmpPic:getSpriteFrame())
		end
		self.groundPic:setPosition(cc.p(0,0))
	end

	self.showFlag = true
	self:setVisible(true)
end

return MapUnit
