local GameControlButton = import("app.views.GameControlButton")

local MyBoughtCell = class("MyBoughtCell",function()
	return display.newNode()
end )

function MyBoughtCell:ctor(parent)
	self.parent = parent

	self:init()
end

function MyBoughtCell:init()
	--bgs 
	local layerSize = {width=420, height=170}
	local bgLayer = cc.LayerColor:create(cc.c4b(174,138,90,255), layerSize.width, layerSize.height)
	if bgLayer ~= nil then
		bgLayer:setAnchorPoint(cc.p(0,0))
		bgLayer:setPosition(cc.p(0, 0))
		self:addChild(bgLayer, 1)
	end
	local layerSize2 = {width=410, height=160}
	local bgLayer2 = cc.LayerColor:create(cc.c4b(250,205,137,255), layerSize2.width, layerSize2.height)
	if bgLayer2 ~= nil then
		bgLayer2:setAnchorPoint(cc.p(0,0))
		bgLayer2:setPosition(cc.p(5, 5))
		self:addChild(bgLayer2, 2)
	end

	local layerSize3 = {width=150, height=150}
	local bgLayer3_L = cc.LayerColor:create(cc.c4b(174,138,90,255), layerSize3.width, layerSize3.height)
	if bgLayer3_L ~= nil then
		bgLayer3_L:setAnchorPoint(cc.p(0,0))
		bgLayer3_L:setPosition(cc.p(15, 10))
		self:addChild(bgLayer3_L, 3)
	end

	--main pic
	self.mainPic = display.newSprite(ResourceManager.ImageName(ResourceDef.DEFAULT_SHOP_MAP_PIC))
	if self.mainPic ~= nil then
		self.mainPic:setAnchorPoint(cc.p(0.5,0.5))
		self.mainPic:setPosition(cc.p(15+layerSize3.width/2, 10+layerSize3.height/2))
		self:addChild(self.mainPic, 5)
	end

	--maker name
	self.makerName = display.newTTFLabel({
        text = "",
        font = ResourceDef.FONT_GAME_MAIN,
        size = 22,
        align = cc.TEXT_ALIGNMENT_CENTER,
        color = cc.c3b(90,45,3)
    })
    if self.makerName ~= nil then
        self.makerName:setAnchorPoint(cc.p(0.5,0.5))
        self.makerName:setPosition(cc.p(300, 140))
        self:addChild(self.makerName, 5)
    end

    --time icon
    local timeIcon = display.newSprite(ResourceManager.ImageName(ResourceDef.TIME_ICON))
    if timeIcon ~= nil then
    	timeIcon:setAnchorPoint(cc.p(0.5,0.5))
    	timeIcon:setPosition(cc.p(230, 110))
    	self:addChild(timeIcon, 5)
    end
	-- upload time value
	self.uploadTimeLabel = display.newTTFLabel({
        text = "",
        font = ResourceDef.FONT_GAME_MAIN,
        size = 20,
        align = cc.TEXT_ALIGNMENT_CENTER,
        color = cc.c3b(90,45,3)
    })
    if self.uploadTimeLabel ~= nil then
        self.uploadTimeLabel:setAnchorPoint(cc.p(0,0.5))
        self.uploadTimeLabel:setPosition(cc.p(250, 110))
        self:addChild(self.uploadTimeLabel, 5)
    end
    
    --hot icon
    local hotIcon = display.newSprite(ResourceManager.ImageName(ResourceDef.HOT_ICON))
    if hotIcon ~= nil then
    	hotIcon:setAnchorPoint(cc.p(0.5,0.5))
    	hotIcon:setPosition(cc.p(230, 70))
    	self:addChild(hotIcon, 5)
    end
    --download times
    self.downloadTimesLabel = display.newTTFLabel({
        text = "",
        font = ResourceDef.FONT_GAME_MAIN,
        size = 18,
        align = cc.TEXT_ALIGNMENT_CENTER,
        color = cc.c3b(90,45,3)
    })
    if self.downloadTimesLabel ~= nil then
        self.downloadTimesLabel:setAnchorPoint(cc.p(0,0.5))
        self.downloadTimesLabel:setPosition(cc.p(250, 70))
        self:addChild(self.downloadTimesLabel, 5)
    end

    --challenge button
	self.challengeBtn = GameControlButton.new({
        btnBg = ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[7],
        dstSize = {width=100, height=45},
        buttonFont = LangStringDefine.CHALLENGE_LABEL,
		buttonFontSize = 22,
		buttonFontColor = cc.c3b(90,45,3),
        callback = function ()
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
        	self:challengeMap()
        end
    })
    if self.challengeBtn ~= nil then
		self.challengeBtn:setAnchorPoint(cc.p(0.5, 0.5))
		self.challengeBtn:setPosition(cc.p(240,30))
	    self:addChild(self.challengeBtn, 5)
	end

    --del button
	self.delBtn = GameControlButton.new({
        btnBg = ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[7],
        dstSize = {width=100, height=45},
        buttonFont = LangStringDefine.DELETE_LABEL,
		buttonFontSize = 22,
		buttonFontColor = cc.c3b(90,45,3),
        callback = function ()
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
        	self:delMap()
        end
    })
    if self.delBtn ~= nil then
		self.delBtn:setAnchorPoint(cc.p(0.5, 0.5))
		self.delBtn:setPosition(cc.p(360,30))
	    self:addChild(self.delBtn, 5)
	end

end

function MyBoughtCell:delMap()
	if self.idx == nil or self.data == nil or self.data.mapId == nil then
		return
	end
	if self.parent ~= nil and self.parent.rankNode ~= nil and self.parent.rankNode:isVisible() == true then
		self.parent.rankNode:setVisible(false)
		return 
	end

	--todo
	display.getRunningScene():showTips(LangStringDefine.FUNC_NOT_OPEN)
	
end

function MyBoughtCell:challengeMap()
	if self.idx == nil or self.data == nil or self.data.mapId == nil then
		return
	end
	if self.parent ~= nil and self.parent.rankNode ~= nil and self.parent.rankNode:isVisible() == true then
		self.parent.rankNode:setVisible(false)
		return 
	end

	local curScene = display.getRunningScene()
	if curScene ~= nil then
		UserDataManager.TMP_VALUE = self.parent.tableView:getContentOffset()
		curScene:enterGame(self.data.mapId, true)
	end
end

function MyBoughtCell:resetCell(idx, data)
	if data == nil or type(data) ~= "table" then
		return
	end

	self.idx = idx
	self.data = data
	
	-- if self.mainPic ~= nil then
	-- 	local picPath = cc.FileUtils:getInstance():getWritablePath() .. "map_pic_" .. self.data.mapId .. ".jpg"
	-- 	local tpPic = display.newSprite(picPath)
	-- 	if tpPic ~= nil then
	-- 		self.mainPic:setSpriteFrame(tpPic:getSpriteFrame())
	-- 	end
	-- end

	if self.makerName ~= nil then
		self.makerName:setString(self.data.title)--self.data.maker)
	end

	if self.uploadTimeLabel ~= nil then
		local timeStr = os.date("%Y%m%d", self.data.uploadTime)
		self.uploadTimeLabel:setString(timeStr)
	end
	if self.downloadTimesLabel ~= nil then
		self.downloadTimesLabel:setString(self.data.downloadTimes)
	end

end


return MyBoughtCell
