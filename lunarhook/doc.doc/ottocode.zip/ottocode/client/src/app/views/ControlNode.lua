local GameControlButton = import("app.views.GameControlButton")

local ControlNode = class("ControlNode",function()
	return display.newNode()
end)

local CONTROL_MODE = {
	SLIDE 			= 1, 		--滑动
	STATIC_BUTTON	= 2,		--固定按钮
	VIRTUAL_BUTTON 	= 3,		--全屏虚拟按钮
	JOYSTIC			= 4,		--摇杆
}
local CONTROL_MODE_STR = {
	"滑动",
	"固定按钮",
	"全屏虚拟按钮",
	"摇杆",
}

function ControlNode:ctor(parent)

    self.parent = parent
    self.joystic_record_t = 0
    self.controlMode = nil
    self:registTouchEvent()
    self:init()

	if UserDataManager.PLAYER_SETTINGS.controlmode == "slide" then
		self:changeControlMode(CONTROL_MODE.SLIDE)
	elseif UserDataManager.PLAYER_SETTINGS.controlmode == "button" then
    	self:changeControlMode(CONTROL_MODE.STATIC_BUTTON)
    end
end

function ControlNode:registTouchEvent()
    self.listener = cc.EventListenerTouchOneByOne:create()
    self.listener:setSwallowTouches(true)
    self.listener:registerScriptHandler(handler(self, self.onTouchBegan), cc.Handler.EVENT_TOUCH_BEGAN)
    self.listener:registerScriptHandler(handler(self, self.onTouchMoved), cc.Handler.EVENT_TOUCH_MOVED)
    self.listener:registerScriptHandler(handler(self, self.onTouchEnded), cc.Handler.EVENT_TOUCH_ENDED)
    self.listener:registerScriptHandler(handler(self, self.onTouchCancelled), cc.Handler.EVENT_TOUCH_CANCELLED)
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(self.listener, self)
end


function ControlNode:init()
	

	--static button content
	self.centerNode = display.newNode()
	if self.centerNode ~= nil then
		self.centerNode:setAnchorPoint(cc.p(0.5,0.5))
		self.centerNode:setPosition(cc.p(0, 0))
		self:addChild(self.centerNode, 2)

		--control gan
		local controlGanPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[3])))
		if controlGanPic ~= nil then
			controlGanPic:setAnchorPoint(cc.p(0.5, 1))
			controlGanPic:setPosition(cc.p(0, -60))
			self.centerNode:addChild(controlGanPic)
		end

		--bg
		local centerPic = display.newSprite(ResourceManager.ImageName(ResourceDef.CONTROL_CENTER_BG))
		if centerPic ~= nil then
			centerPic:setAnchorPoint(cc.p(0.5,0.5))
			centerPic:setPosition(cc.p(0, 0))
			self.centerNode:addChild(centerPic, 1)
		end

		local posXOffset = centerPic:getContentSize().width/4
		local posYOffset = centerPic:getContentSize().height/4

		--buttons
		self.button_LeftTop = GameControlButton.new({
	        btnBg = ResourceDef.ARROW,
	        dstSize = {width=118, height=120},
	        pressDown = function ()
	        	self.button_LeftTop:changeBgImg(ResourceDef.ARROW_SELECT)
	        	EventListener.dispatchEvent({name = GameDefine.GAME_CONTROL_EVENT_TYPE.LEFT_TOP})
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_small), false)
	        end,
	        releaseOutsideButton = function()
	        	self.button_LeftTop:changeBgImg(ResourceDef.ARROW)
	        end,
	        callback = function()
	        	self.button_LeftTop:changeBgImg(ResourceDef.ARROW)
	        end
	    })
	    if self.button_LeftTop ~= nil then
			self.button_LeftTop:setAnchorPoint(cc.p(0.5, 0.5))
			self.button_LeftTop:setPosition(cc.p(0-posXOffset, posYOffset))
		    self.centerNode:addChild(self.button_LeftTop, 5)
		end

		self.button_LeftBottom = GameControlButton.new({
	        btnBg = ResourceDef.ARROW,
	        dstSize = {width=118, height=120},
	        pressDown = function ()
	        	self.button_LeftBottom:changeBgImg(ResourceDef.ARROW_SELECT)
	        	self.button_LeftBottom:setScaleY(-0.9)
	        	EventListener.dispatchEvent({name = GameDefine.GAME_CONTROL_EVENT_TYPE.LEFT_BOTTOM})
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_small), false)
	        end,
	        releaseOutsideButton = function()
	        	self.button_LeftBottom:changeBgImg(ResourceDef.ARROW)
	        	self.button_LeftBottom:setScaleY(-1)
	        end,
	        callback = function()
	        	self.button_LeftBottom:changeBgImg(ResourceDef.ARROW)
	        	self.button_LeftBottom:setScaleY(-1)
	        end
	    })
	    if self.button_LeftBottom ~= nil then
			self.button_LeftBottom:setAnchorPoint(cc.p(0.5, 0.5))
			self.button_LeftBottom:setPosition(cc.p(0-posXOffset, 0-posYOffset))
			self.button_LeftBottom:setScaleY(-1)
		    self.centerNode:addChild(self.button_LeftBottom, 5)
		end

		self.button_RightTop = GameControlButton.new({
	        btnBg = ResourceDef.ARROW,
	        dstSize = {width=118, height=120},
	        pressDown = function ()
	        	self.button_RightTop:changeBgImg(ResourceDef.ARROW_SELECT)
	        	self.button_RightTop:setScaleX(-0.9)
	        	EventListener.dispatchEvent({name = GameDefine.GAME_CONTROL_EVENT_TYPE.RIGHT_TOP})
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_small), false)
	        end,
	        releaseOutsideButton = function()
	        	self.button_RightTop:changeBgImg(ResourceDef.ARROW)
	        	self.button_RightTop:setScaleX(-1)
	        end,
	        callback = function()
	        	self.button_RightTop:changeBgImg(ResourceDef.ARROW)
	        	self.button_RightTop:setScaleX(-1)
	        end
	    })
	    if self.button_RightTop ~= nil then
			self.button_RightTop:setAnchorPoint(cc.p(0.5, 0.5))
			self.button_RightTop:setPosition(cc.p(posXOffset, posYOffset))
			self.button_RightTop:setScaleX(-1)
		    self.centerNode:addChild(self.button_RightTop, 5)
		end

		self.button_RightBottom = GameControlButton.new({
	        btnBg = ResourceDef.ARROW,
	        dstSize ={width=118, height=120},
	        pressDown = function ()
	        	self.button_RightBottom:changeBgImg(ResourceDef.ARROW_SELECT)
	        	self.button_RightBottom:setScaleX(-0.9)
	        	self.button_RightBottom:setScaleY(-0.9)
	        	EventListener.dispatchEvent({name = GameDefine.GAME_CONTROL_EVENT_TYPE.RIGHT_BOTTOM})
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_small), false)
	        end,
	        releaseOutsideButton = function()
	        	self.button_RightBottom:changeBgImg(ResourceDef.ARROW)
	        	self.button_RightBottom:setScaleX(-1)
	        	self.button_RightBottom:setScaleY(-1)
	        end,
	        callback = function()
	        	self.button_RightBottom:changeBgImg(ResourceDef.ARROW)
	        	self.button_RightBottom:setScaleX(-1)
	        	self.button_RightBottom:setScaleY(-1)
	        end
	    })
	    if self.button_RightBottom ~= nil then
			self.button_RightBottom:setAnchorPoint(cc.p(0.5, 0.5))
			self.button_RightBottom:setPosition(cc.p(posXOffset, 0-posYOffset))
			self.button_RightBottom:setScaleX(-1)
			self.button_RightBottom:setScaleY(-1)
		    self.centerNode:addChild(self.button_RightBottom, 5)
		end
	end

	--joystic content
	-- self.joysticNode = display.newNode()
	if self.joysticNode ~= nil then
		self.joysticNode:setAnchorPoint(cc.p(0.5, 0.5))
		self.joysticNode:setPosition(cc.p(display.cx, display.cy-200*2))
	    self:addChild(self.joysticNode,3)

	    self.joysticDirection = nil
	    self.joysticMaxRadis = 0
	    self.joysticBgPicList = {}
	    self.joysticBgScaleList = {{1,1},{1,-1},{-1,-1},{-1,1}}
	    for i=1,4 do
	    	self.joysticBgPicList[i] = display.newSprite(ResourceManager.ImageName(ResourceDef.JOYSTIC_BG_PIC))
	    	if self.joysticBgPicList[i] ~= nil then
	    		self.joysticBgPicList[i]:setAnchorPoint(cc.p(0,0))
	    		self.joysticBgPicList[i]:setScaleX(self.joysticBgScaleList[i][1])
	    		self.joysticBgPicList[i]:setScaleY(self.joysticBgScaleList[i][2])
	    		self.joysticBgPicList[i]:setPosition(cc.p(1, 1))
	    		self.joysticBgPicList[i]:setOpacity(170)
	    		self.joysticNode:addChild(self.joysticBgPicList[i], 1)

	    		if i == 1 then
	    			self.joysticMaxRadis = self.joysticBgPicList[i]:getContentSize().width
	    		end
	    	end
	    end
	    self.highlightBgPic = display.newSprite(ResourceManager.ImageName(ResourceDef.JOYSTIC_BG_HIGHLIGHT_PIC))
	    if self.highlightBgPic ~= nil then
	    	self.highlightBgPic:setAnchorPoint(cc.p(0,0))
    		self.highlightBgPic:setScaleX(self.joysticBgScaleList[1][1])
    		self.highlightBgPic:setScaleY(self.joysticBgScaleList[1][2])
    		self.highlightBgPic:setPosition(cc.p(1, 1))
    		self.highlightBgPic:setVisible(false)
    		self.joysticNode:addChild(self.highlightBgPic, 2)
	    end

	    self.joysticCenterPic = display.newSprite(ResourceManager.ImageName(ResourceDef.JOYSTIC_CENTER_PIC))
	    if self.joysticCenterPic ~= nil then
	    	self.joysticCenterPic:setAnchorPoint(cc.p(0.5,0.5))
    		self.joysticCenterPic:setPosition(cc.p(0, 0))
    		self.joysticCenterPic:setOpacity(170)
    		self.joysticNode:addChild(self.joysticCenterPic, 2)
	    end


	end

	--control switch
	-- self.controlSwitchNode = display.newNode()
	if self.controlSwitchNode ~= nil then
		self.controlSwitchNode:setAnchorPoint(cc.p(0.5, 0.5))
		self.controlSwitchNode:setPosition(cc.p(display.width, display.height))
	    self:addChild(self.controlSwitchNode, 5)

	    local tmpTxt = ""
	    if self.controlMode ~= nil then
	    	tmpTxt = CONTROL_MODE_STR[self.controlMode]
	    end
	    self.controlSwitchButtonLabel = display.newTTFLabel({
	        text = tmpTxt,
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 20,
	        color = cc.c3b(0,0,255),
	        align = cc.TEXT_ALIGNMENT_CENTER
	    })
	    if self.controlSwitchButtonLabel ~= nil then
	        self.controlSwitchButtonLabel:setAnchorPoint(cc.p(0.5,0.5))
	        self.controlSwitchButtonLabel:setPosition(cc.p(-250,-50))
	        self.controlSwitchNode:addChild(self.controlSwitchButtonLabel,6)
	    end
	    self.controlSwitchButton = GameControlButton.new({
	        btnBg = ResourceDef.IMAGE_TRANSPARENT,
	        dstSize = {width=108, height=42},
	        callback = function ()
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_small), false)
	        	local dstMode = self.controlMode
	        	if self.controlMode == nil or self.controlMode == CONTROL_MODE.STATIC_BUTTON then
	        		dstMode = CONTROL_MODE.SLIDE
	        	else
	        		dstMode = dstMode + 1
	        	end
	        	self:changeControlMode(dstMode)
	        	if self.controlSwitchButtonLabel ~= nil then
	        		self.controlSwitchButtonLabel:setScale(1)
	        	end
	        end,
	        pressDown = function ()
	        	if self.controlSwitchButtonLabel ~= nil then
	        		self.controlSwitchButtonLabel:setScale(0.9)
	        	end
	        end,
	        releaseOutsideButton = function()
	        	if self.controlSwitchButtonLabel ~= nil then
	        		self.controlSwitchButtonLabel:setScale(1)
	        	end
	        end
	    })
	    if self.controlSwitchButton ~= nil then
			self.controlSwitchButton:setAnchorPoint(cc.p(0.5, 0.5))
			self.controlSwitchButton:setPosition(cc.p(-250,-50))
		    self.controlSwitchNode:addChild(self.controlSwitchButton, 5)
		end
	end

end

function ControlNode:changeControlMode(eMode)
	if self.controlMode == eMode then
		return
	end
	self.controlMode = eMode

	if self.centerNode ~= nil then
		self.centerNode:setVisible(eMode == CONTROL_MODE.STATIC_BUTTON)
	end

	if self.joysticNode ~= nil then
		self.joysticNode:setVisible(eMode == CONTROL_MODE.JOYSTIC)
	end

	if self.controlSwitchButtonLabel ~= nil then
		self.controlSwitchButtonLabel:setString(CONTROL_MODE_STR[self.controlMode])
	end
end


function ControlNode:onTouchBegan(touch, event)
	if self.parent:isVisible() == false then
		return false
	end

	if self.controlMode ~= CONTROL_MODE.SLIDE and self.controlMode ~= CONTROL_MODE.VIRTUAL_BUTTON and self.controlMode ~= CONTROL_MODE.JOYSTIC then
		return false
	end

    local touchPoint = touch:getLocation()
    self.beginTouchPoint = {x=touchPoint.x, y=touchPoint.y}

    if self.controlMode == CONTROL_MODE.VIRTUAL_BUTTON then
    	local eventName = nil
    	if self.beginTouchPoint.y >= display.cy then
    		if self.beginTouchPoint.x >= display.cx then
    			eventName = GameDefine.GAME_CONTROL_EVENT_TYPE.RIGHT_TOP
	    	elseif self.beginTouchPoint.x < display.cx then
	    		eventName = GameDefine.GAME_CONTROL_EVENT_TYPE.LEFT_TOP
	    	end
    	elseif self.beginTouchPoint.y < display.cy then
    		if self.beginTouchPoint.x >= display.cx then
    			eventName = GameDefine.GAME_CONTROL_EVENT_TYPE.RIGHT_BOTTOM
	    	elseif self.beginTouchPoint.x < display.cx then
	    		eventName = GameDefine.GAME_CONTROL_EVENT_TYPE.LEFT_BOTTOM
	    	end
    	end
    	if eventName ~= nil then
			EventListener.dispatchEvent({name = eventName})
		end
	elseif self.controlMode == CONTROL_MODE.JOYSTIC then
		if self.joysticNode ~= nil then
			self.joysticNode:setPosition(cc.p(self.beginTouchPoint.x, self.beginTouchPoint.y))
		end

		if self.updateSchedulerHandler == nil then
			self.updateSchedulerHandler = scheduler.scheduleUpdateGlobal(function(t)
		        self:updateJoystic(t)
		    end)
		end
    end

    return true
end

function ControlNode:onTouchMoved(touch, event)
	local moveTouchPoint = touch:getLocation()

	if self.controlMode == CONTROL_MODE.JOYSTIC then
		if self.joysticNode ~= nil then
			local targetX = moveTouchPoint.x - self.beginTouchPoint.x
			local targetY = moveTouchPoint.y - self.beginTouchPoint.y
			if targetX*targetX + targetY*targetY > self.joysticMaxRadis*self.joysticMaxRadis then
				if targetX ~= 0 then
					local k = targetY/targetX
					local x = math.sqrt(self.joysticMaxRadis*self.joysticMaxRadis / (k*k+1)) * targetX/math.abs(targetX)
					local y = k*x
					targetX = x
					targetY = y
				else
					if targetY > self.joysticMaxRadis then
						targetY = self.joysticMaxRadis
					end
				end
			end

			if self.joysticCenterPic ~= nil then
				self.joysticCenterPic:setPosition(cc.p(targetX, targetY))
			end

			if targetY >= 0 then
	    		if targetX >= 0 then
	    			if self.joysticDirection == nil or self.joysticDirection ~= GameDefine.GAME_CONTROL_EVENT_TYPE.RIGHT_TOP then
	    				self.joysticDirection = GameDefine.GAME_CONTROL_EVENT_TYPE.RIGHT_TOP
	    				if self.highlightBgPic ~= nil then
				    		self.highlightBgPic:setScaleX(self.joysticBgScaleList[1][1])
				    		self.highlightBgPic:setScaleY(self.joysticBgScaleList[1][2])
				    		self.highlightBgPic:setVisible(true)
					    end
	    			end
		    	elseif targetX < 0 then
		    		if self.joysticDirection == nil or self.joysticDirection ~= GameDefine.GAME_CONTROL_EVENT_TYPE.LEFT_TOP then
	    				self.joysticDirection = GameDefine.GAME_CONTROL_EVENT_TYPE.LEFT_TOP
	    				if self.highlightBgPic ~= nil then
				    		self.highlightBgPic:setScaleX(self.joysticBgScaleList[4][1])
				    		self.highlightBgPic:setScaleY(self.joysticBgScaleList[4][2])
				    		self.highlightBgPic:setVisible(true)
					    end
	    			end
		    	end
	    	elseif targetY < 0 then
	    		if targetX >= 0 then
	    			if self.joysticDirection == nil or self.joysticDirection ~= GameDefine.GAME_CONTROL_EVENT_TYPE.RIGHT_BOTTOM then
	    				self.joysticDirection = GameDefine.GAME_CONTROL_EVENT_TYPE.RIGHT_BOTTOM
	    				if self.highlightBgPic ~= nil then
				    		self.highlightBgPic:setScaleX(self.joysticBgScaleList[2][1])
				    		self.highlightBgPic:setScaleY(self.joysticBgScaleList[2][2])
				    		self.highlightBgPic:setVisible(true)
					    end
	    			end
		    	elseif targetX < 0 then
		    		if self.joysticDirection == nil or self.joysticDirection ~= GameDefine.GAME_CONTROL_EVENT_TYPE.LEFT_BOTTOM then
	    				self.joysticDirection = GameDefine.GAME_CONTROL_EVENT_TYPE.LEFT_BOTTOM
	    				if self.highlightBgPic ~= nil then
				    		self.highlightBgPic:setScaleX(self.joysticBgScaleList[3][1])
				    		self.highlightBgPic:setScaleY(self.joysticBgScaleList[3][2])
				    		self.highlightBgPic:setVisible(true)
					    end
	    			end
		    	end
	    	end

		end
    end
end

function ControlNode:onTouchEnded(touch, event)
	if self.controlMode == CONTROL_MODE.JOYSTIC then
		if self.joysticNode ~= nil then			
			self.joysticNode:setPosition(cc.p(display.cx, display.cy-200*2))
		end
		if self.joysticCenterPic ~= nil then
    		self.joysticCenterPic:setPosition(cc.p(0, 0))
	    end

	    if self.highlightBgPic ~= nil then
    		self.highlightBgPic:setVisible(false)
	    end

	    if self.updateSchedulerHandler ~= nil then
	    	scheduler.unscheduleGlobal(self.updateSchedulerHandler)
	    	self.updateSchedulerHandler = nil
	    end
    end

	if self.controlMode ~= CONTROL_MODE.SLIDE then
		return 
	end

	local endTouchPoint = touch:getLocation()
	local vec_x = endTouchPoint.x - self.beginTouchPoint.x
	local vec_y = endTouchPoint.y - self.beginTouchPoint.y

	if vec_x*vec_x + vec_y*vec_y < GameDefine.MIM_CONTROL_SENSE_DISTANT_POW2 then
		return
	end

	local eventName = nil
	if vec_x >= 0 then
		if vec_y >= 0 then
			eventName = GameDefine.GAME_CONTROL_EVENT_TYPE.RIGHT_TOP
		else
			eventName = GameDefine.GAME_CONTROL_EVENT_TYPE.RIGHT_BOTTOM
		end
	else
		if vec_y >= 0 then
			eventName = GameDefine.GAME_CONTROL_EVENT_TYPE.LEFT_TOP
		else
			eventName = GameDefine.GAME_CONTROL_EVENT_TYPE.LEFT_BOTTOM
		end
	end

	if eventName ~= nil then
		EventListener.dispatchEvent({name = eventName})
	end
end


function ControlNode:updateJoystic(t)
	self.joystic_record_t = self.joystic_record_t + t
	if self.joystic_record_t > 0.1 then
		self.joystic_record_t = self.joystic_record_t - 0.1
		if self.joysticDirection ~= nil then
			EventListener.dispatchEvent({name = self.joysticDirection})
		end
	end
end


return ControlNode
