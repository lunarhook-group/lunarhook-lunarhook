local GameControlButton = import("app.views.GameControlButton")

local ConfirmDialogLayer = class("ConfirmDialogLayer",function()
	return display.newNode()
end)

function ConfirmDialogLayer:ctor()
	self:initUI()
end

function ConfirmDialogLayer:initUI()
	--black bg
	local bgColorLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 120), display.width, display.height)
	if bgColorLayer ~= nil then
		bgColorLayer:setAnchorPoint(cc.p(0, 0))
		bgColorLayer:setPosition(cc.p(0, 0))
		self:addChild(bgColorLayer, 1)
	end

	--
	local bg1 = cc.LayerColor:create(cc.c4b(174, 138, 87, 255), display.width-100, 200)
	if bg1 ~= nil then
		bg1:setAnchorPoint(cc.p(0, 0))
		bg1:setPosition(cc.p(display.cx-(display.width-100)/2, display.cy+175-70))
		self:addChild(bg1, 10)
	end
	local bg2 = cc.LayerColor:create(cc.c4b(250, 205, 137, 255), display.width-110, 190)
	if bg2 ~= nil then
		bg2:setAnchorPoint(cc.p(0, 0))
		bg2:setPosition(cc.p(display.cx-(display.width-110)/2, display.cy+175-65))
		self:addChild(bg2, 11)
	end

	local bgCoverBtn = GameControlButton.new({
        btnBg = ResourceDef.IMAGE_TRANSPARENT,
        dstSize = {width=display.width, height=display.height},
        callback = function ()
        end
    })
    if bgCoverBtn ~= nil then
		bgCoverBtn:setAnchorPoint(cc.p(0.5, 0.5))
		bgCoverBtn:setPosition(cc.p(display.cx, display.cy))
	    self:addChild(bgCoverBtn, 1)
	end

	local yesBtn = GameControlButton.new({
        btnBg = ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[8],
        dstSize = {width=146, height=75},
        buttonFont = LangStringDefine.CONFIRM_LAYER_LABEL_YES,
		buttonFontSize = 30,
		buttonFontColor = cc.c3b(90,45,3),
        callback = function ()
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
        	self:confirm()
        end
    })
    if yesBtn ~= nil then
		yesBtn:setAnchorPoint(cc.p(0.5, 0.5))
		yesBtn:setPosition(cc.p(display.cx-120, display.cy+175-135))
	    self:addChild(yesBtn, 11)
	end

	local noBtn = GameControlButton.new({
        btnBg = ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[8],
        dstSize = {width=146, height=75},
        buttonFont = LangStringDefine.CONFIRM_LAYER_LABEL_NO,
		buttonFontSize = 30,
		buttonFontColor = cc.c3b(90,45,3),
        callback = function ()
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
        	self:cancel()
        end
    })
    if noBtn ~= nil then
		noBtn:setAnchorPoint(cc.p(0.5, 0.5))
		noBtn:setPosition(cc.p(display.cx+120, display.cy+175-135))
	    self:addChild(noBtn, 11)
	end

	local ganPosList = {
		{x=display.cx-180, y=display.cy+175-80},
		{x=display.cx-60, y=display.cy+175-80},
		{x=display.cx+60, y=display.cy+175-80},
		{x=display.cx+180, y=display.cy+175-80},
	}
	for i=1, table.nums(ganPosList) do
		local ganPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.PANEL_CONNECT_POLE2)))
		if ganPic ~= nil then
			ganPic:setAnchorPoint(cc.p(0.5, 0.5))
			ganPic:setPosition(cc.p(ganPosList[i].x, ganPosList[i].y))
			self:addChild(ganPic, 13)
		end
	end

	self.strLabel = display.newTTFLabel({
        text = "",
        font = ResourceDef.FONT_GAME_MAIN,
        size = 30,
        color = cc.c3b(90, 45, 3),
        align = cc.TEXT_ALIGNMENT_CENTER
    })
    if self.strLabel ~= nil then
        self.strLabel:setAnchorPoint(cc.p(0.5, 0.5))
        self.strLabel:setPosition(cc.p(display.cx, display.cy+205))
        self:addChild(self.strLabel, 14)
    end
end

function ConfirmDialogLayer:resetLayer(str, cbYes)
	self.confirmCBFunction = cbYes

	if str ~= nil then
		if self.strLabel ~= nil then
			self.strLabel:setString(str)
		end
	end
end

function ConfirmDialogLayer:confirm()
	if self.confirmCBFunction == nil then
		return
	end

	self.confirmCBFunction()
	self:cancel()
end

function ConfirmDialogLayer:cancel()
	self:closeLayer()
end

function ConfirmDialogLayer:openLayer()
	self:setVisible(true)
end

function ConfirmDialogLayer:closeLayer()
	self:setVisible(false)
end

return ConfirmDialogLayer
