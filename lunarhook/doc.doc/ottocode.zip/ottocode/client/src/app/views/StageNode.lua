
local GameControlButton = import("app.views.GameControlButton")

local StageNode = class("StageNode",function()
	return display.newNode()
end )

function StageNode:ctor(stageId)
	
	self:init(stageId)
end

function StageNode:init(stageId)
	self.stageId = stageId
	local stageTblInfo = ConfigManager.stageTbl[tostring(self.stageId)]

	--button
	self.stageButton = GameControlButton.new({
        btnBg = stageTblInfo.pic,
        dstSize = {width=100, height=110},
        buttonFont = self.stageId,
        buttonFontSize = 42,
        callback = function ()
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
        	self:showStageInfo()
        end
    })
    if self.stageButton ~= nil then
		self.stageButton:setAnchorPoint(cc.p(0.5, 0.5))
		self.stageButton:setPosition(cc.p(0,0))
	    self:addChild(self.stageButton)
	end
end

function StageNode:refresh(stageId)
	self.stageId = stageId
	local stageTblInfo = ConfigManager.stageTbl[tostring(self.stageId)]
	

	--todo
	if self.stageButton ~= nil then


	end

end

function StageNode:showStageInfo()
	local curScene = display.getRunningScene()
	if curScene ~= nil then
		curScene:showStageInfo(self.stageId)
	end
end

return StageNode
