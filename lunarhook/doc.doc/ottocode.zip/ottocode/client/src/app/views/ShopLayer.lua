local GameControlButton = import("app.views.GameControlButton")
local ShopItemCell = import("app.views.ShopItemCell")
local MyBoughtCell = import("app.views.MyBoughtCell")

local ShopLayer = class("ShopLayer", BaseLayer)

local SHOP_LAYER_ZORDER_DEFINE = {
	BG = 1,
	GROUND = 2,
	UI_CONTENT = 3,
	UI_CONTENT_POP = 4,
	TIPS = 5,
}

function ShopLayer:ctor()
	ShopLayer.super.ctor(self)

	self.waitDataFlag = true
	self.curShopTypeIndex = 1
	self.shopData = {latest={},faviror={},recommand={}}
	self:initUI()
end

function ShopLayer:initUI()
	--bg content
	self.bgNode = display.newNode()
	if self.bgNode ~= nil then
		self.bgNode:setAnchorPoint(cc.p(0.5,0.5))
		self.bgNode:setPosition(cc.p(0,0))
		self:addChild(self.bgNode, SHOP_LAYER_ZORDER_DEFINE.BG)

		-------bgcolorlayer
		local bgLayerSize = {width=display.width, height=display.height}
		local bgColorLayer = cc.LayerColor:create(cc.c4b(240, 240, 240, 255), bgLayerSize.width, bgLayerSize.height)
		if bgColorLayer ~= nil then
			bgColorLayer:setAnchorPoint(cc.p(0, 0))
			bgColorLayer:setPosition(cc.p(0, 0))
			self.bgNode:addChild(bgColorLayer, 10)
		end

		-------transparent bg pics
		local transparentBgPic1 = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.transparentBg1)))
		if transparentBgPic1 ~= nil then
			transparentBgPic1:setAnchorPoint(cc.p(0, 0))
			local scaleRate = display.height/transparentBgPic1:getContentSize().height
			transparentBgPic1:setScale(scaleRate)
			transparentBgPic1:setPosition(cc.p(0, 0))
			transparentBgPic1:setOpacity(150)
			self.bgNode:addChild(transparentBgPic1, 15)
		end

		-------clouds
		local cloudNode = GameTools.makeMoveClouds(0-display.cx, display.cy+150, display.width*2, display.cy-100)
		if cloudNode ~= nil then
			self.bgNode:addChild(cloudNode, 17)
		end

		-------round small trees
		local roundSmallTreePosList = {
			{x=-30, y=80, zOrder=18,resIdx=2,scale=0.9},
			{x=186, y=58, zOrder=18,resIdx=1,scale=0.8},
			{x=display.cx+36, y=75, zOrder=17,resIdx=2,scale=0.8},
			{x=display.cx+90, y=67, zOrder=18,resIdx=1,scale=0.8},
			{x=display.width-96, y=55, zOrder=18,resIdx=3,scale=0.8},
			{x=display.width-64, y=100, zOrder=17,resIdx=2,scale=0.7},
			{x=display.width-35, y=75, zOrder=17,resIdx=1,scale=0.7},
		}
		for i=1, #roundSmallTreePosList do
			local roundTreePic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.roundSmallTree[roundSmallTreePosList[i].resIdx])))
			if roundTreePic ~= nil then
				roundTreePic:setAnchorPoint(cc.p(0.5, 0.5))
				roundTreePic:setPosition(cc.p(roundSmallTreePosList[i].x, roundSmallTreePosList[i].y))
				roundTreePic:setScale(roundSmallTreePosList[i].scale)
				self.bgNode:addChild(roundTreePic, roundSmallTreePosList[i].zOrder)
			end
		end

		self:makeFloatFlowers(self.bgNode, 20)
	end

	--ground content
	self.groundNode = display.newNode()
	if self.groundNode ~= nil then
		self.groundNode:setAnchorPoint(cc.p(0.5,0.5))
		self.groundNode:setPosition(cc.p(0,0))
		self:addChild(self.groundNode, SHOP_LAYER_ZORDER_DEFINE.GROUND)

		-------ground
		local tmpPosX = 0
		for i=3, 1, -1 do
			local ground = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.groundResList[i])))
			if ground ~= nil then
				ground:setAnchorPoint(cc.p(0, 0))
				ground:setPosition(cc.p(tmpPosX, 0))
				self.groundNode:addChild(ground, 10)
				tmpPosX = tmpPosX + ground:getContentSize().width - 2
			end
		end

		-------carrot
		self.heroCarrotNode = require("app.views.CarrotNode").new(true)
		if self.heroCarrotNode ~= nil then
			self.heroCarrotNode:setPosition(cc.p(display.cx, 10))
			self.groundNode:addChild(self.heroCarrotNode, 5)
		end

		--flagpole
		local flagpolePic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.BG_FLAGPOLE_RES)))
		if flagpolePic ~= nil then
			flagpolePic:setAnchorPoint(cc.p(0.5, 0))
			flagpolePic:setPosition(cc.p(70, 0))
			self.groundNode:addChild(flagpolePic, 6)
		end

		-- my bought button
		self.openMyBoughtBtnNode = display.newNode()
		if self.openMyBoughtBtnNode ~= nil then
			self.openMyBoughtBtnNode:setAnchorPoint(cc.p(0.5,0.5))
			self.openMyBoughtBtnNode:setPosition(cc.p(100, 45))
			self.groundNode:addChild(self.openMyBoughtBtnNode, 8)

			local myBoughtBtnGanPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[2])))
			if myBoughtBtnGanPic ~= nil then
				myBoughtBtnGanPic:setAnchorPoint(cc.p(0, 0))
				myBoughtBtnGanPic:setPosition(cc.p(0, 0))
				self.openMyBoughtBtnNode:addChild(myBoughtBtnGanPic, 1)
			end

			self.myBoughtButton = GameControlButton.new({
		        btnBg = ResourceDef.BUTTON_BG_PANEL_LIST[3].res,
			    dstSize = ResourceDef.BUTTON_BG_PANEL_LIST[3].size,
			    buttonFont = LangStringDefine.HAVE_BOUGHT_MAP_LIST_LABEL,
		        buttonFontSize = 30,
		        buttonFontColor = cc.c3b(255,255,255),
		        callback = function ()
		        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
		        	self:openMyBoughtMaps()
		        end
		    })
		    if self.myBoughtButton ~= nil then
				self.myBoughtButton:setAnchorPoint(cc.p(0.5, 0.5))
				self.myBoughtButton:setPosition(cc.p(40, 90))
				self.myBoughtButton:setRotation(20)
			    self.openMyBoughtBtnNode:addChild(self.myBoughtButton, 2)
			end
		end

		-- shop button
		self.openShopBtnNode = display.newNode()
		if self.openShopBtnNode ~= nil then
			self.openShopBtnNode:setAnchorPoint(cc.p(0.5,0.5))
			self.openShopBtnNode:setPosition(cc.p(100, 45))
			self.groundNode:addChild(self.openShopBtnNode, 8)

			local goShopBtnGanPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[2])))
			if goShopBtnGanPic ~= nil then
				goShopBtnGanPic:setAnchorPoint(cc.p(0, 0))
				goShopBtnGanPic:setPosition(cc.p(0, 0))
				self.openShopBtnNode:addChild(goShopBtnGanPic, 1)
			end

			self.goShopButton = GameControlButton.new({
		        btnBg = ResourceDef.BUTTON_BG_PANEL_LIST[2].res,
			    dstSize = ResourceDef.BUTTON_BG_PANEL_LIST[2].size,
			    buttonFont = LangStringDefine.STAGE_SHOP,
		        buttonFontSize = 30,
		        buttonFontColor = cc.c3b(255,255,255),
		        callback = function ()
		        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
		        	self:openShop()
		        end
		    })
		    if self.goShopButton ~= nil then
				self.goShopButton:setAnchorPoint(cc.p(0.5, 0.5))
				self.goShopButton:setPosition(cc.p(40, 90))
				self.goShopButton:setRotation(20)
			    self.openShopBtnNode:addChild(self.goShopButton, 2)
			end

			self.openShopBtnNode:setRotation(180)
		end

		--right button (return)
		self.returnBtnNode = display.newNode()
		if self.returnBtnNode ~= nil then
			self.returnBtnNode:setAnchorPoint(cc.p(0.5,0.5))
			self.returnBtnNode:setPosition(cc.p(display.width-70, 45))
			self.groundNode:addChild(self.returnBtnNode, 8)

			local returnBtnGanPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[1])))
			if returnBtnGanPic ~= nil then
				returnBtnGanPic:setAnchorPoint(cc.p(1, 0))
				returnBtnGanPic:setPosition(cc.p(0, 0))
				self.returnBtnNode:addChild(returnBtnGanPic, 1)
			end

			local returnButton = GameControlButton.new({
		        btnBg = ResourceDef.BUTTON_BG_PANEL_LIST[1].res,
			    dstSize = ResourceDef.BUTTON_BG_PANEL_LIST[1].size,
			    buttonFont = LangStringDefine.RETURN_LABEL,
		        buttonFontSize = 30,
		        buttonFontColor = cc.c3b(255,255,255),
		        callback = function ()
		        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
		        	self:returnMainLayer()
		        end
		    })
		    if returnButton ~= nil then
				returnButton:setAnchorPoint(cc.p(0.5, 0.5))
				returnButton:setPosition(cc.p(-30, 80))
			    self.returnBtnNode:addChild(returnButton, 2)
			end
		end
	end

	--main list content
	self.mainUINode = display.newNode()
	if self.mainUINode ~= nil then
		self.mainUINode:setAnchorPoint(cc.p(0.5,0.5))
		self.mainUINode:setPosition(cc.p(display.cx, 0))
		self.groundNode:addChild(self.mainUINode, 15)

		local titleBgPanelSize = {width=460, height=110}
		local titleBgPanel = cc.LayerColor:create(cc.c4b(133, 85, 13, 255), titleBgPanelSize.width, titleBgPanelSize.height)
		if titleBgPanel ~= nil then
			titleBgPanel:setAnchorPoint(cc.p(0, 0))
			titleBgPanel:setPosition(cc.p(0-titleBgPanelSize.width/2, 135 + titleBgPanelSize.height/2 + 735))
			self.mainUINode:addChild(titleBgPanel, 1)
		end
		local titleBgPanelSize2 = {width=432, height=80}
		self.titleBgPanel2 = cc.LayerColor:create(cc.c4b(250, 205, 137, 255), titleBgPanelSize2.width, titleBgPanelSize2.height)
		if self.titleBgPanel2 ~= nil then
			self.titleBgPanel2:setAnchorPoint(cc.p(0, 0))
			self.titleBgPanel2:setPosition(cc.p(0-titleBgPanelSize2.width/2, 165 + titleBgPanelSize2.height/2 + 735))
			self.mainUINode:addChild(self.titleBgPanel2, 3)
		end
		self.titleLabel = display.newTTFLabel({
	        text = GameConfig.SHOP_CONTENT[1].name,
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 36,
	        color = cc.c3b(90, 45, 3),
	        align = cc.TEXT_ALIGNMENT_CENTER
	    })
	    if self.titleLabel ~= nil then
	        self.titleLabel:setAnchorPoint(cc.p(0.5, 0.5))
	        self.titleLabel:setPosition(cc.p(0, 242 + 735))
	        self.mainUINode:addChild(self.titleLabel, 5)
	    end

	    self.titleArrowLeftButton = GameControlButton.new({
	        btnBg = ResourceDef.PANEL_ARROW_RES,
		    dstSize = {width=35, height=18},
	        callback = function ()
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
	        	self:preShop()
	        end
	    })
		if self.titleArrowLeftButton ~= nil then 
			self.titleArrowLeftButton:setAnchorPoint(cc.p(0.5,0.5))
			self.titleArrowLeftButton:setPosition(cc.p(-200, 242 + 735))
			self.titleArrowLeftButton:setRotation(90)
			self.mainUINode:addChild(self.titleArrowLeftButton, 5)
		end
		self.titleArrowRightButton = GameControlButton.new({
	        btnBg = ResourceDef.PANEL_ARROW_RES,
		    dstSize = {width=35, height=18},
	        callback = function ()
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
	        	self:nextShop()
	        end
	    })
	    if self.titleArrowRightButton ~= nil then 
			self.titleArrowRightButton:setAnchorPoint(cc.p(0.5,0.5))
			self.titleArrowRightButton:setPosition(cc.p(200, 242 + 735))
			self.titleArrowRightButton:setRotation(-90)
			self.mainUINode:addChild(self.titleArrowRightButton, 5)
		end

	    self.lampNode = {}
	    for i=1, 2 do
	    	self.lampNode[i] = display.newNode()
		    if self.lampNode[i] ~= nil then
		    	self.lampNode[i]:setAnchorPoint(cc.p(0.5,0.5))
		    	self.lampNode[i]:setPosition(cc.p(0, 242 + 735))
		    	self.mainUINode:addChild(self.lampNode[i], 6)

		    	local xx1 = 1
		    	local xx2 = 0
		    	if i == 1 then
		    		xx1 = 1
		    		xx2 = 0
		    	else
		    		xx1 = 0
		    		xx2 = 1
		    	end

		    	for j=1, 23 do
		    		if math.fmod(j, 2) == xx1 then
		    			local lampPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.LAMP_PIC[1])))
						if lampPic ~= nil then
							lampPic:setAnchorPoint(cc.p(0.5, 0.5))
							lampPic:setPosition(cc.p(0-titleBgPanelSize2.width/2-4 + (j-1)*20, (titleBgPanelSize2.height/2+10)))
							self.lampNode[i]:addChild(lampPic)
						end
					end
					if math.fmod(j, 2) == xx2 then
						local lampPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.LAMP_PIC[2])))
						if lampPic ~= nil then
							lampPic:setAnchorPoint(cc.p(0.5, 0.5))
							lampPic:setPosition(cc.p(0-titleBgPanelSize2.width/2-4 + (j-1)*20, (titleBgPanelSize2.height/2+10)))
							self.lampNode[i]:addChild(lampPic)
						end
					end
					if math.fmod(j, 2) == xx1 then
		    			local lampPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.LAMP_PIC[2])))
						if lampPic ~= nil then
							lampPic:setAnchorPoint(cc.p(0.5, 0.5))
							lampPic:setPosition(cc.p(0-titleBgPanelSize2.width/2-4 + (j-1)*20, 0-(titleBgPanelSize2.height/2+5)))
							self.lampNode[i]:addChild(lampPic)
						end
					end
					if math.fmod(j, 2) == xx2 then
						local lampPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.LAMP_PIC[1])))
						if lampPic ~= nil then
							lampPic:setAnchorPoint(cc.p(0.5, 0.5))
							lampPic:setPosition(cc.p(0-titleBgPanelSize2.width/2-4 + (j-1)*20, 0-(titleBgPanelSize2.height/2+5)))
							self.lampNode[i]:addChild(lampPic)
						end
					end
		    	end

		    	for j=1, 4 do
		    		if math.fmod(j, 2) == xx1 then
		    			local lampPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.LAMP_PIC[2])))
						if lampPic ~= nil then
							lampPic:setAnchorPoint(cc.p(0.5, 0.5))
							lampPic:setPosition(cc.p(0-titleBgPanelSize2.width/2-6, titleBgPanelSize2.height/2+10-j*19))
							self.lampNode[i]:addChild(lampPic)
						end
					end
					if math.fmod(j, 2) == xx2 then
						local lampPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.LAMP_PIC[1])))
						if lampPic ~= nil then
							lampPic:setAnchorPoint(cc.p(0.5, 0.5))
							lampPic:setPosition(cc.p(0-titleBgPanelSize2.width/2-6, titleBgPanelSize2.height/2+10-j*19))
							self.lampNode[i]:addChild(lampPic)
						end
					end
					if math.fmod(j, 2) == xx1 then
		    			local lampPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.LAMP_PIC[2])))
						if lampPic ~= nil then
							lampPic:setAnchorPoint(cc.p(0.5, 0.5))
							lampPic:setPosition(cc.p(titleBgPanelSize2.width/2+6, titleBgPanelSize2.height/2+10-j*19))
							self.lampNode[i]:addChild(lampPic)
						end
					end
					if math.fmod(j, 2) == xx2 then
						local lampPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.LAMP_PIC[1])))
						if lampPic ~= nil then
							lampPic:setAnchorPoint(cc.p(0.5, 0.5))
							lampPic:setPosition(cc.p(titleBgPanelSize2.width/2+6, titleBgPanelSize2.height/2+10-j*19))
							self.lampNode[i]:addChild(lampPic)
						end
					end
		    	end

		    	self.lampNode[i]:setVisible(i==1)
		    end
	    end

	    local shopContentBgPanelSize = {width=460, height=680}
		local shopContentBgPanel = cc.LayerColor:create(cc.c4b(133, 85, 13, 255), shopContentBgPanelSize.width, shopContentBgPanelSize.height)
		if shopContentBgPanel ~= nil then
			shopContentBgPanel:setAnchorPoint(cc.p(0, 0))
			shopContentBgPanel:setPosition(cc.p(0-shopContentBgPanelSize.width/2, -80 - shopContentBgPanelSize.height/2 + 635))
			self.mainUINode:addChild(shopContentBgPanel, 1)
		end

		for i=1, 2 do
			local connectPolePic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.PANEL_CONNECT_POLE)))
			if connectPolePic ~= nil then
				connectPolePic:setAnchorPoint(cc.p(0.5, 0.5))
				connectPolePic:setPosition(cc.p(math.pow((-1), i)*200, 175 + 735))
				self.mainUINode:addChild(connectPolePic, 10)
			end
		end

		self.viewArrowTop = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.PANEL_ARROW_RES)))
		if self.viewArrowTop ~= nil then
			self.viewArrowTop:setAnchorPoint(cc.p(0.5,0.5))
			self.viewArrowTop:setPosition(cc.p(0, -100 + shopContentBgPanelSize.height/2 + 735))
			self.viewArrowTop:setRotation(180)
			self.viewArrowTop:setVisible(false)
			self.mainUINode:addChild(self.viewArrowTop, 10)
		end

		self.viewArrowBottom = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.PANEL_ARROW_RES)))
		if self.viewArrowBottom ~= nil then
			self.viewArrowBottom:setAnchorPoint(cc.p(0.5,0.5))
			self.viewArrowBottom:setPosition(cc.p(0, -60 - shopContentBgPanelSize.height/2 + 735))
			self.viewArrowBottom:setVisible(false)
			self.mainUINode:addChild(self.viewArrowBottom, 10)
		end

	end

	self.tableviewType = "shop"
	self:initView()
	self:reqForShop()

	--rank detail layer
	self.rankNode = require("app.views.RankDetailLayer").new()
	if self.rankNode ~= nil then
		self.rankNode:setPosition(cc.p(display.cx, display.cy+100))
		self.rankNode:setVisible(false)
		self:addChild(self.rankNode, SHOP_LAYER_ZORDER_DEFINE.UI_CONTENT_POP)
	end
	
end

function ShopLayer:update(t)
	
	if self.time_record == nil then
		self.time_record = 0
	end
	self.time_record = self.time_record + t
	if self.time_record >= 1 then
		self.time_record = self.time_record - 1
		for i=1, 2 do
		    if self.lampNode[i] ~= nil then
		    	self.lampNode[i]:setVisible(not self.lampNode[i]:isVisible())
		    end
		end
	end


end

function ShopLayer:initView()
	if self.mainUINode == nil then
    	return
    end

	local viewSize = {width=420, height=650}
	self.tableView = cc.TableView:create(cc.size(viewSize.width, viewSize.height))
   	if self.tableView ~= nil then

   		self.tableView:setPosition(cc.p(0-viewSize.width/2, -80-viewSize.height/2 + 630))
	    self.tableView:setAnchorPoint(cc.p(0.5, 0.5))
	    
	    self.tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	   
	    self.tableView:setDelegate()
	    self.tableView:setDataSource()
	    self.tableView:setBounceable(true)
	    self.tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	    
	    self.tableView:registerScriptHandler(function(tbl, cell)
	    	if self.rankNode ~= nil and self.rankNode:isVisible() == true then
	    		self.rankNode:setVisible(false)
	    		return
	    	end

	    	if self.tableviewType == "bought" then
	    		if self.touchEnableFlag == false then
		    		return
		    	end
		    	self.touchEnableFlag = false

	    		if cell.content ~= nil and cell.content["bought"] ~= nil and cell.content["bought"].data ~= nil and cell.content["bought"].data.mapId ~= nil then
	    			AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
	    			self:requestRankInfo(cell.content["bought"].data.mapId, function()
		    			self.touchEnableFlag = true
		    		end)
		    	else
		    		self.touchEnableFlag = true
	    		end
	    	end
	    end, cc.TABLECELL_TOUCHED)
	    self.tableView:registerScriptHandler(function()
	    	return viewSize.width, 180
	    end, cc.TABLECELL_SIZE_FOR_INDEX)
	    self.tableView:registerScriptHandler(function()
	    	if self.tableviewType == "shop" then
	    		return table.nums(self.shopData[GameConfig.SHOP_CONTENT[self.curShopTypeIndex].shopType])
	    	elseif self.tableviewType == "bought" then
	    		return table.nums(self.boughtMapList)
	    	else
	    		return 0
	    	end
	    end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)

	    self.tableView:registerScriptHandler(function()
	    	if self.rankNode ~= nil and self.rankNode:isVisible() == true then
	    		self.rankNode:setVisible(false)
	    		return
	    	end
	    	-- if self.scrollNoticeNode == nil then
		    --     return
		    -- end
		    -- local nowX = self.tableView:getContentOffset().x
		    -- local tmpX = 0
		    -- if GameConfig.IS_IPHONEX == true then
	   		-- 	tmpX = GameConfig.IPHONEX_XPOS*2
	   		-- end
		    -- if nowX >= -65 then
		    --     self.scrollNoticeNode:showOrHideMainIcon(false, true)
		    --     self.scrollNoticeNode:showOrHideMainIcon(true, false)
		    -- elseif nowX <= -3293-(1136-tmpOffsetX-display.width) + 65 + tmpX then
		    --     self.scrollNoticeNode:showOrHideMainIcon(false, false)
		    --     self.scrollNoticeNode:showOrHideMainIcon(true, true)
		    -- else
		    --     self.scrollNoticeNode:showOrHideMainIcon(false, true)
		    --     self.scrollNoticeNode:showOrHideMainIcon(true, true)
		    -- end
		    -- print("=======    ", self.tableView:getContentOffset().x, self.tableView:getContentOffset().y)
	    end, cc.SCROLLVIEW_SCRIPT_SCROLL)

	    self.tableView:registerScriptHandler(function(tbl, idx)
			local keyIdx = idx + 1 
		    local cell = tbl:dequeueCell()
		    local isNewCell = false
		    if nil == cell then
		        cell = cc.TableViewCell:new()
		        isNewCell = true
		    end
		    cell.idx = keyIdx
		    cell.content = {}

		    if self.tableviewType == "shop" then
	    		local shopData = self.shopData[GameConfig.SHOP_CONTENT[self.curShopTypeIndex].shopType][keyIdx]
			   	if isNewCell == true or cell.content["shop"] == nil then
		    		cell.content["shop"] = ShopItemCell.new(self)
		    		if cell.content["shop"] ~= nil then
		    			cell.content["shop"]:setAnchorPoint(cc.p(0.5,0.5))
		    			cell.content["shop"]:setPosition(cc.p(0, 5))
		    			cell:addChild(cell.content["shop"])
		    			cell.content["shop"]:resetCell(shopData)
		    		end
				else
					if cell.content["shop"] ~= nil then
		    			cell.content["shop"]:resetCell(shopData)
		    		end
				end
	    	elseif self.tableviewType == "bought" then
	    		local boughtData = self.boughtMapList[keyIdx]
			   	if isNewCell == true or cell.content["bought"] == nil then
		    		cell.content["bought"] = MyBoughtCell.new(self)
		    		if cell.content["bought"] ~= nil then
		    			cell.content["bought"]:setAnchorPoint(cc.p(0.5,0.5))
		    			cell.content["bought"]:setPosition(cc.p(0, 5))
		    			cell:addChild(cell.content["bought"])
		    			cell.content["bought"]:resetCell(keyIdx, boughtData)
		    		end
				else
					if cell.content["bought"] ~= nil then
		    			cell.content["bought"]:resetCell(keyIdx, boughtData)
		    		end
				end

	    	end

	    	if cell.content["shop"] ~= nil then
	    		cell.content["shop"]:setVisible(self.tableviewType == "shop")
	    	end
	    	if cell.content["bought"] ~= nil then
	    		cell.content["bought"]:setVisible(self.tableviewType == "bought")
	    	end

		    return cell

	    end, cc.TABLECELL_SIZE_AT_INDEX)

	    self.tableView:reloadData()
	    self.mainUINode:addChild(self.tableView, 8)
	    self.tableView:setTouchEnabled(true)
	    self.touchEnableFlag = true
   	end
end

function ShopLayer:preShop()
	if self.waitDataFlag == true then
		return 
	end
	if self.rankNode ~= nil and self.rankNode:isVisible() == true then
		self.rankNode:setVisible(false)
		return 
	end

	self.curShopTypeIndex = self.curShopTypeIndex - 1
	if self.curShopTypeIndex <= 0 then
		self.curShopTypeIndex = #GameConfig.SHOP_CONTENT
	end
	if self.tableView ~= nil then
		self.tableView:reloadData()
	end
    if self.titleLabel ~= nil then
        self.titleLabel:setString(GameConfig.SHOP_CONTENT[self.curShopTypeIndex].name)
    end
end
function ShopLayer:nextShop()
	if self.waitDataFlag == true then
		return 
	end
	if self.rankNode ~= nil and self.rankNode:isVisible() == true then
		self.rankNode:setVisible(false)
		return 
	end

	self.curShopTypeIndex = self.curShopTypeIndex + 1
	if self.curShopTypeIndex > #GameConfig.SHOP_CONTENT then
		self.curShopTypeIndex = 1
	end
	if self.tableView ~= nil then
		self.tableView:reloadData()
	end
	if self.titleLabel ~= nil then
        self.titleLabel:setString(GameConfig.SHOP_CONTENT[self.curShopTypeIndex].name)
    end
end

function ShopLayer:reqForShop()
	local params = {}
	local ret, resp = GameNetWorker.createHttpRequestWithPostParam(GameConfig.SERVER_ADDRESS .. GameConfig.REQUEST_URL.shoplist, params, false)
	if ret == true then
		local shoplist = json.decode(resp)
		if shoplist ~= nil then
			self:parseShopList(shoplist)
			if self.tableView ~= nil then
				self.tableView:reloadData()
			end
			self.waitDataFlag = false
		end
	end
end

function ShopLayer:reqForMapData(mapId, cb)
	local params = {
		mapId = mapId,
	}
	local ret, resp = GameNetWorker.createHttpRequestWithPostParam(GameConfig.SERVER_ADDRESS .. GameConfig.REQUEST_URL.mapInfo, params, false)
	if ret == true then
		local mapInfo = json.decode(resp)
		if mapInfo ~= nil then
			-- dump(mapInfo.pic)
			if mapInfo.pic ~= nil then
				-- GameTools.makeTextureByData("map_pic_" .. mapId .. ".jpg", mapInfo.pic)
				if cb ~= nil then
					cb(mapId)
				end
			end
		end
	end
end

function ShopLayer:reqForBuyMap(mapId)
	if self.rankNode ~= nil and self.rankNode:isVisible() == true then
		self.rankNode:setVisible(false)
		return 
	end

	-- print("----- buy: ", mapId)
	local curScene = display.getRunningScene()
	local params = {
		playerId = UserDataManager.PLAYER_UID,
		mapId = mapId,
	}
	local ret, resp = GameNetWorker.createHttpRequestWithPostParam(GameConfig.SERVER_ADDRESS .. GameConfig.REQUEST_URL.shopbuy, params, false)
	if ret == true then
		local buyRet = json.decode(resp)
		if buyRet ~= nil then
			if buyRet.errorId ~= nil then
				if curScene ~= nil and curScene.showTips ~= nil then
					curScene:showTips(buyRet.errorMsg)
				end
			else
				if buyRet.coin ~= nil then
					UserDataManager.UM_COIN = buyRet.coin
				end
				buyRet.coin = nil
				if buyRet.mapId ~= nil then
					if buyRet.mapData ~= nil then
						UserDataManager.PLAYER_MAP_DOWNLOAD_LIST[tostring(buyRet.mapId)] = buyRet

						local picPath = cc.FileUtils:getInstance():getWritablePath() .. "map_pic_" .. buyRet.mapId .. ".jpg"
						local F, err=io.open(picPath, "r+");
						if err ~= nil then
							-- GameTools.makeTextureByData("map_pic_" .. buyRet.mapId .. ".jpg", buyRet.mapData.pic)
						end
					end

					if self.tableView ~= nil then
						table.insert(self.boughtMapList, 1, buyRet)
						local off = self.tableView:getContentOffset()
						self.tableView:reloadData()
						self.tableView:setContentOffset(off)
					end

					curScene:showTips(LangStringDefine.BUY_COMPLETE)
				end
			end
		else
			print("==== json decode failed! ")
		end
	end
	
end

function ShopLayer:requestRankInfo(mapId, cb)
	if UserDataManager.RANK_LIST[tostring(mapId)] == nil or
       UserDataManager.RANK_LIST[tostring(mapId)].lastReqTime == nil or 
       UserDataManager.RANK_LIST[tostring(mapId)].lastReqTime < os.time() - 30 then

        --request for rank
        local params = {id = mapId}
        local ret, resp = GameNetWorker.createHttpRequestWithPostParam(GameConfig.SERVER_ADDRESS .. GameConfig.REQUEST_URL.rank, params, false)
        if ret == true then
            local respInfo = json.decode(resp)
            if respInfo ~= nil then
                -- dump(respInfo)
                if respInfo.errorId ~= nil then
                    display.getRunningScene():showTips(respInfo.errorMsg)
                else
                    UserDataManager.RANK_LIST[tostring(mapId)] = {
                        myRank = 0,
                        rankInfo = respInfo,
                        lastReqTime = os.time()
                    }

                    for i=1, #respInfo do
                        if tostring(respInfo[i].playerId) == tostring(UserDataManager.PLAYER_UID) then
                            UserDataManager.RANK_LIST[tostring(mapId)].myRank = i
                            break
                        end
                    end

                    if self.rankNode ~= nil then
				    	local rankInfo = {
				    		myRank = "",
							myRecordTime = "",
							myBestStep = "",
							stageRank = {}
				    	}

				    	if UserDataManager.RANK_LIST[tostring(mapId)] ~= nil then
							rankInfo.myRank =UserDataManager.RANK_LIST[tostring(mapId)].myRank

							for i=1, 3 do
								rankInfo.stageRank[i] = {}
					    		if UserDataManager.RANK_LIST[tostring(mapId)].rankInfo[i] ~= nil then
					    			rankInfo.stageRank[i].name = UserDataManager.RANK_LIST[tostring(mapId)].rankInfo[i].playerId
					    			rankInfo.stageRank[i].steps = UserDataManager.RANK_LIST[tostring(mapId)].rankInfo[i].steps
					    		else
					    			rankInfo.stageRank[i].name = ""
					    			rankInfo.stageRank[i].steps = ""
					    		end
					    	end
						end
						if UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(mapId)] ~= nil then
							rankInfo.myRecordTime = UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(mapId)].record_use_time
							rankInfo.myBestStep = UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(mapId)].step
						end
				    	
				    	self.rankNode:setRankInfo(rankInfo)
				    	self.rankNode:setVisible(true)
				    end
                end

                if cb ~= nil then
                	cb()
                end
            end
        end
    else
    	if self.rankNode ~= nil then
	    	local rankInfo = {
	    		myRank = "",
				myRecordTime = "",
				myBestStep = "",
				stageRank = {}
	    	}

	    	if UserDataManager.RANK_LIST[tostring(mapId)] ~= nil then
				rankInfo.myRank =UserDataManager.RANK_LIST[tostring(mapId)].myRank

				for i=1, 3 do
					rankInfo.stageRank[i] = {}
		    		if UserDataManager.RANK_LIST[tostring(mapId)].rankInfo[i] ~= nil then
		    			rankInfo.stageRank[i].name = UserDataManager.RANK_LIST[tostring(mapId)].rankInfo[i].playerId
		    			rankInfo.stageRank[i].steps = UserDataManager.RANK_LIST[tostring(mapId)].rankInfo[i].steps
		    		else
		    			rankInfo.stageRank[i].name = ""
		    			rankInfo.stageRank[i].steps = ""
		    		end
		    	end
			end
			if UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(mapId)] ~= nil then
				rankInfo.myRecordTime = UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(mapId)].record_use_time
				rankInfo.myBestStep = UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(mapId)].step
			end
	    	
	    	self.rankNode:setRankInfo(rankInfo)
	    	self.rankNode:setVisible(true)
	    end

		if cb ~= nil then
        	cb()
        end
    end

end

function ShopLayer:parseShopList(shoplist)
	-- dump(shoplist)
	if shoplist == nil or type(shoplist) ~= "table" then
		return
	end

	self.shopData = {latest={},faviror={},recommand={}}
	for k,v in pairs(shoplist) do
		--latest
		local hasInsertFlag = false
		for i=1, #self.shopData.latest do
			if self.shopData.latest[i].uploadTime <= v.uploadTime then
				table.insert(self.shopData.latest, i, v)
				hasInsertFlag = true
				break
			end
		end
		if hasInsertFlag == false then
			table.insert(self.shopData.latest, v)
		end

		--faviror
		hasInsertFlag = false
		for i=1, #self.shopData.faviror do
			if self.shopData.faviror[i].downloadTimes <= v.downloadTimes then
				table.insert(self.shopData.faviror, i, v)
				hasInsertFlag = true
				break
			end
		end
		if hasInsertFlag == false then
			table.insert(self.shopData.faviror, v)
		end
	end

	--todo
	self.shopData.recommand = self.shopData.faviror

	--
	self.boughtMapList = {}
	for k,v in pairs(UserDataManager.PLAYER_MAP_DOWNLOAD_LIST) do
		self.boughtMapList[#self.boughtMapList+1] = v
	end

end

function ShopLayer:openMyBoughtMaps()
	if self.waitDataFlag == true then
		return 
	end
	if self.rankNode ~= nil and self.rankNode:isVisible() == true then
		self.rankNode:setVisible(false)
		return 
	end

	self.tableviewType = "bought"
	if self.tableView ~= nil then
		self.tableView:reloadData()
	end
	if self.titleLabel ~= nil then
        self.titleLabel:setString(LangStringDefine.MY_BOUGHT_LIST_LABEL)
    end

    if self.titleArrowLeftButton ~= nil then 
		self.titleArrowLeftButton:setVisible(false)
	end
    if self.titleArrowRightButton ~= nil then 
		self.titleArrowRightButton:setVisible(false)
	end
	if self.titleBgPanel2 ~= nil then
		self.titleBgPanel2:setVisible(true)
	end
	for i=1, 2 do
	    if self.lampNode[i] ~= nil then
	    	self.lampNode[i]:setVisible(i==1)
	    end
	end

    if self.openMyBoughtBtnNode ~= nil then
    	self.openMyBoughtBtnNode:runAction(cc.Sequence:create(
    		cc.RotateBy:create(0.1, 180),
    		cc.DelayTime:create(0.1),
    		cc.CallFunc:create(function()
    			if self.openShopBtnNode ~= nil then
    				self.openShopBtnNode:runAction(cc.RotateBy:create(0.1, -180))
    			end
    		end)
    	))
    end
    

end

function ShopLayer:openShop()
	if self.waitDataFlag == true then
		return 
	end
	if self.rankNode ~= nil and self.rankNode:isVisible() == true then
		self.rankNode:setVisible(false)
		return 
	end

	self.tableviewType = "shop"
	self.curShopTypeIndex = 1
	if self.tableView ~= nil then
		self.tableView:reloadData()
	end
	if self.titleLabel ~= nil then
        self.titleLabel:setString(GameConfig.SHOP_CONTENT[self.curShopTypeIndex].name)
    end

    if self.titleArrowLeftButton ~= nil then 
		self.titleArrowLeftButton:setVisible(true)
	end
    if self.titleArrowRightButton ~= nil then 
		self.titleArrowRightButton:setVisible(true)
	end
	if self.titleBgPanel2 ~= nil then
		self.titleBgPanel2:setVisible(true)
	end
	for i=1, 2 do
	    if self.lampNode[i] ~= nil then
	    	self.lampNode[i]:setVisible(i==1)
	    end
	end

    if self.openShopBtnNode ~= nil then
    	self.openShopBtnNode:runAction(cc.Sequence:create(
    		cc.RotateBy:create(0.1, 180),
    		cc.DelayTime:create(0.1),
    		cc.CallFunc:create(function()
    			if self.openMyBoughtBtnNode ~= nil then
    				self.openMyBoughtBtnNode:runAction(cc.RotateBy:create(0.1, -180))
    			end
    		end)
    	))
    end

end

function ShopLayer:onTouchBegan(touch, event)
	if self:isVisible() == false then
		return false
	end

	self.showingRankFlag = false
	if self.rankNode ~= nil then
		self.showingRankFlag = self.rankNode:isVisible()
	end

	if self.showingRankFlag == true then
		return true
	end

	self.touchBeganPoint = touch:getLocation()

	return true
end

function ShopLayer:onTouchMoved(touch, event)
	if self:isVisible() == false then
		return
	end
	if self.showingRankFlag == true then
		return
	end
end

function ShopLayer:onTouchEnded(touch, event)
	if self:isVisible() == false then
		return
	end

	if self.showingRankFlag == true then
		if self.rankNode ~= nil then
			self.rankNode:setVisible(false)
		end
	end
end

function ShopLayer:makeFloatFlowers(node, zorder)
	if node == nil then
		return
	end
	if zorder == nil then
		zorder = 1
	end

	local totalCountRow = 4
	local totalCountColumn = 4
	for i=1, totalCountRow*totalCountColumn do
		local randIdx = math.random(1, #ResourceDef.MAINSCENE_CONTENT.floatFlowers)
		local flower = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.floatFlowers[randIdx])))
		if flower ~= nil then
			flower:setAnchorPoint(cc.p(0.5,0.5))
			flower:setScale(math.random(100, 120)/100)
			node:addChild(flower, zorder)
			flower:runAction(cc.RepeatForever:create(cc.RotateBy:create(1, 360)))

			local rowIdx = math.floor(i/totalCountRow)
			local columnIdx = math.fmod(i, totalCountColumn) + 1
			flower:setPosition(cc.p(math.random(display.width*columnIdx/totalCountColumn, display.width*(columnIdx+1)/totalCountColumn), math.random(display.height*rowIdx/totalCountRow, display.height*(rowIdx+1)/totalCountRow)))

			local offval = 5
			local bez = {
				cc.p(math.random(31-offval, 31+offval), math.random(-124-offval, -124+offval)),
				cc.p(math.random(100-offval, 100+offval), math.random(-138-offval, -138+offval)),
				cc.p(math.random(95-offval, 95+offval), math.random(-100-offval, -100+offval))
			}
			flower:runAction(cc.RepeatForever:create(cc.Sequence:create(
				cc.BezierBy:create(math.random(50, 100) / 10, bez), 
				cc.CallFunc:create(function()
					if flower:getPositionY() < 0 then
						flower:setPosition(cc.p(math.random(-150, display.cx-100), math.random(display.height, display.height+100)))
					end
				end)
			)))
		end
	end
end

function ShopLayer:openLayer(showType)
	if showType == nil then
		showType = "shop"
	end
	if self.rankNode ~= nil then
		self.rankNode:setVisible(false)
	end

	self.tableviewType = showType
	self.curShopTypeIndex = 1
	self:reqForShop()

	if self.tableviewType == "shop" then
		if self.titleLabel ~= nil then
	        self.titleLabel:setString(GameConfig.SHOP_CONTENT[self.curShopTypeIndex].name)
	    end
	    if self.openShopBtnNode ~= nil then
	    	self.openShopBtnNode:setRotation(-180)
	    end
	    if self.openMyBoughtBtnNode ~= nil then
	    	self.openMyBoughtBtnNode:setRotation(0)
	    end
	    if self.titleArrowLeftButton ~= nil then 
			self.titleArrowLeftButton:setVisible(true)
		end
	    if self.titleArrowRightButton ~= nil then 
			self.titleArrowRightButton:setVisible(true)
		end
		if self.titleBgPanel2 ~= nil then
			self.titleBgPanel2:setVisible(true)
		end
		for i=1, 2 do
		    if self.lampNode[i] ~= nil then
		    	self.lampNode[i]:setVisible(i==1)
		    end
		end
	elseif self.tableviewType == "bought" then
		if self.titleLabel ~= nil then
	        self.titleLabel:setString(LangStringDefine.MY_BOUGHT_LIST_LABEL)
	    end
	    if self.openShopBtnNode ~= nil then
	    	self.openShopBtnNode:setRotation(0)
	    end
	    if self.openMyBoughtBtnNode ~= nil then
	    	self.openMyBoughtBtnNode:setRotation(-180)
	    end
	    if self.titleArrowLeftButton ~= nil then 
			self.titleArrowLeftButton:setVisible(false)
		end
	    if self.titleArrowRightButton ~= nil then 
			self.titleArrowRightButton:setVisible(false)
		end
		if self.titleBgPanel2 ~= nil then
			self.titleBgPanel2:setVisible(true)
		end
		for i=1, 2 do
		    if self.lampNode[i] ~= nil then
		    	self.lampNode[i]:setVisible(i==1)
		    end
		end
	end

	self:setVisible(true)

	AudioManager.stopBackgroundMusic(false)
	AudioManager.playBackgroundMusic(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.shopBgMusic), true)
end


function ShopLayer:closeLayer()
	self:setVisible(false)
end

function ShopLayer:returnMainLayer()
	if self.rankNode ~= nil and self.rankNode:isVisible() == true then
		self.rankNode:setVisible(false)
		return 
	end

	local curScene = display.getRunningScene()
	if curScene ~= nil and curScene.returnMainLayer ~= nil then
		AudioManager.stopBackgroundMusic(false)
		curScene:UITransition(function()
			curScene:returnMainLayer()
			AudioManager.stopBackgroundMusic(false)
			AudioManager.playBackgroundMusic(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.mainBGMusic), true)
		end)
	end
end

return ShopLayer
