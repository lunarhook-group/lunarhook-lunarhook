
local GameControlButton = import("app.views.GameControlButton")
local MapUnit = import("app.views.MapUnit")
local MyMakeCell = import("app.views.MyMakeCell")

local StageEditLayer = class("StageEditLayer", BaseLayer)

local GAME_LAYER_ZORDER_DEFINE = {
	BG = 1,
	MAP = 2,
	MODULE = 3,
	GROUND = 4,
	UI_POP = 5,
	TIPS = 6,
	NOTICE = 7,
}

local MAP_RES_TYPE = {
	ground = 1,
	-- monster = 2,
	-- item = 3,
}

-- local bg_select_list = {
-- 	ResourceDef.IMAGE_TRANSPARENT,
-- }

local USE_FOR_TOOL = false
local map_size_list = {
	{
		text = "7x7",
		size = {width=7, height=7}
	},
	{
		text = "10x10",
		size = {width=10, height=10}
	},
	{
		text = "15x15",
		size = {width=15, height=15}
	},
}

local MAX_ROW_COUNT = 5
local MAX_COLUMN_COUNT = 5
local transMidWidth = 200


function StageEditLayer:ctor()
	StageEditLayer.super.ctor(self)
	
	self.curMapBrushType = nil
	self.curMapBrushContentId = nil
	self.moveFlag = false
	self.selectBgIdx = 1
	self.isEditingFlag = false

	self.mapRowCount = MAX_ROW_COUNT
	self.mapRolumnCount = MAX_COLUMN_COUNT

	self.moveDir = nil

	self:initUI()
end

function StageEditLayer:initUI()
	--bg
	self.bgNode = display.newNode()
	if self.bgNode ~= nil then
		self.bgNode:setAnchorPoint(cc.p(0.5,0.5))
		self.bgNode:setPosition(cc.p(0, 0))
		self:addChild(self.bgNode, GAME_LAYER_ZORDER_DEFINE.BG)

		-------bgcolorlayer
		local bgLayerSize = {width=display.width*2+transMidWidth, height=display.height}
		local bgColorLayer = cc.LayerColor:create(cc.c4b(240, 240, 240, 255), bgLayerSize.width, bgLayerSize.height)
		if bgColorLayer ~= nil then
			bgColorLayer:setAnchorPoint(cc.p(0, 0))
			bgColorLayer:setPosition(cc.p(0, 0))
			self.bgNode:addChild(bgColorLayer, 10)
		end

		-------transparent bg pics
		for i=1, 2 do
			local transparentBgPic1 = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.transparentBg1)))
			if transparentBgPic1 ~= nil then
				transparentBgPic1:setAnchorPoint(cc.p(0, 0))
				local scaleRate = display.height/transparentBgPic1:getContentSize().height
				transparentBgPic1:setScale(scaleRate)
				transparentBgPic1:setPosition(cc.p((i-1)*(display.width+transMidWidth), 0))
				transparentBgPic1:setOpacity(150)
				self.bgNode:addChild(transparentBgPic1, 15)
			end
		end

		-------clouds
		local cloudNode = GameTools.makeMoveClouds(0-display.cx, display.cy+150, display.width*3+transMidWidth, display.cy-100)
		if cloudNode ~= nil then
			self.bgNode:addChild(cloudNode, 17)
		end

		-------round small trees
		local roundSmallTreePosList = {
			{x=-30, y=80, zOrder=18,resIdx=2,scale=0.9},
			{x=186, y=58, zOrder=18,resIdx=1,scale=0.8},
			{x=display.cx+36, y=75, zOrder=17,resIdx=2,scale=0.8},
			{x=display.cx+90, y=67, zOrder=18,resIdx=1,scale=0.8},
			{x=display.width-96, y=55, zOrder=18,resIdx=3,scale=0.8},
			{x=display.width-64, y=100, zOrder=17,resIdx=2,scale=0.7},
			{x=display.width-35, y=75, zOrder=17,resIdx=1,scale=0.7},
		}
		for i=1, #roundSmallTreePosList do
			local roundTreePic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.roundSmallTree[roundSmallTreePosList[i].resIdx])))
			if roundTreePic ~= nil then
				roundTreePic:setAnchorPoint(cc.p(0.5, 0.5))
				roundTreePic:setPosition(cc.p(roundSmallTreePosList[i].x, roundSmallTreePosList[i].y))
				roundTreePic:setScale(roundSmallTreePosList[i].scale)
				self.bgNode:addChild(roundTreePic, roundSmallTreePosList[i].zOrder)
			end
		end

		self:makeFloatFlowers(self.bgNode, 20)
	end

	--map
	self.MapEditorNode = display.newNode()
	if self.MapEditorNode ~= nil then
		self.MapEditorNode:setAnchorPoint(cc.p(0.5,0.5))
		self.MapEditorNode:setPosition(cc.p(display.cx+display.width+transMidWidth, display.cy))
		self:addChild(self.MapEditorNode, GAME_LAYER_ZORDER_DEFINE.MAP)

		self.groundNode = display.newNode()
		if self.groundNode ~= nil then
			self.groundNode:setAnchorPoint(cc.p(0.5,0.5))
			self.groundNode:setPosition(cc.p(0, 0))
			self.MapEditorNode:addChild(self.groundNode)
			-- self:createDefaultMap(self.mapRowCount, self.mapRolumnCount)
		end	
	end

	--module node
	self.moduleNode = display.newNode()
	if self.moduleNode ~= nil then
		self.moduleNode:setAnchorPoint(cc.p(0.5,0.5))
		self.moduleNode:setPosition(cc.p(display.width+transMidWidth, display.height))
		self:addChild(self.moduleNode, GAME_LAYER_ZORDER_DEFINE.MODULE)
		self:initModuleContent()
	end


	--bottom node
	self.bottomNode = display.newNode()
	if self.bottomNode ~= nil then
		self.bottomNode:setAnchorPoint(cc.p(0.5,0.5))
		self.bottomNode:setPosition(cc.p(0, 0))
		self:addChild(self.bottomNode, GAME_LAYER_ZORDER_DEFINE.GROUND)
		self:initBottomContent()
	end

end

function StageEditLayer:resetMap()
	self.mapUnitList = {}
	if self.groundNode ~= nil then
		self.groundNode:removeAllChildren()
		self.groundNode:setScale(1)
	end

	self.mapRowCount = MAX_ROW_COUNT
	self.mapRolumnCount = MAX_COLUMN_COUNT
	if self.tableView ~= nil then
		self.tableView:setContentOffset(cc.p(0,0), true)
	end
end

function StageEditLayer:initModuleContent()
	local bgPanel =  display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.GAME_TITLE_BG_PANEL)))
	if bgPanel ~= nil then
		bgPanel:setAnchorPoint(cc.p(0.5, 0.5))
		bgPanel:setPosition(cc.p(display.cx, -75))
		bgPanel:setScaleX((display.width-50)/bgPanel:getContentSize().width)
		self.moduleNode:addChild(bgPanel)
	end

	self.buttonMapRes = {}

	self:initView()


	local eraserPos = {x=display.width - GameDefine.GROUND_BLOCK_WIDTH/4 - 50, y=-75}
	local eraserBg1 = cc.LayerColor:create(cc.c4b(226, 235, 222, 255), 82, 82)
	if eraserBg1 ~= nil then
		eraserBg1:setAnchorPoint(cc.p(0.5,0.5))
		eraserBg1:setPosition(cc.p(eraserPos.x-82/2, eraserPos.y-82/2))
		self.moduleNode:addChild(eraserBg1, 1)
	end
	local eraserBg2 = cc.LayerColor:create(cc.c4b(103, 205, 43, 255), 50, 82)
	if eraserBg2 ~= nil then
		eraserBg2:setAnchorPoint(cc.p(0.5,0.5))
		eraserBg2:setPosition(cc.p(eraserPos.x-50/2, eraserPos.y-82/2))
		self.moduleNode:addChild(eraserBg2, 2)
	end
	local eraserBg3 = cc.LayerColor:create(cc.c4b(103, 205, 43, 255), 82, 50)
	if eraserBg3 ~= nil then
		eraserBg3:setAnchorPoint(cc.p(0.5,0.5))
		eraserBg3:setPosition(cc.p(eraserPos.x-82/2, eraserPos.y-50/2))
		self.moduleNode:addChild(eraserBg3, 3)
	end
	self.eraserBg = cc.LayerColor:create(cc.c4b(103, 205, 43, 255), 82, 82)
	if self.eraserBg ~= nil then
		self.eraserBg:setAnchorPoint(cc.p(0.5,0.5))
		self.eraserBg:setPosition(cc.p(eraserPos.x-82/2, eraserPos.y-82/2))
		self.moduleNode:addChild(self.eraserBg, 4)
		self.eraserBg:setScale(1)
	end

	self.buttonMapRes["eraser"] = GameControlButton.new({
        btnBg = string.format("%s%0.2d", ConfigManager.mapBlockTbl["0"].res, ConfigManager.mapBlockTbl["0"].animation.start),
        dstSize = {width=75, height=75},
        pressedScale = 1,
        pressDown = function()
        	self.eraserBg:setScale(0.9)
        end,
        callback = function ()
        	self.moveFlag = false
        	self.curMapBrushType = "clear"
			self.curMapBrushContentId = 0

			if self.selectedCell ~= nil then
	    		self.selectedCell.eraserBg:setScale(1.0)
	    		self.selectedCell = nil
	    	end
        end
    })
    if self.buttonMapRes["eraser"] ~= nil then
		self.buttonMapRes["eraser"]:setAnchorPoint(cc.p(0.5, 0.5))
		self.buttonMapRes["eraser"]:setPosition(cc.p(eraserPos.x, eraserPos.y))
	    self.moduleNode:addChild(self.buttonMapRes["eraser"], 5)
	end

end

function StageEditLayer:initView()
	if self.moduleNode == nil then
		return
	end

	local viewSize = {width=420, height=100}
	self.tableView = cc.TableView:create(cc.size(viewSize.width, viewSize.height))
   	if self.tableView ~= nil then

   		self.tableView:setPosition(cc.p(display.cx-viewSize.width/2-50, -65-viewSize.height/2))
	    self.tableView:setAnchorPoint(cc.p(0, 0))
	    
	    self.tableView:setDirection(cc.SCROLLVIEW_DIRECTION_HORIZONTAL)
	   
	    self.tableView:setDelegate()
	    self.tableView:setDataSource()
	    self.tableView:setBounceable(true)
	    
	    self.tableView:registerScriptHandler(function(tbl, cell)
	    	-- print("------- viewl cell touched ---- ", cell.idx, cell.resName)

	    	if self.selectedCell ~= nil then
	    		self.selectedCell.eraserBg:setScale(1.0)
	    	end
	    	if self.curMapBrushContentId == 0 then
	    		self.eraserBg:setScale(1.0)
	    	end

	    	self.moveFlag = false
	    	self.curMapBrushContentId = cell.idx
	    	self.curMapBrushType = "ground"

	    	if cell.eraserBg ~= nil then
	    		cell.eraserBg:setScale(0.9)
	    	end
	    	self.selectedCell = cell

	    end, cc.TABLECELL_TOUCHED)
	    self.tableView:registerScriptHandler(function()
	    	return 85, 85
	    end, cc.TABLECELL_SIZE_FOR_INDEX)
	    self.tableView:registerScriptHandler(function()
	    	for i=1, 99 do
	    		local tblInfo = ConfigManager.mapBlockTbl[tostring(i)]
	    		if tblInfo == nil then
	    			return i-1
	    		end
	    	end
	    	return 0
	    end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)

	    self.tableView:registerScriptHandler(function()
	    	-- if self.scrollNoticeNode == nil then
		    --     return
		    -- end
		    -- local nowX = self.tableView:getContentOffset().x
		    -- local tmpX = 0
		    -- if GameConfig.IS_IPHONEX == true then
	   		-- 	tmpX = GameConfig.IPHONEX_XPOS*2
	   		-- end
		    -- if nowX >= -65 then
		    --     self.scrollNoticeNode:showOrHideMainIcon(false, true)
		    --     self.scrollNoticeNode:showOrHideMainIcon(true, false)
		    -- elseif nowX <= -3293-(1136-tmpOffsetX-display.width) + 65 + tmpX then
		    --     self.scrollNoticeNode:showOrHideMainIcon(false, false)
		    --     self.scrollNoticeNode:showOrHideMainIcon(true, true)
		    -- else
		    --     self.scrollNoticeNode:showOrHideMainIcon(false, true)
		    --     self.scrollNoticeNode:showOrHideMainIcon(true, true)
		    -- end
		    -- print("=======    ", self.tableView:getContentOffset().x, self.tableView:getContentOffset().y)
	    end, cc.SCROLLVIEW_SCRIPT_SCROLL)

	    self.tableView:registerScriptHandler(function(tbl, idx)
			local keyIdx = idx + 1 
		    local cell = tbl:dequeueCell()
		    local isNewCell = false
		    if nil == cell then
		        cell = cc.TableViewCell:new()
		        isNewCell = true
		    end
		    cell.idx = keyIdx

		    if isNewCell == true then
		    	local offsetX = 85/2
			    local offsetY = 85/2
		    	local eraserPos = {x=offsetX, y=offsetY}
				local eraserBg1 = cc.LayerColor:create(cc.c4b(226, 235, 222, 255), 82, 82)
				if eraserBg1 ~= nil then
					eraserBg1:setAnchorPoint(cc.p(0.5,0.5))
					eraserBg1:setPosition(cc.p(eraserPos.x-82/2, eraserPos.y-82/2))
					cell:addChild(eraserBg1, 1)
				end
				local eraserBg2 = cc.LayerColor:create(cc.c4b(90, 45, 3, 255), 50, 82)
				if eraserBg2 ~= nil then
					eraserBg2:setAnchorPoint(cc.p(0.5,0.5))
					eraserBg2:setPosition(cc.p(eraserPos.x-50/2, eraserPos.y-82/2))
					cell:addChild(eraserBg2, 2)
				end
				local eraserBg3 = cc.LayerColor:create(cc.c4b(90, 45, 3, 255), 82, 50)
				if eraserBg3 ~= nil then
					eraserBg3:setAnchorPoint(cc.p(0.5,0.5))
					eraserBg3:setPosition(cc.p(eraserPos.x-82/2, eraserPos.y-50/2))
					cell:addChild(eraserBg3, 3)
				end
				cell.eraserBg = cc.LayerColor:create(cc.c4b(90, 45, 3, 255), 82, 82)
				if cell.eraserBg ~= nil then
					cell.eraserBg:setAnchorPoint(cc.p(0.5,0.5))
					cell.eraserBg:setPosition(cc.p(eraserPos.x-82/2, eraserPos.y-82/2))
					cell:addChild(cell.eraserBg, 4)
					cell.eraserBg:setScale(1)
				end

				if ConfigManager.mapBlockTbl[tostring(keyIdx)] ~= nil then
					local resName = string.format("%s%0.2d", ConfigManager.mapBlockTbl[tostring(keyIdx)].res, ConfigManager.mapBlockTbl[tostring(keyIdx)].animation.start)
				    cell.groundBlockPic = display.newSprite(ResourceManager.ImageName(resName))
				    if cell.groundBlockPic ~= nil then
				    	cell.groundBlockPic:setAnchorPoint(cc.p(0.5,0.5))
				    	cell.groundBlockPic:setPosition(cc.p(offsetX,offsetY))
				    	cell.groundBlockPic:setScale(75/cell.groundBlockPic:getContentSize().width)
				    	cell:addChild(cell.groundBlockPic, 5)
				    end
				    cell.resName = resName
				end

			else
				if cell.groundBlockPic ~= nil then
					if ConfigManager.mapBlockTbl[tostring(keyIdx)] ~= nil then
						local resName = string.format("%s%0.2d", ConfigManager.mapBlockTbl[tostring(keyIdx)].res, ConfigManager.mapBlockTbl[tostring(keyIdx)].animation.start)
						local tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(resName))
						if tpFrame ~= nil then
							cell.groundBlockPic:setSpriteFrame(tpFrame)
						end
						cell.resName = resName
					end
				end
			end

			if self.selectedCell == cell and cell.idx ~= self.curMapBrushContentId then
				self.selectedCell = nil
				if cell.eraserBg ~= nil then
		    		cell.eraserBg:setScale(1.0)
		    	end
		    end
			if self.curMapBrushContentId == cell.idx then
	    		self.selectedCell = cell
	    		if cell.eraserBg ~= nil then
		    		cell.eraserBg:setScale(0.9)
		    	end
	    	end

		    return cell

	    end, cc.TABLECELL_SIZE_AT_INDEX)

	    self.tableView:reloadData()
	    self.moduleNode:addChild(self.tableView, 10)

	    -- --scroll node
		-- self.scrollNoticeNode = GameTools.getScrollNoticeNode(false, viewSize.width-30)
		-- if self.scrollNoticeNode ~= nil then
		-- 	self.scrollNoticeNode:setPosition(cc.p(self.tableView:getPositionX()+25, viewSize.height/2+0))
		-- 	self.viewNode:addChild(self.scrollNoticeNode, 11)
		-- 	--default
		-- 	self.scrollNoticeNode:showOrHideMainIcon(false, false)
		-- 	self.scrollNoticeNode:showOrHideMainIcon(true, true)
		-- end
   	end
end

function StageEditLayer:initBottomContent()
	-------ground
	local tmpPosX = 0
	local groundResIndexList = {3,2,3,2}
	for i=1, #groundResIndexList do
		local ground = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.groundResList[groundResIndexList[i]])))
		if ground ~= nil then
			ground:setAnchorPoint(cc.p(0, 0))
			ground:setPosition(cc.p(tmpPosX, 0))
			self.bottomNode:addChild(ground, 10)
			if i == 2 then
				ground:setScaleX(transMidWidth/ground:getContentSize().width)
				tmpPosX = tmpPosX + transMidWidth - 2
			else
				tmpPosX = tmpPosX + ground:getContentSize().width - 2
			end
		end
	end

	-------carrot
	self.heroCarrotNode = require("app.views.CarrotNode").new(true)
	if self.heroCarrotNode ~= nil then
		self.heroCarrotNode:setPosition(cc.p(display.cx, 10))
		self.bottomNode:addChild(self.heroCarrotNode, 5)
	end

	--flagpole
	local flagpolePic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.BG_FLAGPOLE_RES)))
	if flagpolePic ~= nil then
		flagpolePic:setAnchorPoint(cc.p(0.5, 0))
		flagpolePic:setPosition(cc.p(70, 0))
		self.bottomNode:addChild(flagpolePic, 6)
	end

	-- edit button
	self.editBtnNode = display.newNode()
	if self.editBtnNode ~= nil then
		self.editBtnNode:setAnchorPoint(cc.p(0.5,0.5))
		self.editBtnNode:setPosition(cc.p(100, 45))
		self.editBtnNode:setRotation(180)
		self.bottomNode:addChild(self.editBtnNode, 8)

		local editBtnGanPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[2])))
		if editBtnGanPic ~= nil then
			editBtnGanPic:setAnchorPoint(cc.p(0, 0))
			editBtnGanPic:setPosition(cc.p(0, 0))
			self.editBtnNode:addChild(editBtnGanPic, 1)
		end

		self.editButton = GameControlButton.new({
	        btnBg = ResourceDef.BUTTON_BG_PANEL_LIST[2].res,
		    dstSize = ResourceDef.BUTTON_BG_PANEL_LIST[2].size,
		    buttonFont = LangStringDefine.EDITOR_LABEL,
	        buttonFontSize = 30,
	        buttonFontColor = cc.c3b(255,255,255),
	        callback = function ()
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
	        	self:closeMyMakeList()
	        end
	    })
	    if self.editButton ~= nil then
			self.editButton:setAnchorPoint(cc.p(0.5, 0.5))
			self.editButton:setPosition(cc.p(30, 90))
			self.editButton:setRotation(10)
		    self.editBtnNode:addChild(self.editButton, 2)
		end
	end

	--return button
	self.returnBtnNode = display.newNode()
	if self.returnBtnNode ~= nil then
		self.returnBtnNode:setAnchorPoint(cc.p(0.5,0.5))
		self.returnBtnNode:setPosition(cc.p(display.width-70, 45))
		self.bottomNode:addChild(self.returnBtnNode, 8)

		local returnBtnGanPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[1])))
		if returnBtnGanPic ~= nil then
			returnBtnGanPic:setAnchorPoint(cc.p(1, 0))
			returnBtnGanPic:setPosition(cc.p(0, 0))
			self.returnBtnNode:addChild(returnBtnGanPic, 1)
		end

		local returnButton = GameControlButton.new({
	        btnBg = ResourceDef.BUTTON_BG_PANEL_LIST[1].res,
		    dstSize = ResourceDef.BUTTON_BG_PANEL_LIST[1].size,
		    buttonFont = LangStringDefine.RETURN_LABEL,
	        buttonFontSize = 30,
	        buttonFontColor = cc.c3b(255,255,255),
	        callback = function ()
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
	        	self:returnMainLayer()
	        end
	    })
	    if returnButton ~= nil then
			returnButton:setAnchorPoint(cc.p(0.5, 0.5))
			returnButton:setPosition(cc.p(-30, 80))
		    self.returnBtnNode:addChild(returnButton, 2)
		end
	end

	--return button2
	self.returnBtnNode2 = display.newNode()
	if self.returnBtnNode2 ~= nil then
		self.returnBtnNode2:setAnchorPoint(cc.p(0.5,0.5))
		self.returnBtnNode2:setPosition(cc.p(display.width*2+transMidWidth-50, 45))
		self.bottomNode:addChild(self.returnBtnNode2, 8)

		local returnBtnGanPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[1])))
		if returnBtnGanPic ~= nil then
			returnBtnGanPic:setAnchorPoint(cc.p(1, 0))
			returnBtnGanPic:setPosition(cc.p(0, 0))
			self.returnBtnNode2:addChild(returnBtnGanPic, 1)
		end

		local returnButton = GameControlButton.new({
	        btnBg = ResourceDef.BUTTON_BG_PANEL_LIST[1].res,
		    dstSize = ResourceDef.BUTTON_BG_PANEL_LIST[1].size,
		    buttonFont = LangStringDefine.RETURN_LABEL,
	        buttonFontSize = 30,
	        buttonFontColor = cc.c3b(255,255,255),
	        callback = function ()
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
	        	display.getRunningScene():showConfirmLayer(LangStringDefine.CONFIRM_CONTENT_LABEL[1], function()
	        		self:returnEditHomePage()
	        	end)
	        end
	    })
	    if returnButton ~= nil then
			returnButton:setAnchorPoint(cc.p(0.5, 0.5))
			returnButton:setPosition(cc.p(-30, 80))
		    self.returnBtnNode2:addChild(returnButton, 2)
		end
	end

	self.mapSizeSelectNode = display.newNode()
	if self.mapSizeSelectNode ~= nil then
		self.mapSizeSelectNode:setAnchorPoint(cc.p(0.5,0.5))
		self.mapSizeSelectNode:setPosition(cc.p(165, 1000))
		self.bottomNode:addChild(self.mapSizeSelectNode, 15)

		for i=1, #map_size_list + 1 do
			local btnBgPanelPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.funcPanelBtnRes)))
			if btnBgPanelPic ~= nil then
				btnBgPanelPic:setAnchorPoint(cc.p(0.5,0.5))
				btnBgPanelPic:setPosition(cc.p(0, 0-(i-1)*100-30))
				self.mapSizeSelectNode:addChild(btnBgPanelPic, 1)
			end

			if i <= #map_size_list then
				for j=1, 2 do
					local connectPolePic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.PANEL_CONNECT_POLE)))
					if connectPolePic ~= nil then
						connectPolePic:setAnchorPoint(cc.p(0.5, 0.5))
						connectPolePic:setPosition(cc.p(math.pow((-1), j)*50+3, 0-(i-1)*100-30-48))
						self.mapSizeSelectNode:addChild(connectPolePic, 5)
					end
				end
				local sizeButton = GameControlButton.new({
			        btnBg = ResourceDef.IMAGE_TRANSPARENT,
				    dstSize = {width=130, height=60},
				    buttonFont = map_size_list[i].text,
			        buttonFontSize = 30,
			        buttonFontColor = cc.c3b(255,255,255),
			        callback = function ()
			        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)

			        	self.mapRowCount = map_size_list[i].size.width
						self.mapRolumnCount = map_size_list[i].size.height
						self:createDefaultMap(self.mapRowCount, self.mapRolumnCount)

						self:runAction(cc.MoveBy:create(0.5, cc.p(-display.width-transMidWidth, 0)))
						self.isEditingFlag = true
			        end
			    })
			    if sizeButton ~= nil then
					sizeButton:setAnchorPoint(cc.p(0.5, 0.5))
					sizeButton:setPosition(cc.p(0, 0-(i-1)*100-30))
				    self.mapSizeSelectNode:addChild(sizeButton, 3)
				end
			else
				local changeModeButton = GameControlButton.new({
			        btnBg = ResourceDef.IMAGE_TRANSPARENT,
				    dstSize = {width=130, height=60},
				    buttonFont = LangStringDefine.MADE_BY_ME_LABEL,
			        buttonFontSize = 30,
			        buttonFontColor = cc.c3b(255,255,255),
			        callback = function ()
			        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
			        	self:openMyMakeList()
			        end
			    })
			    if changeModeButton ~= nil then
					changeModeButton:setAnchorPoint(cc.p(0.5, 0.5))
					changeModeButton:setPosition(cc.p(0, 0-(i-1)*100-30))
				    self.mapSizeSelectNode:addChild(changeModeButton, 3)
				end
			end
		end
	end

	self.mainUINode = display.newNode()
	if self.mainUINode ~= nil then
		self.mainUINode:setAnchorPoint(cc.p(0.5,0.5))
		self.mainUINode:setPosition(cc.p(display.cx, 0))
		self.mainUINode:setVisible(false)
		self.bottomNode:addChild(self.mainUINode, 15)

		local titleBgPanelSize = {width=460, height=110}
		local titleBgPanel = cc.LayerColor:create(cc.c4b(133, 85, 13, 255), titleBgPanelSize.width, titleBgPanelSize.height)
		if titleBgPanel ~= nil then
			titleBgPanel:setAnchorPoint(cc.p(0, 0))
			titleBgPanel:setPosition(cc.p(0-titleBgPanelSize.width/2, 135 + titleBgPanelSize.height/2 + 735))
			self.mainUINode:addChild(titleBgPanel, 1)
		end
		local titleBgPanelSize2 = {width=432, height=80}
		self.titleBgPanel2 = cc.LayerColor:create(cc.c4b(250, 205, 137, 255), titleBgPanelSize2.width, titleBgPanelSize2.height)
		if self.titleBgPanel2 ~= nil then
			self.titleBgPanel2:setAnchorPoint(cc.p(0, 0))
			self.titleBgPanel2:setPosition(cc.p(0-titleBgPanelSize2.width/2, 165 + titleBgPanelSize2.height/2 + 735))
			self.mainUINode:addChild(self.titleBgPanel2, 3)
		end

		local titleIcon = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
		if titleIcon ~= nil then
			titleIcon:setAnchorPoint(cc.p(0.5,0.5))
			titleIcon:setScale(0.5)
			titleIcon:setPosition(cc.p(-115, 242 + 735))
			self.mainUINode:addChild(titleIcon, 5)
			local gearRotateAni = AnimationManager.getAniFromCacheByName("gear_rotate_animation")
			if gearRotateAni == nil then
				AnimationManager.setAniToCache(ResourceDef.TITLE_SHADING_RES_PARAM.res, 
								   ResourceDef.TITLE_SHADING_RES_PARAM.start, 
								   ResourceDef.TITLE_SHADING_RES_PARAM.count, 
								   ResourceDef.TITLE_SHADING_RES_PARAM.time, 
								   "gear_rotate_animation")
				gearRotateAni = AnimationManager.getAniFromCacheByName("gear_rotate_animation")
			end
			if gearRotateAni ~= nil then
				titleIcon:runAction(cc.RepeatForever:create(cc.Animate:create(gearRotateAni)))
			end
		end
		local titleIcon2 = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
		if titleIcon2 ~= nil then
			titleIcon2:setAnchorPoint(cc.p(0.5,0.5))
			titleIcon2:setScaleX(-0.25)
			titleIcon2:setScaleY(0.25)
			titleIcon2:setPosition(cc.p(-115+15, 242 + 750))
			self.mainUINode:addChild(titleIcon2, 5)
			local gearRotateAni = AnimationManager.getAniFromCacheByName("gear_rotate_animation")
			if gearRotateAni ~= nil then
				titleIcon2:runAction(cc.RepeatForever:create(cc.Animate:create(gearRotateAni)))
			end
		end


		local titleLabel = display.newTTFLabel({
	        text = LangStringDefine.MY_MADE_LIST_LABEL,
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 40,
	        color = cc.c3b(52, 36, 13),
	        align = cc.TEXT_ALIGNMENT_CENTER
	    })
	    if titleLabel ~= nil then
	        titleLabel:setAnchorPoint(cc.p(0.5, 0.5))
	        titleLabel:setPosition(cc.p(0, 242 + 735))
	        self.mainUINode:addChild(titleLabel, 5)
	    end

	    local shopContentBgPanelSize = {width=460, height=680}
		local shopContentBgPanel = cc.LayerColor:create(cc.c4b(133, 85, 13, 255), shopContentBgPanelSize.width, shopContentBgPanelSize.height)
		if shopContentBgPanel ~= nil then
			shopContentBgPanel:setAnchorPoint(cc.p(0, 0))
			shopContentBgPanel:setPosition(cc.p(0-shopContentBgPanelSize.width/2, -80 - shopContentBgPanelSize.height/2 + 635))
			self.mainUINode:addChild(shopContentBgPanel, 1)
		end

		for i=1, 2 do
			local connectPolePic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.PANEL_CONNECT_POLE)))
			if connectPolePic ~= nil then
				connectPolePic:setAnchorPoint(cc.p(0.5, 0.5))
				connectPolePic:setPosition(cc.p(math.pow((-1), i)*200, 175 + 735))
				self.mainUINode:addChild(connectPolePic, 10)
			end
		end

		self.viewArrowTop = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.PANEL_ARROW_RES)))
		if self.viewArrowTop ~= nil then
			self.viewArrowTop:setAnchorPoint(cc.p(0.5,0.5))
			self.viewArrowTop:setPosition(cc.p(0, -100 + shopContentBgPanelSize.height/2 + 735))
			self.viewArrowTop:setRotation(180)
			self.viewArrowTop:setVisible(false)
			self.mainUINode:addChild(self.viewArrowTop, 10)
		end

		self.viewArrowBottom = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.PANEL_ARROW_RES)))
		if self.viewArrowBottom ~= nil then
			self.viewArrowBottom:setAnchorPoint(cc.p(0.5,0.5))
			self.viewArrowBottom:setPosition(cc.p(0, -60 - shopContentBgPanelSize.height/2 + 735))
			self.viewArrowBottom:setVisible(false)
			self.mainUINode:addChild(self.viewArrowBottom, 10)
		end

		self:initMakeListView()
	end

	self.editUINode = display.newNode()
	if self.editUINode ~= nil then
		self.editUINode:setAnchorPoint(cc.p(0.5,0.5))
		self.editUINode:setPosition(cc.p(display.cx+display.width+transMidWidth, 0))
		self.bottomNode:addChild(self.editUINode, 8)

		local editButtonParamList = {
			{ganResIdx=4, ganPos={x=80-display.cx,y=40}, ganAnger=7, btnRes=ResourceDef.BUTTON_BG_PANEL_LIST[2].res, btnSize=ResourceDef.BUTTON_BG_PANEL_LIST[2].size, btnFuncIdx=1, btnAnger=-7, btnPos={x=100-display.cx,y=200}, btnLabel=LangStringDefine.CHANGE_BG_LABEL, btnIcon=ResourceDef.IMAGE_TRANSPARENT},
			{ganResIdx=5, ganPos={x=115-display.cx,y=27}, ganAnger=0, btnRes=ResourceDef.BUTTON_BG_PANEL_LIST[1].res, btnSize=ResourceDef.BUTTON_BG_PANEL_LIST[1].size, btnFuncIdx=2, btnAnger=10, btnPos={x=115-display.cx,y=100}, btnLabel=LangStringDefine.MAP_SAVE, btnIcon=ResourceDef.IMAGE_TRANSPARENT},
			{ganResIdx=6, ganPos={x=0,y=40}, ganAnger=0, btnRes=ResourceDef.BUTTON_BG_PANEL_LIST[1].res, btnSize={width=62,height=58}, btnFuncIdx=3, btnAnger=0, btnPos={x=0,y=110}, btnLabel="", btnIcon=ResourceDef.PANEL_ARROW_RES},
			{ganResIdx=0, ganPos={x=0,y=0}, ganAnger=0, btnRes=ResourceDef.BUTTON_BG_PANEL_LIST[1].res, btnSize={width=62,height=58}, btnFuncIdx=4, btnAnger=-90, btnPos={x=57,y=170}, btnLabel="", btnIcon=ResourceDef.PANEL_ARROW_RES},
			{ganResIdx=0, ganPos={x=0,y=0}, ganAnger=0, btnRes=ResourceDef.BUTTON_BG_PANEL_LIST[1].res, btnSize={width=62,height=58}, btnFuncIdx=5, btnAnger=-180, btnPos={x=0,y=230}, btnLabel="", btnIcon=ResourceDef.PANEL_ARROW_RES},
			{ganResIdx=0, ganPos={x=0,y=0}, ganAnger=0, btnRes=ResourceDef.BUTTON_BG_PANEL_LIST[1].res, btnSize={width=62,height=58}, btnFuncIdx=6, btnAnger=90, btnPos={x=-57,y=170}, btnLabel="", btnIcon=ResourceDef.PANEL_ARROW_RES},
		}

		for i=2, #editButtonParamList do
			if editButtonParamList[i].ganResIdx > 0 then
				local btnGanPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[editButtonParamList[i].ganResIdx])))
				if btnGanPic ~= nil then
					btnGanPic:setAnchorPoint(cc.p(0.5, 0))
					btnGanPic:setPosition(cc.p(editButtonParamList[i].ganPos.x, editButtonParamList[i].ganPos.y))
					btnGanPic:setRotation(editButtonParamList[i].ganAnger)
					self.editUINode:addChild(btnGanPic, 1)
				end
			end
			local funcButton = GameControlButton.new({
		        btnBg = editButtonParamList[i].btnRes,
		        textImg = editButtonParamList[i].btnIcon,
			    dstSize = editButtonParamList[i].btnSize,
			    buttonFont = editButtonParamList[i].btnLabel,
		        buttonFontSize = 30,
		        buttonFontColor = cc.c3b(255,255,255),
		        pressDown = function()
		        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
		        	self:editFunc(editButtonParamList[i].btnFuncIdx, true)
		        end,
		        callback = function ()
		        	self:editFunc(editButtonParamList[i].btnFuncIdx, false)
		        end,
		        releaseOutsideButton = function()
		        	self:editFunc(editButtonParamList[i].btnFuncIdx, false)
		        end
		    })
		    if funcButton ~= nil then
				funcButton:setAnchorPoint(cc.p(0.5, 0.5))
				funcButton:setPosition(cc.p(editButtonParamList[i].btnPos.x, editButtonParamList[i].btnPos.y))
				funcButton:setRotation(editButtonParamList[i].btnAnger)
			    self.editUINode:addChild(funcButton, 3)
			end
		end

	end

	local factoryWorkerList = {
		{resIdx=1, pos={x=90,y=160}, zorder=12},
		{resIdx=2, pos={x=165,y=130}, zorder=12},
		{resIdx=3, pos={x=display.cx-30,y=60}, zorder=12},
		{resIdx=4, pos={x=display.cx+110,y=90}, zorder=12},
		{resIdx=5, pos={x=display.width-100,y=200}, zorder=12},
		{resIdx=6, pos={x=display.width-100,y=70}, zorder=12},
	}
	for i=1, #factoryWorkerList do
		local workerPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.EDITOR_FACTORY_ELEMENT_LIST[factoryWorkerList[i].resIdx])))
		if workerPic ~= nil then
			workerPic:setAnchorPoint(cc.p(0.5, 0.5))
			workerPic:setPosition(cc.p(factoryWorkerList[i].pos.x+display.width+transMidWidth, factoryWorkerList[i].pos.y))
			self.bottomNode:addChild(workerPic, factoryWorkerList[i].zorder)
		end
	end
end

function StageEditLayer:openMyMakeList()
	if self.editBtnNode ~= nil then
		self.editBtnNode:runAction(cc.RotateBy:create(0.1, -180))
	end
	if self.mapSizeSelectNode ~= nil then
		self.mapSizeSelectNode:setVisible(false)
	end
	if self.myMakeListView ~= nil then
		self.myMakeListView:reloadData()
	end
	if self.mainUINode ~= nil then
		self.mainUINode:setVisible(true)
	end
end

function StageEditLayer:closeMyMakeList()
	if self.editBtnNode ~= nil then
		self.editBtnNode:runAction(cc.RotateBy:create(0.1, 180))
	end
	if self.mapSizeSelectNode ~= nil then
		self.mapSizeSelectNode:setVisible(true)
	end
	if self.mainUINode ~= nil then
		self.mainUINode:setVisible(false)
	end
end

function StageEditLayer:checkEditedMapNotNull()
	for k,v in pairs(self.mapUnitList) do
		for kk,vv in pairs(v) do
			if vv.id ~= 0 then
				return true
			end
		end
	end

	return false
end

function StageEditLayer:editFunc(funcIdx, isPressing)
	self.moveFlag = false
	if funcIdx == 1 then
		if isPressing == false then
			self:changeBg()
		end
	elseif funcIdx == 2 then
		if isPressing == false then
			if self:checkEditedMapNotNull() == false then
				display.getRunningScene():showConfirmLayer(LangStringDefine.CONFIRM_CONTENT_LABEL[2], function()
	        		self:makeName()
	        	end)
	        else
	        	display.getRunningScene():showTips(LangStringDefine.LABEL_EDITED_MAP_IS_NULL, -150)
	        end
		end
	elseif funcIdx == 3 then
		if isPressing == false then
			self.moveDir = nil
		else
			self.moveDir = {x=0,y=-1}
		end
	elseif funcIdx == 4 then
		if isPressing == false then
			self.moveDir = nil
		else
			self.moveDir = {x=1,y=0}
		end
	elseif funcIdx == 5 then
		if isPressing == false then
			self.moveDir = nil
		else
			self.moveDir = {x=0,y=1}
		end
	elseif funcIdx == 6 then
		if isPressing == false then
			self.moveDir = nil
		else
			self.moveDir = {x=-1,y=0}
		end
	end
end

function StageEditLayer:initMakeListView()
	if self.mainUINode == nil then
    	return
    end

	local viewSize = {width=420, height=650}
	self.myMakeListView = cc.TableView:create(cc.size(viewSize.width, viewSize.height))
   	if self.myMakeListView ~= nil then

   		self.myMakeListView:setPosition(cc.p(0-viewSize.width/2, -80-viewSize.height/2 + 630))
	    self.myMakeListView:setAnchorPoint(cc.p(0.5, 0.5))
	    
	    self.myMakeListView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	   
	    self.myMakeListView:setDelegate()
	    self.myMakeListView:setDataSource()
	    self.myMakeListView:setBounceable(true)
	    self.myMakeListView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	    
	    self.myMakeListView:registerScriptHandler(function(tbl, cell)
	    	
	    end, cc.TABLECELL_TOUCHED)
	    self.myMakeListView:registerScriptHandler(function()
	    	return viewSize.width, 180
	    end, cc.TABLECELL_SIZE_FOR_INDEX)
	    self.myMakeListView:registerScriptHandler(function()
     		return #UserDataManager.PLAYER_MAP_MAKE_LIST
	    end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)

	    self.myMakeListView:registerScriptHandler(function()
	    	-- if self.scrollNoticeNode == nil then
		    --     return
		    -- end
		    -- local nowX = self.tableView:getContentOffset().x
		    -- local tmpX = 0
		    -- if GameConfig.IS_IPHONEX == true then
	   		-- 	tmpX = GameConfig.IPHONEX_XPOS*2
	   		-- end
		    -- if nowX >= -65 then
		    --     self.scrollNoticeNode:showOrHideMainIcon(false, true)
		    --     self.scrollNoticeNode:showOrHideMainIcon(true, false)
		    -- elseif nowX <= -3293-(1136-tmpOffsetX-display.width) + 65 + tmpX then
		    --     self.scrollNoticeNode:showOrHideMainIcon(false, false)
		    --     self.scrollNoticeNode:showOrHideMainIcon(true, true)
		    -- else
		    --     self.scrollNoticeNode:showOrHideMainIcon(false, true)
		    --     self.scrollNoticeNode:showOrHideMainIcon(true, true)
		    -- end
		    -- print("=======    ", self.tableView:getContentOffset().x, self.tableView:getContentOffset().y)
	    end, cc.SCROLLVIEW_SCRIPT_SCROLL)

	    self.myMakeListView:registerScriptHandler(function(tbl, idx)
			local keyIdx = idx + 1 
		    local cell = tbl:dequeueCell()
		    local isNewCell = false
		    if nil == cell then
		        cell = cc.TableViewCell:new()
		        isNewCell = true
		    end
		    cell.idx = keyIdx

		    local makeData = UserDataManager.PLAYER_MAP_MAKE_LIST[keyIdx]
		   	if isNewCell == true then
	    		cell.content = MyMakeCell.new(self)
	    		if cell.content ~= nil then
	    			cell.content:setAnchorPoint(cc.p(0.5,0.5))
	    			cell.content:setPosition(cc.p(0, 5))
	    			cell:addChild(cell.content)
	    			cell.content:resetCell(keyIdx, makeData)
	    		end
			else
				if cell.content ~= nil then
	    			cell.content:resetCell(keyIdx, makeData)
	    		end
			end

		    return cell

	    end, cc.TABLECELL_SIZE_AT_INDEX)

	    self.myMakeListView:reloadData()
	    self.mainUINode:addChild(self.myMakeListView, 8)
	    self.myMakeListView:setTouchEnabled(true)
   	end
end


function StageEditLayer:update(t)
	if self.moveDir ~= nil then
		if self.moveDir.x ~= nil and self.moveDir.x ~= 0 then
			self.groundNode:setPositionX(self.groundNode:getPositionX() + GameConfig.GROUND_MOVE_CONTROL_SPEED*self.moveDir.x*t*(1))
		end
		if self.moveDir.y ~= nil and self.moveDir.y ~= 0 then
			self.groundNode:setPositionY(self.groundNode:getPositionY() + GameConfig.GROUND_MOVE_CONTROL_SPEED*self.moveDir.y*t*(1))
		end
	end
end

function StageEditLayer:mapReturnCenterPos()
	self.groundNode:setPositionX(0-self.mapUnitList[math.ceil(self.mapRowCount/2)][math.ceil(self.mapRolumnCount/2)]:getPositionX())
	self.groundNode:setPositionY(0-self.mapUnitList[math.ceil(self.mapRowCount/2)][math.ceil(self.mapRolumnCount/2)]:getPositionY())
end

function StageEditLayer:changeBg()
	if self.bgPic == nil then
		return
	end

	local tpIdx = self.selectBgIdx

	-- tpIdx = tpIdx + 1
	-- if tpIdx > #bg_select_list then
	-- 	tpIdx = 1
	-- end

	-- local tpSprite = display.newSprite(ResourceManager.ImageName(bg_select_list[tpIdx]))
	-- if tpSprite ~= nil then
	-- 	self.bgPic:setSpriteFrame(tpSprite:getSpriteFrame())
	-- 	self.selectBgIdx = tpIdx
	-- end
end

function StageEditLayer:createDefaultMap(max_x, max_y)
	local maxX = max_x or GameDefine.MAX_GROUND_X
	local maxY = max_y or GameDefine.MAX_GROUND_Y

	if self.groundNode ~= nil then
		local xx = GameDefine.GROUND_BLOCK_WIDTH/2
		local yy = GameDefine.GROUND_BLOCK_HEIGHT/2

		--make ground
		self.mapUnitList = {}
		for i=1, maxX do
			self.mapUnitList[i] = {}
			for j=1, maxY do
				self.mapUnitList[i][j] = MapUnit.new(self)
				if self.mapUnitList[i][j] ~= nil then
					self.mapUnitList[i][j]:setAnchorPoint(cc.p(0.5,0.5))

					local x = (i-1)*xx + (j-1)*xx
					local y = (i-1)*(0-yy) + (j-1)*yy
					self.mapUnitList[i][j]:setPosition(cc.p(x, y))
					self.groundNode:addChild(self.mapUnitList[i][j], (i-j+GameDefine.ZORDER_BASE_VALUE))
					self.mapUnitList[i][j]:changeGroundPic(ResourceManager.ImageName("#brick00_01"))
					self.mapUnitList[i][j].groundId = 0
					self.mapUnitList[i][j].monsterId = 0
					self.mapUnitList[i][j].itemId = 0
				end
			end
		end

		self.groundNode:setPositionX(0-self.mapUnitList[math.ceil(self.mapRowCount/2)][math.ceil(self.mapRolumnCount/2)]:getPositionX())
		self.groundNode:setPositionY(0-self.mapUnitList[math.ceil(self.mapRowCount/2)][math.ceil(self.mapRolumnCount/2)]:getPositionY())
	end

end

function StageEditLayer:findMapBlockPosIndex(x, y)
	local row = nil
	local column = nil

	local blockSideLength = GameDefine.GROUND_BLOCK_WIDTH -- 150

	--  row    范围为： y =  0.5*x + blockSideLength/4 - blockSideLength/2 * (n - 1) + blockSideLength/4+5	到  y =  0.5*x + blockSideLength/4 - blockSideLength/2*n +blockSideLength/4+5
	--  column 范围为： y = -0.5*x - blockSideLength/4 + blockSideLength/2 * (n - 1) + blockSideLength/4+5	到  y = -0.5*x - blockSideLength/4 + blockSideLength/2*n +blockSideLength/4+5

	for i = 1, self.mapRowCount do
		local y_top = 0.5*x + blockSideLength/4 - blockSideLength/2 * (i-1) +blockSideLength/4+5
		local y_bottom = 0.5*x + blockSideLength/4 - blockSideLength/2 * i +blockSideLength/4+5

		if y < y_top and y > y_bottom then
			row = i
			break
		end
	end

	for i = 1, self.mapRowCount do
		local y_bottom = -0.5 * x - blockSideLength/4 + blockSideLength/2 * (i-1) + blockSideLength/4+5
		local y_top = -0.5 * x - blockSideLength/4 + blockSideLength/2 * i + blockSideLength/4+5

		if y < y_top and y > y_bottom then
			column = i
			break
		end
	end

	-- print("------- row:", row, "---- column:", column)
	return row, column
end

function StageEditLayer:changeMapContent(row, column)
	if self.curMapBrushType == nil then
		return
	end

	if self.mapUnitList == nil or self.mapUnitList[row] == nil or self.mapUnitList[row][column] == nil then
		return
	end

	if self.curMapBrushType == "ground" then
		if self.mapUnitList[row][column].groundId ~= self.curMapBrushContentId then
			self.mapUnitList[row][column].groundId = self.curMapBrushContentId

			local groundTblInfo = ConfigManager.mapBlockTbl[tostring(self.curMapBrushContentId)]
			if groundTblInfo ~= nil then
				self.mapUnitList[row][column]:changeGroundPic(ResourceManager.ImageName(string.format("%s%0.2d", groundTblInfo.res, groundTblInfo.animation.start)))
			end
		end

	elseif self.curMapBrushType == "monster" then
		self.mapUnitList[row][column].monsterId = self.curMapBrushContentId



	elseif self.curMapBrushType == "item" then
		self.mapUnitList[row][column].itemId = self.curMapBrushContentId



	elseif self.curMapBrushType == "clear" then

		self.mapUnitList[row][column].groundId = self.curMapBrushContentId
		local groundTblInfo = ConfigManager.mapBlockTbl[tostring(self.curMapBrushContentId)]
		if groundTblInfo ~= nil then
			self.mapUnitList[row][column]:changeGroundPic(ResourceManager.ImageName(string.format("%s%0.2d", groundTblInfo.res, groundTblInfo.animation.start)))
		end

		self.mapUnitList[row][column].monsterId = 0

		self.mapUnitList[row][column].itemId = 0

	end

end

function StageEditLayer:onEdit(event)
	if event == "began" then
        -- 输入开始
    elseif event == "changed" then
        -- 输入框内容发生变化
    elseif event == "ended" then
        -- 输入结束
    end
end

function StageEditLayer:makeName()
	if self.makeNameNode == nil then
		self.makeNameNode = display.newNode()
		if self.makeNameNode ~= nil then
			self.makeNameNode:setAnchorPoint(cc.p(0.5,0.5))
			self.makeNameNode:setPosition(cc.p(display.cx+display.width+transMidWidth, display.cy))
			self:addChild(self.makeNameNode, 1000)

			--black bg
			local bgColorLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 120), display.width, display.height)
			if bgColorLayer ~= nil then
				bgColorLayer:setAnchorPoint(cc.p(0, 0))
				bgColorLayer:setPosition(cc.p(0-display.cx, 0-display.cy))
				self.makeNameNode:addChild(bgColorLayer, 1)
			end
			local bgCoverBtn = GameControlButton.new({
		        btnBg = ResourceDef.IMAGE_TRANSPARENT,
		        dstSize = {width=display.width, height=display.height},
		        callback = function ()
		        end
		    })
		    if bgCoverBtn ~= nil then
				bgCoverBtn:setAnchorPoint(cc.p(0.5, 0.5))
				bgCoverBtn:setPosition(cc.p(0, 0))
			    self.makeNameNode:addChild(bgCoverBtn, 1)
			end

			local bgLayerSize = {width=400, height=300}
			local bgColorLayer = cc.LayerColor:create(cc.c4b(174, 138, 87, 255), bgLayerSize.width, bgLayerSize.height)
			if bgColorLayer ~= nil then
				bgColorLayer:setAnchorPoint(cc.p(0, 0))
				bgColorLayer:setPosition(cc.p(0-bgLayerSize.width/2, 0-bgLayerSize.height/2))
				self.makeNameNode:addChild(bgColorLayer, 2)
			end

			self.nameEditBox = ccui.EditBox:create(cc.size(300, 50), ResourceManager.ImageName("inputBg"), 0)
			if self.nameEditBox ~= nil then
				self.nameEditBox:setPosition(cc.p(0,50))
				self.nameEditBox:setAnchorPoint(cc.p(0.5,0.5))
				self.nameEditBox:setFontSize(24)
				self.nameEditBox:setFontColor(cc.c3b(0,0,0))
				self.nameEditBox:setMaxLength(100)
				self.nameEditBox:setFontName(ResourceDef.FONT_GAME_MAIN)
				self.nameEditBox:setInputMode(cc.EDITBOX_INPUT_MODE_SINGLELINE)
				self.nameEditBox:setInputFlag(cc.EDITBOX_INPUT_FLAG_SENSITIVE)
				self.nameEditBox:setPlaceholderFontName(ResourceDef.FONT_GAME_MAIN)
				self.nameEditBox:setPlaceholderFontSize(24)
				self.nameEditBox:setPlaceHolder("请输入名字")
				self.nameEditBox:registerScriptEditBoxHandler(handler(self, self.onEdit))
				self.makeNameNode:addChild(self.nameEditBox, 3)
			end

			local makeNameBtn = GameControlButton.new({
		        btnBg = ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[8],
		        dstSize = {width=145, height=40},
		        buttonFont = LangStringDefine.MAP_SAVE,
		        buttonFontSize = 30,
		        buttonFontColor = cc.c3b(0,0,0),
		        callback = function ()
		        	self:saveMap(self.nameEditBox:getText())
		        	self.makeNameNode:removeFromParent(true)
		        	self.makeNameNode = nil
		        end
		    })
			if makeNameBtn ~= nil then
				makeNameBtn:setAnchorPoint(cc.p(0.5, 0.5))
				makeNameBtn:setPosition(cc.p(0,-70))
				self.makeNameNode:addChild(makeNameBtn, 4)
			end
		end
	else
		if self.nameEditBox ~= nil then
			self.nameEditBox:setText("")
		end
	end

end

function StageEditLayer:saveMap(mapName)
	if mapName == nil then
		mapName = ""
	end

	local custome_stage_info = {
		pic = "",
		title = mapName,
		bg = "",
		map = {
			ground={},
			monster={},
			item={},
			born={x=0,y=0}
		},
		maker = UserDataManager.PLAYER_UID,
		makeTime = os.date(),
	}

	custome_stage_info.map.born.x = math.ceil(self.mapRowCount/2)
	custome_stage_info.map.born.y = math.ceil(self.mapRolumnCount/2)
	custome_stage_info.bg = ""--bg_select_list[self.selectBgIdx]

	for i=1, self.mapRowCount do
		custome_stage_info.map.ground[i] = {}
		for j=1, self.mapRolumnCount do
			if self.mapUnitList[i][j] ~= nil then
				if self.mapUnitList[i][j].groundId == 0 then
					custome_stage_info.map.ground[i][j] = 0
				else
					custome_stage_info.map.ground[i][j] = self.mapUnitList[i][j].groundId
				end

				if self.mapUnitList[i][j].monsterId ~= 0 then
					if custome_stage_info.map.monster[tostring(self.mapUnitList[i][j].monsterId)] ~= nil then
						local haveConfigFlag = false
						for k,v in pairs(custome_stage_info.map.monster[tostring(self.mapUnitList[i][j].monsterId)]) do
							if v.x == i and v.y == j then
								haveConfigFlag = true
								break
							end
						end
						if haveConfigFlag == false then
							table.insert(custome_stage_info.map.monster[tostring(self.mapUnitList[i][j].monsterId)], {x=i,y=j})
						end
					else
						custome_stage_info.map.monster[tostring(self.mapUnitList[i][j].monsterId)] = {{x=i,y=j}}
					end
				end

				if self.mapUnitList[i][j].itemId ~= 0 then
					if custome_stage_info.map.item[tostring(self.mapUnitList[i][j].itemId)] ~= nil then
						local haveConfigFlag = false
						for k,v in pairs(custome_stage_info.map.item[tostring(self.mapUnitList[i][j].itemId)]) do
							if v.x == i and v.y == j then
								haveConfigFlag = true
								break
							end
						end
						if haveConfigFlag == false then
							table.insert(custome_stage_info.map.item[tostring(self.mapUnitList[i][j].itemId)], {x=i,y=j})
						end
					else
						custome_stage_info.map.item[tostring(self.mapUnitList[i][j].itemId)] = {{x=i,y=j}}
					end
				end
			end
		end
	end
	if USE_FOR_TOOL ~= nil and USE_FOR_TOOL == true then
		local xx = ""
		for i=1, table.nums(custome_stage_info.map.ground) do
			for j=1, table.nums(custome_stage_info.map.ground[i]) do
				if j == 1 then
					xx = xx .. custome_stage_info.map.ground[i][j]
				else
					xx = xx .. "," .. custome_stage_info.map.ground[i][j]
				end
			end
			if i ~= table.nums(custome_stage_info.map.ground) then
				xx = xx .. ";"
			end
		end
		-- print(xx)
	else
		-- local capturePicName = self:captureSceen()
		self:runAction(cc.Sequence:create(
							cc.DelayTime:create(1.0),
						  	cc.CallFunc:create(function()
						  		if self.groundNode ~= nil then
						  			self.groundNode:setScale(1.0)
						  		end
						  		self:mapReturnCenterPos()
						  		custome_stage_info.picname = ""--cc.FileUtils:getInstance():getWritablePath() .. capturePicName
						  		custome_stage_info.pic = ""--GameTools.getTextureData(cc.FileUtils:getInstance():getWritablePath() .. capturePicName)
						  		table.insert(UserDataManager.PLAYER_MAP_MAKE_LIST, 1, custome_stage_info)
								UserDataManager.savePlayerMakeMapList()

								self:returnEditHomePage()
								self:openMyMakeList()
						  	end)
						)
					)
	end
end

function StageEditLayer:captureSceen()
	for i=1,self.mapRowCount do
		for j=1,self.mapRolumnCount do
			if self.mapUnitList[i] ~= nil and self.mapUnitList[i][j] ~= nil then
				if self.mapUnitList[i][j].groundId == 0 then
					self.mapUnitList[i][j]:setVisible(false)
				end
			end
		end
	end

	local scaleRate = (GameConfig.CAPTURE_MAP_MINI_PIC_WIDTH - 20) / (GameDefine.GROUND_BLOCK_WIDTH*self.mapRowCount + 40)

	self.groundNode:setScale(scaleRate)
	self.groundNode:setPositionX( GameDefine.GROUND_BLOCK_WIDTH/2 * scaleRate + 10 )
	self.groundNode:setPositionY(0-(self.mapUnitList[self.mapRowCount][1]:getPositionY()-GameDefine.GROUND_BLOCK_WIDTH/2 - 10)*scaleRate + GameConfig.CAPTURE_MAP_MINI_PIC_WIDTH/4)
	
	local picName = "upload_" .. tostring(os.time()) .. "_" .. tostring(math.random(100,999)) .. ".jpg"
	GameTools.captureScreen(picName, self.groundNode, {width=GameConfig.CAPTURE_MAP_MINI_PIC_WIDTH, height=GameConfig.CAPTURE_MAP_MINI_PIC_WIDTH})
	return picName
end

function StageEditLayer:refreshCustomDefineStage()
	-- local curScene = display.getRunningScene()
	-- if curScene == nil or curScene.StageSelectLayer == nil or curScene.StageSelectLayer.refreshCustomDefineStage == nil then
	-- 	return
	-- end
	-- curScene.StageSelectLayer:refreshCustomDefineStage()
end

function StageEditLayer:uploadMap(stageInfo)	
	local params = {
		playerId = UserDataManager.PLAYER_UID,
		mapData = stageInfo,
		title = stageInfo.title
	}
	local ret, resp = GameNetWorker.createHttpRequestWithPostParam(GameConfig.SERVER_ADDRESS .. GameConfig.REQUEST_URL.upload, params, false)
	-- dump(resp)
	if ret == true then
		local respInfo = json.decode(resp)
		if respInfo ~= nil and respInfo.mapId ~= nil then
			if respInfo.errorId ~= nil then
				if curScene ~= nil and curScene.showTips ~= nil then
					curScene:showTips(respInfo.errorMsg)
				end
			elseif respInfo.mapId ~= nil then
				UserDataManager.PLAYER_MAP_UPLOAD_LIST[tostring(respInfo.mapId)] = respInfo
				UserDataManager.PLAYER_MAP_UPLOAD_LIST[tostring(respInfo.mapId)]["mapData"] = stageInfo

				-- GameTools.makeTextureByData("map_pic_" .. respInfo.mapId .. ".jpg", stageInfo.pic)
			else
				if curScene ~= nil and curScene.showTips ~= nil then
					curScene:showTips("resp fromat error.")
				end
			end
		else
			if curScene ~= nil and curScene.showTips ~= nil then
				curScene:showTips("resp fromat error.")
			end
		end
	else
		if curScene ~= nil and curScene.showTips ~= nil then
			curScene:showTips("server fault.")
		end
	end

	self:refreshCustomDefineStage()
end

function StageEditLayer:reset()
	self.curMapBrushType = nil
	self.curMapBrushContentId = nil
	self.moveFlag = false
	self.selectBgIdx = 1
	self.isEditingFlag = false

	self:resetMap()

	if self.editBtnNode ~= nil then
		self.editBtnNode:setRotation(180)
	end
	if self.mapSizeSelectNode ~= nil then
		self.mapSizeSelectNode:setVisible(true)
	end
	if self.mainUINode ~= nil then
		self.mainUINode:setVisible(false)
	end

	-- if self.bgPic ~= nil then
	-- 	local tpSprite = display.newSprite(ResourceManager.ImageName(bg_select_list[self.selectBgIdx]))
	-- 	if tpSprite ~= nil then
	-- 		self.bgPic:setSpriteFrame(tpSprite:getSpriteFrame())
	-- 	end
	-- end
end


function StageEditLayer:openLayer()
	self:reset()
	self:setVisible(true)

	AudioManager.stopBackgroundMusic(false)
	AudioManager.playBackgroundMusic(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.editorBgMusic), true)
end


function StageEditLayer:closeLayer()
	self:setVisible(false)
	self:reset()
end


function StageEditLayer:onTouchBegan(touch, event)
	self.useTouch = false
	self.touchMove = false
	if self:isVisible() == false then
		return false
	end

	local touchPoint = touch:getLocation()
	if touchPoint.y <= 120 or touchPoint.y >= display.height - 150 then
		return false
	end
    self.beginTouchPoint = {x=touchPoint.x-self.groundNode:getPositionX()-display.cx, y=touchPoint.y-self.groundNode:getPositionY()-display.cy}

    if self.moveFlag == true then
		self.useTouch = true
		return true
	end

	if self.curMapBrushType == nil or self.curMapBrushContentId == nil then
		return false
	end

	-- print("-----began----", self.beginTouchPoint.x, self.beginTouchPoint.y)
    self.useTouch = true
    return true
end

function StageEditLayer:onTouchMoved(touch, event)
	if self.useTouch == false then
		return
	end

	local touchPoint = touch:getLocation()
	local mapGroundPoint = {x=touchPoint.x-self.groundNode:getPositionX()-display.cx, y=touchPoint.y-self.groundNode:getPositionY()-display.cy}
	local offsetX = mapGroundPoint.x - self.beginTouchPoint.x
	local offsetY = mapGroundPoint.y - self.beginTouchPoint.y

	if self.moveFlag == true then
		self.groundNode:setPositionX(self.groundNode:getPositionX() + offsetX)
		self.groundNode:setPositionY(self.groundNode:getPositionY() + offsetY)
		self.touchMove = true
		return
	end

	local dis = offsetX*offsetX + offsetY*offsetY
	if dis < GameDefine.GROUND_BLOCK_WIDTH/4 then
		return
	end
	self.touchMove = true

	-- print("-----touchPoint----", touchPoint.x, touchPoint.y)
	-- print("-----move----", mapGroundPoint.x, mapGroundPoint.y)

	local posIdxRow, posIdxColumn = self:findMapBlockPosIndex(mapGroundPoint.x, mapGroundPoint.y)
	if posIdxRow ~= nil and posIdxColumn ~= nil then
		self:changeMapContent(posIdxRow, posIdxColumn)
	end

end

function StageEditLayer:onTouchEnded(touch, event)
	if self.useTouch == false or self.touchMove == true then
		return
	end

	local touchPoint = touch:getLocation()
	local mapGroundPoint = {x=touchPoint.x-self.groundNode:getPositionX()-display.cx, y=touchPoint.y-self.groundNode:getPositionY()-display.cy}
	-- print("-----touchPoint----", touchPoint.x, touchPoint.y)
	-- print("-----end----", mapGroundPoint.x, mapGroundPoint.y)

	local posIdxRow, posIdxColumn = self:findMapBlockPosIndex(mapGroundPoint.x, mapGroundPoint.y)
	if posIdxRow ~= nil and posIdxColumn ~= nil then
		self:changeMapContent(posIdxRow, posIdxColumn)
	end

end

function StageEditLayer:makeFloatFlowers(node, zorder)
	if node == nil then
		return
	end
	if zorder == nil then
		zorder = 1
	end

	local totalCountRow = 4
	local totalCountColumn = 4
	for i=1, totalCountRow*totalCountColumn do
		local randIdx = math.random(1, #ResourceDef.MAINSCENE_CONTENT.floatFlowers)
		local flower = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.floatFlowers[randIdx])))
		if flower ~= nil then
			flower:setAnchorPoint(cc.p(0.5,0.5))
			flower:setScale(math.random(100, 120)/100)
			node:addChild(flower, zorder)
			flower:runAction(cc.RepeatForever:create(cc.RotateBy:create(1, 360)))

			local rowIdx = math.floor(i/totalCountRow)
			local columnIdx = math.fmod(i, totalCountColumn) + 1
			flower:setPosition(cc.p(math.random(display.width*columnIdx/totalCountColumn, display.width*(columnIdx+1)/totalCountColumn), math.random(display.height*rowIdx/totalCountRow, display.height*(rowIdx+1)/totalCountRow)))

			local offval = 5
			local bez = {
				cc.p(math.random(31-offval, 31+offval), math.random(-124-offval, -124+offval)),
				cc.p(math.random(100-offval, 100+offval), math.random(-138-offval, -138+offval)),
				cc.p(math.random(95-offval, 95+offval), math.random(-100-offval, -100+offval))
			}
			flower:runAction(cc.RepeatForever:create(cc.Sequence:create(
				cc.BezierBy:create(math.random(50, 100) / 10, bez), 
				cc.CallFunc:create(function()
					if flower:getPositionY() < 0 then
						if self:getPositionX() < 0 then
							flower:setPosition(cc.p(math.random(display.width+transMidWidth-150, display.width+transMidWidth+display.cx-100), math.random(display.height, display.height+100)))
						else
							flower:setPosition(cc.p(math.random(-150, display.cx-100), math.random(display.height, display.height+100)))
						end
					end
				end)
			)))
		end
	end
end
 	
function StageEditLayer:returnEditHomePage()
	self:runAction(cc.MoveBy:create(0.5, cc.p(display.width+transMidWidth, 0)))
	self.isEditingFlag = false
	self:reset()
end

function StageEditLayer:returnMainLayer()
	local curScene = display.getRunningScene()
	if curScene ~= nil and curScene.returnMainLayer ~= nil then
		curScene:UITransition(function()
			curScene:returnMainLayer()
			AudioManager.stopBackgroundMusic(false)
			AudioManager.playBackgroundMusic(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.mainBGMusic), true)
		end)
	end
end

return StageEditLayer
