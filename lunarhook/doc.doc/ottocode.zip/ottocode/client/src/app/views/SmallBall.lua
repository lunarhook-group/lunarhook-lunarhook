
local SmallBall = class("SmallBall", function()
	return display.newNode()
end)

function SmallBall:ctor(parent, id, resIdx)
	self.parent = parent
	self.id = id
	self.resIdx = resIdx or 1
	self.dirIsLeft = (math.random(0,1) == 1)


	self.initFinFlag = false
	self:init()
end

function SmallBall:init()
	self.ballSprite = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.groundBallResList[self.resIdx])))
	if self.ballSprite ~= nil then
		self.ballSprite:setAnchorPoint(cc.p(0.5,0.5))
		self.ballSprite:setScale(0.5)
		if self.dirIsLeft == false then
			self.ballSprite:setScaleX(-0.5)
		end
		self.ballSprite:setPosition(cc.p(0, 0))
		self:addChild(self.ballSprite)
	end


	self.gravity = GameDefine.GLOBAL_GRAVITY*3
	self.maxJumpHeight = math.random(35,42)
	self.jumpTimeRecord = 0
	self.airTime = math.sqrt(2*self.maxJumpHeight/self.gravity)
	self.jumpInitSpeed = self.gravity * self.airTime
	self.jumpMaxSpeed = math.abs(self.jumpInitSpeed)
	self.initHeight = 0

	self.groundDelayTimeNeed = math.random(50,300)/100
	self.moveSpeedNormal = math.random(45,75)/100
	self.moveSpeedFast = math.random(28,32)/10
	self.groundDelayTimeRecord = 0

	self.jumpState = GameDefine.CHARACTER_JUMP_STATE.BEGIN

	self.actArea = {min=0, max = display.width}
	self.nodePosX = 0

	self.initFinFlag = true
end

function SmallBall:update(t)
	if self.initFinFlag == false then
		return
	end

	if self.parent.gameLoginedFlag == true then
		self.actArea = {min = display.width + self.parent.midSceneWidth, max = display.width*2 + self.parent.midSceneWidth}
	else
		self.actArea = {min = 0, max = display.width}
	end

	if self.jumpState == GameDefine.CHARACTER_JUMP_STATE.BEGIN then
		if self.parent.fastMoveFlag == false then
			self.groundDelayTimeRecord = self.groundDelayTimeRecord + t
			if self.groundDelayTimeRecord >= self.groundDelayTimeNeed then
				self.groundDelayTimeRecord = 0
				self.jumpTimeRecord = 0
				self.jumpState = GameDefine.CHARACTER_JUMP_STATE.RISE
			end
		else
			self.groundDelayTimeRecord = 0
			self.jumpTimeRecord = 0
			self.jumpState = GameDefine.CHARACTER_JUMP_STATE.RISE
		end
	elseif self.jumpState == GameDefine.CHARACTER_JUMP_STATE.RISE then
		self.jumpTimeRecord = self.jumpTimeRecord + t
		local y = self.jumpInitSpeed*self.jumpTimeRecord - 0.5*self.gravity*self.jumpTimeRecord*self.jumpTimeRecord + self.initHeight
		local vy = self.jumpInitSpeed - self.gravity * self.jumpTimeRecord
		if vy <= 0 then
			self.ballSprite:setPositionY(self.maxJumpHeight)
			self.jumpTimeRecord = 0
			self.jumpState = GameDefine.CHARACTER_JUMP_STATE.FALL
		else
			self.ballSprite:setPositionY(y)
		end

		self:move()
	elseif self.jumpState == GameDefine.CHARACTER_JUMP_STATE.FALL then
		self.jumpTimeRecord = self.jumpTimeRecord + t
		local y = self.maxJumpHeight - 0.5*self.gravity*self.jumpTimeRecord*self.jumpTimeRecord
		local vy = self.gravity * self.jumpTimeRecord
		if vy >= self.jumpMaxSpeed then
			self.ballSprite:setPositionY(0)
			self.jumpTimeRecord = 0
			self.jumpState = GameDefine.CHARACTER_JUMP_STATE.FALLGROUND
		else
			self.ballSprite:setPositionY(y)
		end

		self:move()
	elseif self.jumpState == GameDefine.CHARACTER_JUMP_STATE.FALLGROUND then
		self.jumpState = GameDefine.CHARACTER_JUMP_STATE.BEGIN
	end

end

function SmallBall:move()
	local moveSpeed = self.moveSpeedNormal
	if self.parent.fastMoveFlag == true then
		moveSpeed = self.moveSpeedFast
	else
		if self.lastDir ~= nil then
			self.dirIsLeft = self.lastDir
			self.lastDir = nil
		end
	end

	if self.nodePosX >= self.actArea.min and self.nodePosX <= self.actArea.max then
		if self.dirIsLeft == true then
			if self.nodePosX - moveSpeed <= self.actArea.min then
				self.nodePosX = self.actArea.min
				self.dirIsLeft = false
				self.parent.fastMoveFlag = false
			else
				self.nodePosX = self.nodePosX - moveSpeed
			end
		else
			if self.nodePosX + moveSpeed >= self.actArea.max then
				self.nodePosX = self.actArea.max
				self.dirIsLeft = true
				self.parent.fastMoveFlag = false
			else
				self.nodePosX = self.nodePosX + moveSpeed
			end
		end
	else
		if self.lastDir == nil then
			self.lastDir = self.dirIsLeft
		end
		if self.nodePosX >= self.actArea.min then
			--  <<-----
			if self.dirIsLeft == false then
				self.dirIsLeft = true
			end
			self.nodePosX = self.nodePosX - moveSpeed
		else
			--  ----->>
			if self.dirIsLeft == true then
				self.dirIsLeft = false
			end
			self.nodePosX = self.nodePosX + moveSpeed
		end

	end

	self:setPositionX(self.nodePosX)
	if self.dirIsLeft == true then
		self.ballSprite:setScaleX(0.5)
	else
		self.ballSprite:setScaleX(-0.5)
	end

end

return SmallBall
