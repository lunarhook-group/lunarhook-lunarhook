local GameControlButton = import("app.views.GameControlButton")

local PlayerInfo = class("PlayerInfo", BaseLayer)

function PlayerInfo:ctor()
	PlayerInfo.super.ctor(self)

	self:initUI()
end

function PlayerInfo:initUI()
	--bg content
	self.bgNode = display.newNode()
	if self.bgNode ~= nil then
		self.bgNode:setAnchorPoint(cc.p(0.5,0.5))
		self.bgNode:setPosition(cc.p(0,0))
		self:addChild(self.bgNode, 1)

		-------bgcolorlayer
		local bgLayerSize = {width=display.width, height=display.height}
		local bgColorLayer = cc.LayerColor:create(cc.c4b(240, 240, 240, 255), bgLayerSize.width, bgLayerSize.height)
		if bgColorLayer ~= nil then
			bgColorLayer:setAnchorPoint(cc.p(0, 0))
			bgColorLayer:setPosition(cc.p(0, 0))
			self.bgNode:addChild(bgColorLayer, 10)
		end

		-------transparent bg pics
		local transparentBgPic1 = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.transparentBg1)))
		if transparentBgPic1 ~= nil then
			transparentBgPic1:setAnchorPoint(cc.p(0, 0))
			local scaleRate = display.height/transparentBgPic1:getContentSize().height
			transparentBgPic1:setScale(scaleRate)
			transparentBgPic1:setPosition(cc.p(0, 0))
			transparentBgPic1:setOpacity(150)
			self.bgNode:addChild(transparentBgPic1, 15)
		end

		-------clouds
		local cloudNode = GameTools.makeMoveClouds(0-display.cx, display.cy+150, display.width*2, display.cy-100)
		if cloudNode ~= nil then
			self.bgNode:addChild(cloudNode, 17)
		end

		-------round small trees
		local roundSmallTreePosList = {
			{x=-30, y=80, zOrder=18,resIdx=2,scale=0.9},
			{x=186, y=58, zOrder=18,resIdx=1,scale=0.8},
			{x=display.cx+36, y=75, zOrder=17,resIdx=2,scale=0.8},
			{x=display.cx+90, y=67, zOrder=18,resIdx=1,scale=0.8},
			{x=display.width-96, y=55, zOrder=18,resIdx=3,scale=0.8},
			{x=display.width-64, y=100, zOrder=17,resIdx=2,scale=0.7},
			{x=display.width-35, y=75, zOrder=17,resIdx=1,scale=0.7},
		}
		for i=1, #roundSmallTreePosList do
			local roundTreePic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.roundSmallTree[roundSmallTreePosList[i].resIdx])))
			if roundTreePic ~= nil then
				roundTreePic:setAnchorPoint(cc.p(0.5, 0.5))
				roundTreePic:setPosition(cc.p(roundSmallTreePosList[i].x, roundSmallTreePosList[i].y))
				roundTreePic:setScale(roundSmallTreePosList[i].scale)
				self.bgNode:addChild(roundTreePic, roundSmallTreePosList[i].zOrder)
			end
		end

		self:makeFloatFlowers(self.bgNode, 20)
	end

	--ground content
	self.groundNode = display.newNode()
	if self.groundNode ~= nil then
		self.groundNode:setAnchorPoint(cc.p(0.5,0.5))
		self.groundNode:setPosition(cc.p(0,0))
		self:addChild(self.groundNode, 11)

		-------ground
		local tmpPosX = 0
		for i=3, 1, -1 do
			local ground = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.groundResList[i])))
			if ground ~= nil then
				ground:setAnchorPoint(cc.p(0, 0))
				ground:setPosition(cc.p(tmpPosX, 0))
				self.groundNode:addChild(ground, 10)
				tmpPosX = tmpPosX + ground:getContentSize().width - 2
			end
		end

		-------carrot
		self.heroCarrotNode = require("app.views.CarrotNode").new(true)
		if self.heroCarrotNode ~= nil then
			self.heroCarrotNode:setPosition(cc.p(display.cx, 10))
			self.groundNode:addChild(self.heroCarrotNode, 5)
		end

		--flagpole
		local flagpolePic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.BG_FLAGPOLE_RES)))
		if flagpolePic ~= nil then
			flagpolePic:setAnchorPoint(cc.p(0.5, 0))
			flagpolePic:setPosition(cc.p(70, 0))
			self.groundNode:addChild(flagpolePic, 6)
		end

		--right button (return)
		self.returnBtnNode = display.newNode()
		if self.returnBtnNode ~= nil then
			self.returnBtnNode:setAnchorPoint(cc.p(0.5,0.5))
			self.returnBtnNode:setPosition(cc.p(display.width-70, 45))
			self.groundNode:addChild(self.returnBtnNode, 8)

			local returnBtnGanPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[1])))
			if returnBtnGanPic ~= nil then
				returnBtnGanPic:setAnchorPoint(cc.p(1, 0))
				returnBtnGanPic:setPosition(cc.p(0, 0))
				self.returnBtnNode:addChild(returnBtnGanPic, 1)
			end

			local returnButton = GameControlButton.new({
		        btnBg = ResourceDef.BUTTON_BG_PANEL_LIST[1].res,
			    dstSize = ResourceDef.BUTTON_BG_PANEL_LIST[1].size,
			    buttonFont = LangStringDefine.RETURN_LABEL,
		        buttonFontSize = 30,
		        buttonFontColor = cc.c3b(255,255,255),
		        callback = function ()
		        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
		        	self:returnMainLayer()
		        end
		    })
		    if returnButton ~= nil then
				returnButton:setAnchorPoint(cc.p(0.5, 0.5))
				returnButton:setPosition(cc.p(-30, 80))
			    self.returnBtnNode:addChild(returnButton, 2)
			end
		end
	end

	--main list content
	self.contentNode = {}
	self.mainUINode = display.newNode()
	if self.mainUINode ~= nil then
		self.mainUINode:setAnchorPoint(cc.p(0.5,0.5))
		self.mainUINode:setPosition(cc.p(display.cx, 0))
		self:addChild(self.mainUINode, 21)

		local titleBgPanelSize = {width=460, height=80}
		local titleBgPanel = cc.LayerColor:create(cc.c4b(133, 85, 13, 255), titleBgPanelSize.width, titleBgPanelSize.height)
		if titleBgPanel ~= nil then
			titleBgPanel:setAnchorPoint(cc.p(0, 0))
			titleBgPanel:setPosition(cc.p(0-titleBgPanelSize.width/2, 175 + titleBgPanelSize.height/2 + 735))
			self.mainUINode:addChild(titleBgPanel, 1)
		end
		local titleBgPanelSize2 = {width=432, height=60}
		self.titleBgPanel2 = cc.LayerColor:create(cc.c4b(250, 205, 137, 255), titleBgPanelSize2.width, titleBgPanelSize2.height)
		if self.titleBgPanel2 ~= nil then
			self.titleBgPanel2:setAnchorPoint(cc.p(0, 0))
			self.titleBgPanel2:setPosition(cc.p(0-titleBgPanelSize2.width/2, 205 + titleBgPanelSize2.height/2 + 725))
			self.mainUINode:addChild(self.titleBgPanel2, 3)
		end
		
		self.titleLabel = display.newTTFLabel({
	        text = LangStringDefine.PLAYER_INFO_LABEL,
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 36,
	        color = cc.c3b(52, 36, 13),
	        align = cc.TEXT_ALIGNMENT_CENTER
	    })
	    if self.titleLabel ~= nil then
	        self.titleLabel:setAnchorPoint(cc.p(0.5, 0.5))
	        self.titleLabel:setPosition(cc.p(0, 255 + 735))
	        self.mainUINode:addChild(self.titleLabel, 5)
	    end

	    local contentBgPanelSize = {width=460, height=700}
		local contentBgPanel = cc.LayerColor:create(cc.c4b(133, 85, 13, 255), contentBgPanelSize.width, contentBgPanelSize.height)
		if contentBgPanel ~= nil then
			contentBgPanel:setAnchorPoint(cc.p(0, 0))
			contentBgPanel:setPosition(cc.p(0-contentBgPanelSize.width/2, -75 - contentBgPanelSize.height/2 + 655))
			self.mainUINode:addChild(contentBgPanel, 1)
		end

		for i=1, 2 do
			local connectPolePic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.PANEL_CONNECT_POLE)))
			if connectPolePic ~= nil then
				connectPolePic:setAnchorPoint(cc.p(0.5, 0.5))
				connectPolePic:setPosition(cc.p(math.pow((-1), i)*200, 200 + 735))
				self.mainUINode:addChild(connectPolePic, 10)
			end
		end

		local contentPanelParamList = {
			{nodePos={x=0,y=105}, panelSize={width=410,height=100}},
			{nodePos={x=0,y=-70}, panelSize={width=410,height=220}},
			{nodePos={x=0,y=-340}, panelSize={width=410,height=280}},
		}
		for i=1, #contentPanelParamList do
			self.contentNode[i] = display.newNode()
			if self.contentNode[i] ~= nil then
				self.contentNode[i]:setAnchorPoint(cc.p(0.5,0.5))
				self.contentNode[i]:setPosition(cc.p(contentPanelParamList[i].nodePos.x, contentPanelParamList[i].nodePos.y + 735))
				self.mainUINode:addChild(self.contentNode[i], 5)

				local contentPanelBg1 = cc.LayerColor:create(cc.c4b(174, 138, 90, 255), contentPanelParamList[i].panelSize.width, contentPanelParamList[i].panelSize.height)
				if contentPanelBg1 ~= nil then
					contentPanelBg1:setAnchorPoint(cc.p(0, 0))
					contentPanelBg1:setPosition(cc.p(0-contentPanelParamList[i].panelSize.width/2, 0-contentPanelParamList[i].panelSize.height/2))
					self.contentNode[i]:addChild(contentPanelBg1, 1)
				end
				local contentPanelBg2 = cc.LayerColor:create(cc.c4b(250, 205, 137, 255), contentPanelParamList[i].panelSize.width-10, contentPanelParamList[i].panelSize.height-10)
				if contentPanelBg2 ~= nil then
					contentPanelBg2:setAnchorPoint(cc.p(0, 0))
					contentPanelBg2:setPosition(cc.p(0-(contentPanelParamList[i].panelSize.width-10)/2, 0-(contentPanelParamList[i].panelSize.height-10)/2))
					self.contentNode[i]:addChild(contentPanelBg2, 2)
				end

			end
		end
	end

	if self.contentNode[1] ~= nil then
		local nameLabel = display.newTTFLabel({
	        text = LangStringDefine.PLAYER_NAME_LABEL,
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 30,
	        color = cc.c3b(98, 54, 11),
	        align = cc.TEXT_ALIGNMENT_CENTER
	    })
	    if nameLabel ~= nil then
	        nameLabel:setAnchorPoint(cc.p(0, 0))
	        nameLabel:setPosition(cc.p(-190, -15))
	        self.contentNode[1]:addChild(nameLabel, 5)
	    end
		self.playerName = display.newTTFLabel({
	        text = tostring(UserDataManager.PLAYER_UID),
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 35,
	        color = cc.c3b(98, 54, 11),
	        align = cc.TEXT_ALIGNMENT_CENTER
	    })
	    if self.playerName ~= nil then
	        self.playerName:setAnchorPoint(cc.p(0, 0))
	        self.playerName:setPosition(cc.p(-120, -17))
	        self.contentNode[1]:addChild(self.playerName, 5)
	    end
	end

	if self.contentNode[2] ~= nil then
		local targetStr = ""
		for i=1, #LangStringDefine.GAME_DESC_STRING_LIST do
			targetStr = targetStr .. LangStringDefine.GAME_DESC_STRING_LIST[i]
		end
		local gameDesc = display.newTTFLabel({
	        text = targetStr,
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 24,
	        color = cc.c3b(98, 54, 11),
	        align = cc.TEXT_ALIGNMENT_LEFT, -- 文字内部左对齐
		    valign = cc.VERTICAL_TEXT_ALIGNMENT_CENTER,
	        dimensions = cc.size(390, 210)
	    })
	    if gameDesc ~= nil then
	    	gameDesc:setLineHeight(30)
	        gameDesc:setAnchorPoint(cc.p(0, 1))
	        gameDesc:setPosition(cc.p(-195, 105))
	        self.contentNode[2]:addChild(gameDesc, 5)
	    end
	end

	if self.contentNode[3] ~= nil then
		--speed labels
		self.radioSelectPic = {}
		local speedUIOffsetXList = {
			easy = -190, normal = -50, hard = 80,
		}
		for k,v in pairs(GameDefine.GAME_DIFFICULT_TYPE) do
			local speedLabel = display.newTTFLabel({
		        text = LangStringDefine.DIFFICULT_MODE_LABEL[k],
		        font = ResourceDef.FONT_GAME_MAIN,
		        size = 30,
		        color = cc.c3b(98, 54, 11),
		        align = cc.TEXT_ALIGNMENT_CENTER
		    })
		    if speedLabel ~= nil then
		        speedLabel:setAnchorPoint(cc.p(0, 0.5))
		        speedLabel:setPosition(cc.p(speedUIOffsetXList[k], 110))
		        self.contentNode[3]:addChild(speedLabel, 15)
		    end

		    local radioBtn = GameControlButton.new({
		        btnBg = ResourceDef.STAGE_SELECT_CONTENT.groundShadingResList[2],
		        dstSize = {width=30, height=30},
		        pressedScale = 1,
		        callback = function ()
		        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
		        	self:changeDifficultSpeed(k)
		        end
		    })
		    if radioBtn ~= nil then
		        radioBtn:setAnchorPoint(cc.p(0.5, 0.5))
		        radioBtn:setPosition(cc.p(speedUIOffsetXList[k]+80, 110))
		        self.contentNode[3]:addChild(radioBtn, 15)
		    end

		    self.radioSelectPic[k] = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.RADIO_BUTTON_SELECTED_PIC)))
		    if self.radioSelectPic[k] ~= nil then
		        self.radioSelectPic[k]:setAnchorPoint(cc.p(0.5, 0.5))
		        self.radioSelectPic[k]:setPosition(cc.p(speedUIOffsetXList[k]+80+2, 110))
		        self.radioSelectPic[k]:setScale(1.5)
		        self.radioSelectPic[k]:setVisible(UserDataManager.PLAYER_SETTINGS.gamespeed == k)
		        self.contentNode[3]:addChild(self.radioSelectPic[k], 16)
		    end
		end

		--control labels
		local controlLabel = display.newTTFLabel({
	        text = LangStringDefine.CONTROL_LABEL,
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 30,
	        color = cc.c3b(98, 54, 11),
	        align = cc.TEXT_ALIGNMENT_CENTER
	    })
	    if controlLabel ~= nil then
	        controlLabel:setAnchorPoint(cc.p(0, 0.5))
	        controlLabel:setPosition(cc.p(speedUIOffsetXList["easy"], 40))
	        self.contentNode[3]:addChild(controlLabel, 15)
	    end

	    local controlSwitch = import("app.views.SwitchNode").new(self)
	    if controlSwitch ~= nil then
	    	local retFlag = true
	    	if UserDataManager.PLAYER_SETTINGS.controlmode == "button" then
	    		retFlag = false
	    	end
	    	controlSwitch:resetLayer({
	    		showLeft = retFlag,
	    		leftPic = ResourceDef.CONTROL_ICON_SLIDE,
	    		rightPic = ResourceDef.CONTROL_ICON_PRESS,
	    		leftStateLabel = LangStringDefine.CONTROL_LABEL_SLIDE,
	    		rightStateLabel = LangStringDefine.CONTROL_LABEL_PRESS,
	    		func = function(ret)
	    			if ret == true then
	    				UserDataManager.PLAYER_SETTINGS.controlmode = "slide"
	    				if self.parent ~= nil and self.parent.controlNode ~= nil then
	    					self.parent.controlNode:changeControlMode(1)
	    				end
	    			else
	    				UserDataManager.PLAYER_SETTINGS.controlmode = "button"
	    				if self.parent ~= nil and self.parent.controlNode ~= nil then
	    					self.parent.controlNode:changeControlMode(2)
	    				end 
	    			end
	    			UserDataManager.savePlayerSettings()
	    			UserDataManager.refreshPlayerSetting()
	    		end
	    	})
	    	controlSwitch:setPosition(cc.p(speedUIOffsetXList["easy"]+200, 40))
	    	self.contentNode[3]:addChild(controlSwitch, 15)
	    end

		--sound
		local soundLabel1 = display.newTTFLabel({
	        text = LangStringDefine.SOUND_MUSIC_LABEL,
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 30,
	        color = cc.c3b(98, 54, 11),
	        align = cc.TEXT_ALIGNMENT_CENTER
	    })
	    if soundLabel1 ~= nil then
	        soundLabel1:setAnchorPoint(cc.p(0, 0.5))
	        soundLabel1:setPosition(cc.p(speedUIOffsetXList["easy"], -30))
	        self.contentNode[3]:addChild(soundLabel1, 15)
	    end
	    local soundMusicSwitch = import("app.views.SwitchNode").new(self)
	    if soundMusicSwitch ~= nil then
	    	local retFlag = true
	    	if UserDataManager.PLAYER_SETTINGS.soundmusiconoff == "off" then
	    		retFlag = false
	    	end
	    	soundMusicSwitch:resetLayer({
	    		showLeft = retFlag,
	    		leftPic = ResourceDef.SOUND_MUSIC_ON,
	    		rightPic = ResourceDef.SOUND_MUSIC_OFF,
	    		leftStateLabel = LangStringDefine.CONTROL_LABEL_OPEN,
	    		rightStateLabel = LangStringDefine.CONTROL_LABEL_CLOSE,
	    		func = function(ret)
	    			if ret == true then
	    				UserDataManager.PLAYER_SETTINGS.soundmusiconoff = "on"
	    			else
	    				UserDataManager.PLAYER_SETTINGS.soundmusiconoff = "off"
	    			end
	    			UserDataManager.savePlayerSettings()
	    			UserDataManager.refreshPlayerSetting()
	    		end
	    	})
	    	soundMusicSwitch:setPosition(cc.p(speedUIOffsetXList["easy"]+200, -30))
	    	self.contentNode[3]:addChild(soundMusicSwitch, 15)
	    end

	    local soundLabel2 = display.newTTFLabel({
	        text = LangStringDefine.SOUND_EFFECT_LABEL,
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 30,
	        color = cc.c3b(98, 54, 11),
	        align = cc.TEXT_ALIGNMENT_CENTER
	    })
	    if soundLabel2 ~= nil then
	        soundLabel2:setAnchorPoint(cc.p(0, 0.5))
	        soundLabel2:setPosition(cc.p(speedUIOffsetXList["easy"], -100))
	        self.contentNode[3]:addChild(soundLabel2, 15)
	    end
	    local soundEffectSwitch = import("app.views.SwitchNode").new(self)
	    if soundEffectSwitch ~= nil then
	    	local retFlag = true
	    	if UserDataManager.PLAYER_SETTINGS.soundeffectonoff == "off" then
	    		retFlag = false
	    	end
	    	soundEffectSwitch:resetLayer({
	    		showLeft = retFlag,
	    		leftPic = ResourceDef.SOUND_EFFECT_ON,
	    		rightPic = ResourceDef.SOUND_EFFECT_OFF,
	    		leftStateLabel = LangStringDefine.CONTROL_LABEL_OPEN,
	    		rightStateLabel = LangStringDefine.CONTROL_LABEL_CLOSE,
	    		func = function(ret)
	    			if ret == true then
	    				UserDataManager.PLAYER_SETTINGS.soundeffectonoff = "on"
	    			else
	    				UserDataManager.PLAYER_SETTINGS.soundeffectonoff = "off"
	    			end
	    			UserDataManager.savePlayerSettings()
	    			UserDataManager.refreshPlayerSetting()
	    		end
	    	})
	    	soundEffectSwitch:setPosition(cc.p(speedUIOffsetXList["easy"]+200, -100))
	    	self.contentNode[3]:addChild(soundEffectSwitch, 15)
	    end
	end

end

function PlayerInfo:changeDifficultSpeed(etype)
	if GameDefine.GAME_DIFFICULT_TYPE[etype] == nil then
		return
	end

	if self.radioSelectPic[UserDataManager.PLAYER_SETTINGS.gamespeed] ~= nil then
		self.radioSelectPic[UserDataManager.PLAYER_SETTINGS.gamespeed]:setVisible(false)
	end

	UserDataManager.PLAYER_SETTINGS.gamespeed = etype
	UserDataManager.savePlayerSettings()

	if self.radioSelectPic[UserDataManager.PLAYER_SETTINGS.gamespeed] ~= nil then
		self.radioSelectPic[UserDataManager.PLAYER_SETTINGS.gamespeed]:setVisible(true)
	end

end

function PlayerInfo:makeFloatFlowers(node, zorder)
	if node == nil then
		return
	end
	if zorder == nil then
		zorder = 1
	end

	local totalCountRow = 4
	local totalCountColumn = 4
	for i=1, totalCountRow*totalCountColumn do
		local randIdx = math.random(1, #ResourceDef.MAINSCENE_CONTENT.floatFlowers)
		local flower = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.floatFlowers[randIdx])))
		if flower ~= nil then
			flower:setAnchorPoint(cc.p(0.5,0.5))
			flower:setScale(math.random(100, 120)/100)
			node:addChild(flower, zorder)
			flower:runAction(cc.RepeatForever:create(cc.RotateBy:create(1, 360)))

			local rowIdx = math.floor(i/totalCountRow)
			local columnIdx = math.fmod(i, totalCountColumn) + 1
			flower:setPosition(cc.p(math.random(display.width*columnIdx/totalCountColumn, display.width*(columnIdx+1)/totalCountColumn), math.random(display.height*rowIdx/totalCountRow, display.height*(rowIdx+1)/totalCountRow)))

			local offval = 5
			local bez = {
				cc.p(math.random(31-offval, 31+offval), math.random(-124-offval, -124+offval)),
				cc.p(math.random(100-offval, 100+offval), math.random(-138-offval, -138+offval)),
				cc.p(math.random(95-offval, 95+offval), math.random(-100-offval, -100+offval))
			}
			flower:runAction(cc.RepeatForever:create(cc.Sequence:create(
				cc.BezierBy:create(math.random(50, 100) / 10, bez), 
				cc.CallFunc:create(function()
					if flower:getPositionY() < 0 then
						flower:setPosition(cc.p(math.random(-150, display.cx-100), math.random(display.height, display.height+100)))
					end
				end)
			)))
		end
	end
end

function PlayerInfo:returnMainLayer()
	local curScene = display.getRunningScene()
	if curScene ~= nil and curScene.returnMainLayer ~= nil then
		curScene:UITransition(function()
			curScene:returnMainLayer()
		end)
	end
end

function PlayerInfo:openLayer()
	self:setVisible(true)
end

function PlayerInfo:closeLayer()
	self:setVisible(false)
end

return PlayerInfo
