local GameControlButton = import("app.views.GameControlButton")

local SwitchNode = class("SwitchNode",function()
	return display.newNode()
end)

function SwitchNode:ctor(parent)
	self.parent = parent
	self:initUI()
end

function SwitchNode:initUI()
	--bg
	local btnBg = cc.LayerColor:create(cc.c4b(255, 67, 0, 255), 140, 60)
	if btnBg ~= nil then
		btnBg:setAnchorPoint(cc.p(0, 0))
		btnBg:setPosition(cc.p(-70, -30))
		self:addChild(btnBg, 1)
	end
	local leftBgPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.groundShadingResList[2])))
	if leftBgPic ~= nil then
		leftBgPic:setAnchorPoint(cc.p(0.5, 0.5))
		leftBgPic:setPosition(cc.p(-70, 0))
		leftBgPic:setScale(60/leftBgPic:getContentSize().width)
		self:addChild(leftBgPic, 1)
	end
	local rightBgPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.groundShadingResList[2])))
	if rightBgPic ~= nil then
		rightBgPic:setAnchorPoint(cc.p(0.5, 0.5))
		rightBgPic:setPosition(cc.p(70, 0))
		rightBgPic:setScale(60/rightBgPic:getContentSize().width)
		self:addChild(rightBgPic, 1)
	end

	self.leftPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
	if self.leftPic ~= nil then
		self.leftPic:setAnchorPoint(cc.p(0.5, 0.5))
		self.leftPic:setPosition(cc.p(-70, 0))
		self.leftPic:setVisible(false)
		self:addChild(self.leftPic, 1)
	end

	self.rightPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
	if self.rightPic ~= nil then
		self.rightPic:setAnchorPoint(cc.p(0.5, 0.5))
		self.rightPic:setPosition(cc.p(70, 0))
		self.rightPic:setVisible(false)
		self:addChild(self.rightPic, 1)
	end

	local mainBtn = GameControlButton.new({
        btnBg = ResourceDef.IMAGE_TRANSPARENT,
        dstSize = {width=200, height=60},
        callback = function ()
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
        	if self.params == nil then
        		return
        	end
        	self:onClick()
        end
    })
    if mainBtn ~= nil then
        mainBtn:setAnchorPoint(cc.p(0.5, 0.5))
        mainBtn:setPosition(cc.p(0, 0))
        self:addChild(mainBtn, 15)
    end

    self.btnLabel = display.newTTFLabel({
        text = "",
        font = ResourceDef.FONT_GAME_MAIN,
        size = 30,
        color = cc.c3b(248, 201, 131),
        align = cc.TEXT_ALIGNMENT_CENTER
    })
    if self.btnLabel ~= nil then
        self.btnLabel:setAnchorPoint(cc.p(0.5, 0.5))
        self.btnLabel:setPosition(cc.p(0, 0))
        self:addChild(self.btnLabel, 17)
    end

end

function SwitchNode:resetLayer(params)
	if params == nil or type(params) ~= "table" then
		return
	end

	self.params = params
	if self.params.showLeft == nil then
		self.params.showLeft = true
	end

	if self.leftPic ~= nil then
		if self.params.leftPic ~= nil then
			local tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(self.params.leftPic))
			if tpFrame ~= nil then
				self.leftPic:setSpriteFrame(tpFrame)
			end
		end
		self.leftPic:setVisible(self.params.showLeft)
	end
	if self.rightPic ~= nil then
		if self.params.rightPic ~= nil then
			local tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(self.params.rightPic))
			if tpFrame ~= nil then
				self.rightPic:setSpriteFrame(tpFrame)
			end
		end
		self.rightPic:setVisible(not self.params.showLeft)
	end

	if self.btnLabel ~= nil then
		if self.params.showLeft == true then
			if self.params.leftStateLabel ~= nil then
				self.btnLabel:setString(self.params.leftStateLabel)
			end
		else
			if self.params.rightStateLabel ~= nil then
				self.btnLabel:setString(self.params.rightStateLabel)
			end
		end
	end

end

function SwitchNode:onClick()
	if self.leftPic ~= nil then
		self.leftPic:setVisible(not self.params.showLeft)
	end
	if self.rightPic ~= nil then
		self.rightPic:setVisible(self.params.showLeft)
	end
	if self.params.showLeft == true then
		if self.btnLabel ~= nil then
			if self.params.rightStateLabel ~= nil then
				self.btnLabel:setString(self.params.rightStateLabel)
			end
		end
	else
		if self.btnLabel ~= nil then
			if self.params.leftStateLabel ~= nil then
				self.btnLabel:setString(self.params.leftStateLabel)
			end
		end
	end

	if self.params.func ~= nil then
		self.params.func(not self.params.showLeft)
	end

	self.params.showLeft = not self.params.showLeft
end

return SwitchNode
