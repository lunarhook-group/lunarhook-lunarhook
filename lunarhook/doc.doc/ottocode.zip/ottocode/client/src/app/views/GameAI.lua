local GameAI = class("GameAI")

function GameAI:ctor(map, aiIdList)
	self.map = map
	self.aiIDList = aiIdList or {}

	self.time_record = 0
	self.aiList = {}
	self.initFinFlag = false
	self:init()
end

function GameAI:init()

	self.aiTypeList = {}
	for i=1, #self.aiIDList do
		local aiId = self.aiIDList[i]
		local aiTblInfo = ConfigManager.gameAITbl[tostring(aiId)]
		if aiTblInfo ~= nil and aiTblInfo.conditionId ~= nil and aiTblInfo.eventId ~= nil then
			local eventObj = GameAIDefine.SCENEAI_EVENT_LUA[tonumber(aiTblInfo.eventId)].new(self, aiTblInfo.eventParams)
			local conditionObj = GameAIDefine.SCENEAI_CONDITION_LUA[tonumber(aiTblInfo.conditionId)].new(self, aiTblInfo.conditionParams, eventObj)
			if conditionObj ~= nil and eventObj ~= nil then
				self.aiList[#self.aiList+1] = {condition = conditionObj, evnet = eventObj}
				if self.aiTypeList[aiTblInfo.conditionId] == nil then
					self.aiTypeList[aiTblInfo.conditionId] = {}
				end
				table.insert(self.aiTypeList[aiTblInfo.conditionId], conditionObj)
			end
		end
	end

	self.initFinFlag = true
end

function GameAI:update(t)
	if self.initFinFlag == false then
		return
	end

	for k,v in pairs(self.aiList) do
		if v.condition ~= nil then
			v.condition:update(t)
		end
	end
end

function GameAI:monterDie(monsterid, initPos)
	if self.map.stopUpdateFlag == true then
		return
	end

	if self.aiTypeList[GameAIDefine.SCENEAI_CONDITION_TYPE.monster_die] == nil then
		return
	end

	for k,v in pairs(self.aiTypeList[GameAIDefine.SCENEAI_CONDITION_TYPE.monster_die]) do
		if v.someoneDie ~= nil then
			v:someoneDie(monsterid, initPos)
		end
	end
end

return GameAI
