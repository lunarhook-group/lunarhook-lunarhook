local GameControlButton = import("app.views.GameControlButton")

local GameResult = class("GameResult", BaseLayer)


function GameResult:ctor()
	GameResult.super.ctor(self)

	self.stageId = nil
	self.resultData = {}

	self:initUI()
end

function GameResult:initUI()
	--black bg
	local bgColorLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 75), display.width, display.height)
	if bgColorLayer ~= nil then
		bgColorLayer:setAnchorPoint(cc.p(0, 0))
		bgColorLayer:setPosition(cc.p(0, 0))
		self:addChild(bgColorLayer, 1)
	end
	local bgCoverBtn = GameControlButton.new({
        btnBg = ResourceDef.IMAGE_TRANSPARENT,
        dstSize = {width=display.width, height=display.height},
        callback = function ()
        end
    })
    if bgCoverBtn ~= nil then
		bgCoverBtn:setAnchorPoint(cc.p(0.5, 0.5))
		bgCoverBtn:setPosition(cc.p(display.cx, display.cy))
	    self:addChild(bgCoverBtn, 2)
	end

	--rank node
	self.rankNode = require("app.views.RankDetailLayer").new()
	if self.rankNode ~= nil then
		self.rankNode:setPosition(cc.p(display.cx, display.cy+150))
		self:addChild(self.rankNode, 5)
	end

	--func node
	local offX = 30
	self.funcPosList = {
		{x=-120+offX, y=0},
		{x=-80+offX, y=0},
		{x=0+offX, y=0},
		{x=50+offX, y=0},
		{x=120+offX, y=0},
	}

	self.funcNode = display.newNode()
	if self.funcNode ~= nil then
		self.funcNode:setAnchorPoint(cc.p(0.5,0.5))
		self.funcNode:setPosition(cc.p(display.cx, display.cy-180))
		self:addChild(self.funcNode, 4)

		local funcPanelBgPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.GAME_RESULT_MIDDLE_BG_PANEL)))
		if funcPanelBgPic ~= nil then
			funcPanelBgPic:setAnchorPoint(cc.p(0.5,0.5))
			funcPanelBgPic:setPosition(cc.p(20, 0))
			funcPanelBgPic:setScaleX(400/funcPanelBgPic:getContentSize().width)
			funcPanelBgPic:setScaleY(150/funcPanelBgPic:getContentSize().height)
			self.funcNode:addChild(funcPanelBgPic, 2)
		end
		local leftGan = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.GAME_RESULT_MIDDLE_PANEL_LONG_POLE)))
		if leftGan ~= nil then
			leftGan:setAnchorPoint(cc.p(0.5,0))
			leftGan:setPosition(cc.p(-118, 50))
			leftGan:setScaleX(-1)
			self.funcNode:addChild(leftGan, 1)
		end
		local rightGan = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.GAME_RESULT_MIDDLE_PANEL_LONG_POLE)))
		if rightGan ~= nil then
			rightGan:setAnchorPoint(cc.p(0.5,0))
			rightGan:setPosition(cc.p(165, 55))
			self.funcNode:addChild(rightGan, 1)
		end

		--retry button
		self.buttonRetry = GameControlButton.new({
	        btnBg = ResourceDef.COMMON_BUTTON_RES_RETRY,
	        dstSize = {width=96, height=96},
	        callback = function ()
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
	        	self:gameRetry()
	        end
	    })
	    if self.buttonRetry ~= nil then
			self.buttonRetry:setAnchorPoint(cc.p(0.5, 0.5))
			self.buttonRetry:setPosition(cc.p(0, 0))
		    self.funcNode:addChild(self.buttonRetry, 3)
		end

		--return button
		self.buttonReturnWorld = GameControlButton.new({
	        btnBg = ResourceDef.COMMON_BUTTON_RES_RETURN_LIST,
	        dstSize = {width=96, height=96},
	        callback = function ()
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
	        	self:returnWorld()
	        end
	    })
	    if self.buttonReturnWorld ~= nil then
			self.buttonReturnWorld:setAnchorPoint(cc.p(0.5, 0.5))
			self.buttonReturnWorld:setPosition(cc.p(0, 0))
		    self.funcNode:addChild(self.buttonReturnWorld, 3)
		end

		--next button
		self.buttonNextStage = GameControlButton.new({
	        btnBg = ResourceDef.COMMON_BUTTON_RES_NEXT_CHALLENGE,
	        dstSize = {width=96, height=96},
	        callback = function ()
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
	        	self:nextStage()
	        end
	    })
	    if self.buttonNextStage ~= nil then
			self.buttonNextStage:setAnchorPoint(cc.p(0.5, 0.5))
			self.buttonNextStage:setPosition(cc.p(0, 0))
		    self.funcNode:addChild(self.buttonNextStage, 3)
		end

		--share button
		self.buttonShare = GameControlButton.new({
	        btnBg = ResourceDef.IMAGE_TRANSPARENT,
	        dstSize = {width=96, height=96},
	        buttonFont = LangStringDefine.SHARE_LABEL,
	        buttonFontSize = 22,
	        buttonFontColor = cc.c3b(0,0,255),
	        callback = function ()
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
	        	self:share()
	        end
	    })
	    if self.buttonShare ~= nil then
			self.buttonShare:setAnchorPoint(cc.p(0.5, 0.5))
			self.buttonShare:setPosition(cc.p(0, 0))
			self.buttonShare:setVisible(false)
		    self.funcNode:addChild(self.buttonShare, 3)
		end
	end

end

function GameResult:resetLayer(stageId, result, isShopMap, isTestMap)
	if stageId == nil or result == nil then 
		return
	end
	if isShopMap == nil then
		isShopMap = false
	end
	if isTestMap == nil then
		isTestMap = false
	end

	self.stageId = stageId
	self.resultData = result
	self.isShopMap = isShopMap
	self.isTestMap = isTestMap
	
	if self.rankNode ~= nil then
		self.rankNode:setRankInfo(self.resultData.rankInfo)
	end
   
	if result.isWin == true then
		if self.buttonRetry ~= nil then
			self.buttonRetry:setVisible(true)
			self.buttonRetry:setPosition(cc.p(self.funcPosList[1].x, self.funcPosList[1].y))
		end
		if self.buttonReturnWorld ~= nil then
			self.buttonReturnWorld:setVisible(true)
			self.buttonReturnWorld:setPosition(cc.p(self.funcPosList[3].x, self.funcPosList[3].y))
		end
		if self.buttonNextStage ~= nil then
			self.buttonNextStage:setVisible(self.isShopMap == false and self.isTestMap == false)
			self.buttonNextStage:setPosition(cc.p(self.funcPosList[5].x, self.funcPosList[5].y))
		end
	else
		if self.buttonRetry ~= nil then
			self.buttonRetry:setVisible(true)
			self.buttonRetry:setPosition(cc.p(self.funcPosList[2].x, self.funcPosList[2].y))
		end
		if self.buttonReturnWorld ~= nil then
			self.buttonReturnWorld:setVisible(true)
			self.buttonReturnWorld:setPosition(cc.p(self.funcPosList[4].x, self.funcPosList[4].y))
		end
		if self.buttonNextStage ~= nil then
			self.buttonNextStage:setVisible(false)
		end
	end

	if self.isTestMap == true then
		if self.buttonRetry ~= nil then
			self.buttonRetry:setVisible(false)
		end
	end

end

-- function GameResult:nextContent()
-- 	self:closeLayer()

-- 	 --request for rank
--     local params = {id = self.stageId}
--     local ret, resp = GameNetWorker.createHttpRequestWithPostParam(GameConfig.SERVER_ADDRESS .. GameConfig.REQUEST_URL.rank, params, false)
--     if ret == true then
--         local respInfo = json.decode(resp)
--         if respInfo ~= nil then
--             -- dump(respInfo)
--             if respInfo.errorId ~= nil then
--                 self:showTips(respInfo.errorMsg)
--             else
--                 UserDataManager.RANK_LIST[tostring(self.stageId)] = {
--                     myRank = 0,
--                     rankInfo = respInfo,
--                     lastReqTime = os.time()
--                 }

--                 for i=1, #respInfo do
--                     if tostring(respInfo[i].playerId) == tostring(UserDataManager.PLAYER_UID) then
--                         UserDataManager.RANK_LIST[tostring(self.stageId)].myRank = i
--                         break
--                     end
--                 end
--             end
--         end
--     end


-- 	local curScene = display.getRunningScene()
-- 	if curScene ~= nil and curScene.StageInfoLayer ~= nil then
-- 		curScene.StageInfoLayer:resetLayer(self.stageId, self.resultData)
-- 		curScene.StageInfoLayer:openLayer()
-- 		AudioManager.stopBackgroundMusic(false)
-- 	end
-- end

function GameResult:gameRetry()
	if self.stageId == nil then
		return
	end

	local curScene = display.getRunningScene()
	if curScene ~= nil then
		curScene:UITransition(function()
			curScene:enterGame(self.stageId, self.isShopMap)
		end)
	end
end
	
function GameResult:returnWorld()
	local curScene = display.getRunningScene()
	if curScene ~= nil then
		curScene:UITransition(function()
			if self.isShopMap == true then
				curScene:openShop("bought")
				if UserDataManager.TMP_VALUE ~= nil then
					if curScene.ShopLayer ~= nil and curScene.ShopLayer.tableView ~= nil then
						curScene.ShopLayer.tableView:setContentOffset(UserDataManager.TMP_VALUE)
					end
					UserDataManager.TMP_VALUE = nil
				end
				AudioManager.stopBackgroundMusic(false)
				AudioManager.playBackgroundMusic(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.shopBgMusic), true)
			elseif self.isTestMap == true then
				curScene:openEditor()
				if UserDataManager.TMP_VALUE ~= nil then
					if curScene.StageEditLayer ~= nil and curScene.StageEditLayer.myMakeListView ~= nil then
						curScene.StageEditLayer:openMyMakeList()
						curScene.StageEditLayer.myMakeListView:setContentOffset(UserDataManager.TMP_VALUE)
					end
					UserDataManager.TMP_VALUE = nil
				end
				AudioManager.stopBackgroundMusic(false)
				AudioManager.playBackgroundMusic(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.shopBgMusic), true)
			else
				local worldIdx = nil
				if self.stageId ~= nil then
					worldIdx = math.floor(self.stageId/100)
				end
				curScene:returnStageSelectLayer(worldIdx)
				AudioManager.stopBackgroundMusic(false)
				AudioManager.playBackgroundMusic(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.mainBGMusic), true)
			end
		end)
	end
end

function GameResult:nextStage()
	if self.stageId == nil then
		return
	end
	if self.isShopMap == true then
		return 
	end

	local nextStageId = nil
	local stageTblInfo = ConfigManager.stageTbl[tostring(self.stageId)]
	if stageTblInfo ~= nil and stageTblInfo.nextStageId ~= nil then
		nextStageId = stageTblInfo.nextStageId
	end

	local nextStageTblInfo = ConfigManager.stageTbl[tostring(nextStageId)]
	if nextStageTblInfo == nil then
		self:returnWorld()
		AudioManager.playBackgroundMusic(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.mainBGMusic), true)
		return 
	end

	local curScene = display.getRunningScene()
	if curScene ~= nil then
		curScene:UITransition(function()
			curScene:enterGame(nextStageId)
		end)
	end
end

function GameResult:share()
	local curScene = display.getRunningScene()
	if curScene ~= nil then
		curScene:showTips(LangStringDefine.FUNC_NOT_OPEN)
	end
end

function GameResult:reset()
	if self.rankNode ~= nil then
		self.rankNode:reset()
	end
	if self.buttonNextStage ~= nil then
		self.buttonNextStage:setVisible(false)
	end
end

function GameResult:openLayer()
	self:setVisible(true)
end


function GameResult:closeLayer()
	self:setVisible(false)
	self:reset()
end

return GameResult
