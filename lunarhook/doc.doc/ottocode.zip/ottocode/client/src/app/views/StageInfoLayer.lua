local GameControlButton = import("app.views.GameControlButton")

local StageInfoLayer = class("StageInfoLayer", BaseLayer)

function StageInfoLayer:ctor()
	StageInfoLayer.super.ctor(self)
	self.stageId = nil
	self:initUI()
end

function StageInfoLayer:initUI()
	self.nodeMidMid = display.newNode()
	if self.nodeMidMid ~= nil then
		self.nodeMidMid:setAnchorPoint(cc.p(0.5,0.5))
		self.nodeMidMid:setPosition(cc.p(display.cx, display.cy))
		self:addChild(self.nodeMidMid)
	else
		return
	end

	--bg
	local bgLayerSize = {width=560, height=896}
	self.bgNode = display.newNode()
	if self.bgNode ~= nil then
		self.bgNode:setAnchorPoint(cc.p(0.5,0.5))
		self.bgNode:setPosition(cc.p(0, 0))
		self.nodeMidMid:addChild(self.bgNode, 1)

		local bgCover = cc.LayerColor:create(cc.c4b(0, 0, 0, 200), display.width, display.height)
		if bgCover ~= nil then
			bgCover:setAnchorPoint(cc.p(0.5,0.5))
			bgCover:setPosition(cc.p(0-display.cx, 0-display.cy))
			self.bgNode:addChild(bgCover,1)
		end
		local bgColorLayer = cc.LayerColor:create(cc.c4b(140, 83, 67, 255), bgLayerSize.width, bgLayerSize.height)
		if bgColorLayer ~= nil then
			bgColorLayer:setAnchorPoint(cc.p(0.5,0.5))
			bgColorLayer:setPosition(cc.p(0-bgLayerSize.width/2, 0-bgLayerSize.height/2))
			self.bgNode:addChild(bgColorLayer,2)
		end

		local lineMainCountList = {28,28,54,54}
		local lineSubCountList = {30,30,24,24}
		for i=1,4 do
			local sidePic = display.newSprite(ResourceManager.ImageName(ResourceDef.POP_PANEL_SIDE))
			if sidePic ~= nil then
				sidePic:setAnchorPoint(cc.p(0.5,0.5))
				sidePic:setScaleX(0.5)
				if i <= 2 then
					sidePic:setScaleY(bgLayerSize.width/5)
					sidePic:setRotation(90)
					sidePic:setPosition(cc.p(0, bgLayerSize.height/2*math.pow(-1, i)))
				else
					sidePic:setScaleY(bgLayerSize.height/5)
					sidePic:setPosition(cc.p(bgLayerSize.width/2*math.pow(-1,i), 0))
				end
				self.bgNode:addChild(sidePic, 3)
			end

			local cornerPic = nil
			if i == 1 then
				cornerPic = display.newSprite(ResourceManager.ImageName(ResourceDef.POP_PANEL_CORNER_RETURN_BG))
			else
				cornerPic = display.newSprite(ResourceManager.ImageName(ResourceDef.POP_PANEL_CORNER_PIC))
			end
			if cornerPic ~= nil then
				cornerPic:setAnchorPoint(cc.p(0.9, 0.1))
				if i == 1 then
					cornerPic:setAnchorPoint(cc.p(0.15, 0.85))
					cornerPic:setPosition(cc.p(0-bgLayerSize.width/2, bgLayerSize.height/2))
				elseif i == 2 then
					cornerPic:setScaleY(-1)
					cornerPic:setPosition(cc.p(bgLayerSize.width/2, bgLayerSize.height/2))
				elseif i == 3 then
					cornerPic:setScaleX(-1)
					cornerPic:setPosition(cc.p(0-bgLayerSize.width/2, 0-bgLayerSize.height/2))
				else
					cornerPic:setPosition(cc.p(bgLayerSize.width/2, 0-bgLayerSize.height/2))
				end
				self.bgNode:addChild(cornerPic, 4)
			end

			local lineBorderCornerMainPic = display.newSprite(ResourceManager.ImageName(ResourceDef.LINE_CORNER_1))
			if lineBorderCornerMainPic ~= nil then
				lineBorderCornerMainPic:setAnchorPoint(cc.p(1, 1))
				if i == 1 then
					lineBorderCornerMainPic:setPosition(cc.p(bgLayerSize.width/2-20, bgLayerSize.height/2-20))
				elseif i == 2 then
					lineBorderCornerMainPic:setScaleX(-1)
					lineBorderCornerMainPic:setPosition(cc.p(0-(bgLayerSize.width/2-20), bgLayerSize.height/2-20))
				elseif i == 3 then
					lineBorderCornerMainPic:setScaleX(-1)
					lineBorderCornerMainPic:setScaleY(-1)
					lineBorderCornerMainPic:setPosition(cc.p(0-(bgLayerSize.width/2-20), 0-(bgLayerSize.height/2-20)))
				else
					lineBorderCornerMainPic:setScaleY(-1)
					lineBorderCornerMainPic:setPosition(cc.p(bgLayerSize.width/2-20, 0-(bgLayerSize.height/2-20)))
				end
				self.bgNode:addChild(lineBorderCornerMainPic, 3)
			end

			local lineBorderCornerSubPic = display.newSprite(ResourceManager.ImageName(ResourceDef.LINE_CORNER_2))
			if lineBorderCornerSubPic ~= nil then
				lineBorderCornerSubPic:setAnchorPoint(cc.p(1, 1))
				if i == 1 then
					lineBorderCornerSubPic:setPosition(cc.p(bgLayerSize.width/2-35, bgLayerSize.height/2-150))
				elseif i == 2 then
					lineBorderCornerSubPic:setScaleX(-1)
					lineBorderCornerSubPic:setPosition(cc.p(0-(bgLayerSize.width/2-35), bgLayerSize.height/2-150))
				elseif i == 3 then
					lineBorderCornerSubPic:setScaleX(-1)
					lineBorderCornerSubPic:setScaleY(-1)
					lineBorderCornerSubPic:setPosition(cc.p(0-(bgLayerSize.width/2-35), bgLayerSize.height/2-550))
				else
					lineBorderCornerSubPic:setScaleY(-1)
					lineBorderCornerSubPic:setPosition(cc.p(bgLayerSize.width/2-35, bgLayerSize.height/2-550))
				end
				self.bgNode:addChild(lineBorderCornerSubPic, 3)
			end

			local lineBorderMainPic = self:makeLine(ResourceDef.LINE_1, lineMainCountList[i])
			if lineBorderMainPic ~= nil then
				lineBorderMainPic:setAnchorPoint(cc.p(0.5,0.5))
				if i==1 then
					lineBorderMainPic:setPosition(cc.p(0-(bgLayerSize.width/2-20) + lineBorderCornerMainPic:getContentSize().width, bgLayerSize.height/2-20))
				elseif i == 2 then
					lineBorderMainPic:setPosition(cc.p(0-(bgLayerSize.width/2-20) + lineBorderCornerMainPic:getContentSize().width, 0-(bgLayerSize.height/2-20)))
				elseif i == 3 then
					lineBorderMainPic:setRotation(90)
					lineBorderMainPic:setPosition(cc.p(0-(bgLayerSize.width/2-21), bgLayerSize.height/2-20 - lineBorderCornerMainPic:getContentSize().height))
				else
					lineBorderMainPic:setRotation(90)
					lineBorderMainPic:setPosition(cc.p(bgLayerSize.width/2-21, bgLayerSize.height/2-20 - lineBorderCornerMainPic:getContentSize().height))
				end
				self.bgNode:addChild(lineBorderMainPic, 3)
			end

			local lineBorderSubPic = self:makeLine(ResourceDef.LINE_1, lineSubCountList[i])
			if lineBorderSubPic ~= nil then
				lineBorderSubPic:setAnchorPoint(cc.p(0.5,0.5))
				if i==1 then
					lineBorderSubPic:setPosition(cc.p(0-(bgLayerSize.width/2-20) + lineBorderCornerSubPic:getContentSize().width, bgLayerSize.height/2-150))
				elseif i == 2 then
					lineBorderSubPic:setPosition(cc.p(0-(bgLayerSize.width/2-20) + lineBorderCornerSubPic:getContentSize().width, bgLayerSize.height/2-550))
				elseif i == 3 then
					lineBorderSubPic:setRotation(90)
					lineBorderSubPic:setPosition(cc.p(0-(bgLayerSize.width/2-35), bgLayerSize.height/2-150 - lineBorderCornerSubPic:getContentSize().height + 10))
				else
					lineBorderSubPic:setRotation(90)
					lineBorderSubPic:setPosition(cc.p(bgLayerSize.width/2-35, bgLayerSize.height/2-150 - lineBorderCornerSubPic:getContentSize().height + 10))
				end
				self.bgNode:addChild(lineBorderSubPic, 3)
			end
		end

		local lineMiddle = self:makeLine(ResourceDef.LINE_1, 36)
		if lineMiddle ~= nil then
			lineMiddle:setAnchorPoint(cc.p(0.5,0.5))
			lineMiddle:setPosition(cc.p(0-(bgLayerSize.width/2-45), 80))
			self.bgNode:addChild(lineMiddle, 3)
		end

		self.mainTitleBg = display.newSprite(ResourceManager.ImageName(ResourceDef.POP_PANEL_TITLE_BG))
		if self.mainTitleBg ~= nil then
			self.mainTitleBg:setAnchorPoint(cc.p(0.5,0.5))
			self.mainTitleBg:setPosition(cc.p(0, bgLayerSize.height/2))
			self.bgNode:addChild(self.mainTitleBg, 5)
		end
	end

	--close button
	self.buttonClose = GameControlButton.new({
        btnBg = ResourceDef.BUTTON_RETURN,
        dstSize = {width=80, height=80},
        callback = function ()
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_small), false)
        	self:closeLayer()
        end
    })
    if self.buttonClose ~= nil then
		self.buttonClose:setAnchorPoint(cc.p(0.5, 0.5))
		self.buttonClose:setPosition(cc.p(0-bgLayerSize.width/2+5, bgLayerSize.height/2-5))
	    self.nodeMidMid:addChild(self.buttonClose, 2)
	end

	self.buttonList = {}
	--main button
	self.mainButton1 = GameControlButton.new({
        btnBg = ResourceDef.BUTTON_LONG,
        dstSize = {width=240, height=68},
        callback = function()
        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
        	self:challenge()
        end
    })
    if self.mainButton1 ~= nil then
		self.mainButton1:setAnchorPoint(cc.p(0.5, 0.5))
		self.mainButton1:setPosition(cc.p(0,0-bgLayerSize.height/2 + 230))
	    self.nodeMidMid:addChild(self.mainButton1, 2)
	    self.buttonList[#self.buttonList+1] = self.mainButton1

	    self.mainButton1_label = display.newTTFLabel({
	        text = LangStringDefine.CONTINUE_CHALLENGE,
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 30,
	        align = cc.TEXT_ALIGNMENT_CENTER,
	        color = cc.c3b(141,84,67)
	    })
	    if self.mainButton1_label ~= nil then
	    	self.mainButton1_label:setAnchorPoint(cc.p(0.5,0.5))
	    	self.mainButton1_label:setPosition(cc.p(0,0))
	    	self.mainButton1:addChild(self.mainButton1_label, 10)
	    end
	end
	--main button
	self.mainButton2 = GameControlButton.new({
        btnBg = ResourceDef.BUTTON_LONG,
        dstSize = {width=240, height=68},
    })
    if self.mainButton2 ~= nil then
		self.mainButton2:setAnchorPoint(cc.p(0.5, 0.5))
		self.mainButton2:setPosition(cc.p(0,0-bgLayerSize.height/2 + 140))
	    self.nodeMidMid:addChild(self.mainButton2, 2)
	    self.buttonList[#self.buttonList+1] = self.mainButton2

	    self.mainButton2_label = display.newTTFLabel({
	        text = "",
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 30,
	        align = cc.TEXT_ALIGNMENT_CENTER,
	        color = cc.c3b(141,84,67)
	    })
	    if self.mainButton2_label ~= nil then
	    	self.mainButton2_label:setAnchorPoint(cc.p(0.5,0.5))
	    	self.mainButton2_label:setPosition(cc.p(0,0))
	    	self.mainButton2:addChild(self.mainButton2_label, 10)
	    end
	end

	--stage title
	self.stageTitleLabel = display.newTTFLabel({
        text = "",
        font = ResourceDef.FONT_GAME_MAIN,
        size = 32,
        align = cc.TEXT_ALIGNMENT_CENTER,
        color = cc.c3b(141,84,67)
    })
    if self.stageTitleLabel ~= nil then
        self.stageTitleLabel:setAnchorPoint(cc.p(0.5,0.5))
        self.stageTitleLabel:setPosition(cc.p(0, bgLayerSize.height/2))
        self.nodeMidMid:addChild(self.stageTitleLabel, 1)
    end

    --labels
    self.gameFailedLabel = display.newTTFLabel({
        text = "",
        font = ResourceDef.FONT_GAME_MAIN,
        size = 32,
        align = cc.TEXT_ALIGNMENT_CENTER,
        color = cc.c3b(249,232,188)
    })
    if self.gameFailedLabel ~= nil then
        self.gameFailedLabel:setAnchorPoint(cc.p(0.5,0.5))
        self.gameFailedLabel:setPosition(cc.p(0, bgLayerSize.height/2 - 100))
        self.gameFailedLabel:setVisible(false)
        self.nodeMidMid:addChild(self.gameFailedLabel, 1)
    end

    self.centerUIContent = {}
    local bestRecord_label = display.newTTFLabel({
        text = LangStringDefine.BEST_RECORD_DESC_LABEL,
        font = ResourceDef.FONT_GAME_MAIN,
        size = 28,
        align = cc.TEXT_ALIGNMENT_CENTER,
        color = cc.c3b(249,232,188)
    })
    if bestRecord_label ~= nil then
        bestRecord_label:setAnchorPoint(cc.p(0,0.5))
        bestRecord_label:setPosition(cc.p(0-bgLayerSize.width/2 + 50, bgLayerSize.height/2 - 140))
        self.nodeMidMid:addChild(bestRecord_label, 1)
        self.centerUIContent[#self.centerUIContent+1] = bestRecord_label
    end

    self.bestRecord_tag = display.newSprite(ResourceManager.ImageName(ResourceDef.BEST_RECORD_NEW_TAG))
    if self.bestRecord_tag ~= nil then
    	self.bestRecord_tag:setAnchorPoint(cc.p(0.5,0.5))
    	self.bestRecord_tag:setPosition(cc.p(-30,bgLayerSize.height/2 - 140))
    	self.bestRecord_tag:setVisible(false)
    	self.nodeMidMid:addChild(self.bestRecord_tag, 1)
    	self.centerUIContent[#self.centerUIContent+1] = self.bestRecord_tag
    end

    --no record node
    self.noRecordNode = display.newNode()
    if self.noRecordNode ~= nil then
    	self.noRecordNode:setAnchorPoint(cc.p(0.5,0.5))
        self.noRecordNode:setPosition(cc.p(0, bgLayerSize.height/2 - 210))
        self.nodeMidMid:addChild(self.noRecordNode, 1)
        self.centerUIContent[#self.centerUIContent+1] = self.noRecordNode

        local notHaveRecord_label = display.newTTFLabel({
	        text = LangStringDefine.HAVE_NO_RECORD_DESC_LABEL,
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 28,
	        align = cc.TEXT_ALIGNMENT_CENTER,
	        color = cc.c3b(249,232,188)
	    })
	    if notHaveRecord_label ~= nil then
	        notHaveRecord_label:setAnchorPoint(cc.p(0.5,0.5))
	        notHaveRecord_label:setPosition(cc.p(0, 0))
	        self.noRecordNode:addChild(notHaveRecord_label)
	    end

	    self.noRecordNode:setVisible(false)
    end

    --record node
    self.recordNode = display.newNode()
    if self.recordNode ~= nil then
    	self.recordNode:setAnchorPoint(cc.p(0.5,0.5))
        self.recordNode:setPosition(cc.p(0, bgLayerSize.height/2 - 220))
        self.nodeMidMid:addChild(self.recordNode, 1)
        self.centerUIContent[#self.centerUIContent+1] = self.recordNode

	    local stepCount_label = display.newTTFLabel({
	        text = "LangStringDefine.STEP_LABEL",
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 25,
	        align = cc.TEXT_ALIGNMENT_CENTER,
	        color = cc.c3b(249,232,188)
	    })
	    if stepCount_label ~= nil then
	        stepCount_label:setAnchorPoint(cc.p(1,0.5))
	        stepCount_label:setPosition(cc.p(0-bgLayerSize.width/4-35, 0))
	        self.recordNode:addChild(stepCount_label, 1)
	    end
	    self.stepCountText = display.newTTFLabel({
	        text = "0",
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 25,
	        align = cc.TEXT_ALIGNMENT_CENTER,
	        color = cc.c3b(249,232,188)
	    })
	    if self.stepCountText ~= nil then
	        self.stepCountText:setAnchorPoint(cc.p(0,0.5))
	        self.stepCountText:setPosition(cc.p(0-bgLayerSize.width/4-30, 0))
	        self.recordNode:addChild(self.stepCountText)
	    end

	    self.recordDateText = display.newTTFLabel({
	        text = "0",
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 18,
	        align = cc.TEXT_ALIGNMENT_CENTER,
	        color = cc.c3b(249,232,188)
	    })
	    if self.recordDateText ~= nil then
	        self.recordDateText:setAnchorPoint(cc.p(1,0.5))
	        self.recordDateText:setPosition(cc.p(bgLayerSize.width/4+60, 80))
	        self.recordNode:addChild(self.recordDateText)
	    end

	    --show video button
		self.buttonShowVideo = GameControlButton.new({
	        btnBg = ResourceDef.BUTTON_OK,
	        dstSize = {width=108, height=42},
	        buttonFont = LangStringDefine.VIDEO_BUTTON_LABEL,
	        buttonFontSize = 18,
	        buttonFontColor = cc.c3b(141,84,67),
	        callback = function ()
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
	        	self:showVideo()
	        end
	    })
	    if self.buttonShowVideo ~= nil then
			self.buttonShowVideo:setAnchorPoint(cc.p(0.5, 0.5))
			self.buttonShowVideo:setPosition(cc.p(bgLayerSize.width/4+15,0))
		    self.recordNode:addChild(self.buttonShowVideo)
		end

	    self.recordNode:setVisible(false)
	end


    --rank node
    self.rankNode = display.newNode()
    if self.rankNode ~= nil then
    	self.rankNode:setAnchorPoint(cc.p(0.5,0.5))
        self.rankNode:setPosition(cc.p(0, 100))
        self.nodeMidMid:addChild(self.rankNode, 1)
        self.centerUIContent[#self.centerUIContent+1] = self.rankNode

	    local friendRank_label = display.newTTFLabel({
	        text = LangStringDefine.FRIEND_RANK_LABEL,
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 25,
	        align = cc.TEXT_ALIGNMENT_CENTER,
	        color = cc.c3b(249,232,188)
	    })
	    if friendRank_label ~= nil then
	        friendRank_label:setAnchorPoint(cc.p(1,0.5))
	        friendRank_label:setPosition(cc.p(0-bgLayerSize.width/4+20, 15))
	        self.rankNode:addChild(friendRank_label)
	    end
	    self.friendRankText = display.newTTFLabel({
	        text = LangStringDefine.WAIT_FOR_SERVER_DATA,
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 25,
	        align = cc.TEXT_ALIGNMENT_CENTER,
	        color = cc.c3b(249,232,188)
	    })
	    if self.friendRankText ~= nil then
	        self.friendRankText:setAnchorPoint(cc.p(0,0.5))
	        self.friendRankText:setPosition(cc.p(0-bgLayerSize.width/4+25, 15))
	        self.rankNode:addChild(self.friendRankText)
	    end
	    local worldRank_label = display.newTTFLabel({
	        text = LangStringDefine.WORLD_RANK_LABEL,
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 25,
	        align = cc.TEXT_ALIGNMENT_CENTER,
	        color = cc.c3b(249,232,188)
	    })
	    if worldRank_label ~= nil then
	        worldRank_label:setAnchorPoint(cc.p(1,0.5))
	        worldRank_label:setPosition(cc.p(0-bgLayerSize.width/4+20, -35))
	        self.rankNode:addChild(worldRank_label)
	    end
	    self.worldRankText = display.newTTFLabel({
	        text = LangStringDefine.WAIT_FOR_SERVER_DATA,
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 25,
	        align = cc.TEXT_ALIGNMENT_CENTER,
	        color = cc.c3b(249,232,188)
	    })
	    if self.worldRankText ~= nil then
	        self.worldRankText:setAnchorPoint(cc.p(0,0.5))
	        self.worldRankText:setPosition(cc.p(0-bgLayerSize.width/4+25, -35))
	        self.rankNode:addChild(self.worldRankText)
	    end

	    --show rank button
		self.buttonShowRank = GameControlButton.new({
	        btnBg = ResourceDef.BUTTON_OK,
		    dstSize = {width=108, height=42},
	        buttonFont = LangStringDefine.RANK_BUTTON_LABEL,
	        buttonFontSize = 18,
	        buttonFontColor = cc.c3b(141,84,67),
	        callback = function ()
	        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
	        	self:showRank()
	        end
	    })
	    if self.buttonShowRank ~= nil then
			self.buttonShowRank:setAnchorPoint(cc.p(0.5, 0.5))
			self.buttonShowRank:setPosition(cc.p(bgLayerSize.width/4+15, -20))
		    self.rankNode:addChild(self.buttonShowRank)
		end

	end

	for k,v in pairs(self.centerUIContent) do
		v:setPositionY(v:getPositionY()-75)
	end

end

function StageInfoLayer:makeLine(res, count)
	if res == nil or count == nil then
		return nil
	end

	if res == "" or count <= 0 then
		return nil
	end


	local node = display.newNode()
	if node == nil then
		return nil
	end

	for i=1, count do
		local pic = display.newSprite(ResourceManager.ImageName(res))
		if pic ~= nil then
			pic:setAnchorPoint(cc.p(0, 0.5))
			pic:setPosition(cc.p((i-1)*pic:getContentSize().width, 0))
			node:addChild(pic)
		end
	end

	return node
end

function StageInfoLayer:resetLayer(stageId, stageData)
	if stageId == nil then
		return
	end

	-- stageData = {
	-- 	isGameEnd = false,
	-- 	isWin = false,
	-- 	steps = 0,
	-- 	isNewRecord = false,
	-- }

	if stageData.isNewRecord == nil then
		stageData.isNewRecord = false
	end

	self.stageId = stageId

	local stageTblInfo = ConfigManager.stageTbl[tostring(self.stageId)]
	if stageTblInfo == nil then
		return
	end

	--check have finish stage  todo shang
	local stageHasFinishFlag = false
	local playerStageData = UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(self.stageId)]
	if playerStageData ~= nil and playerStageData.firstTime ~= nil then
		if playerStageData.firstTime ~= 0 then
			stageHasFinishFlag = true
		end
	end
	-- dump(playerStageData)

    if self.gameFailedLabel ~= nil then
    	if stageData.isWin == true then
    		self.gameFailedLabel:setString(LangStringDefine.GAME_SUCCESS_DESC_LABEL)
    	else
    		self.gameFailedLabel:setString(LangStringDefine.GAME_FAILED_DESC_LABEL)
    	end
        self.gameFailedLabel:setVisible(false)--stageData.isGameEnd)
    end
    if self.bestRecord_tag ~= nil then
    	self.bestRecord_tag:setVisible(stageData.isNewRecord)
    end
	if self.noRecordNode ~= nil then
		self.noRecordNode:setVisible(not stageHasFinishFlag)
	end
	if self.recordNode ~= nil then
		self.recordNode:setVisible(stageHasFinishFlag)
	end
	if self.stageTitleLabel ~= nil then
		self.stageTitleLabel:setString(stageTblInfo.title)
	end

	if self.mainButton1 ~= nil then
		self.mainButton1:setVisible(stageData.isGameEnd)
	end
	if self.mainButton2 ~= nil then
		if stageData.isGameEnd == false then
			self.mainButton2_label:setString(LangStringDefine.CHALLENGE_BEGIN)
			self.mainButton2.options.callback = function()
				AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
				self:challenge()
			end
		else
			if stageData.isWin == true then
				self.mainButton2_label:setString(LangStringDefine.GOTO_NEXT_STAGE_LABEL)
				self.mainButton2.options.callback = function()
					AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
					self:challengeNext()
				end
			else
				self.mainButton2_label:setString(LangStringDefine.CHOOSE_OTHER_STAGE_LABEL)
				self.mainButton2.options.callback = function()
					AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
					self:returnStageSelectLayer()
				end
			end
		end
	end

	if self.buttonClose ~= nil then
		self.buttonClose:setVisible(not stageData.isGameEnd)
	end

	if self.stepCountText ~= nil then
		if playerStageData ~= nil and playerStageData.step ~= nil then
			self.stepCountText:setString(tostring(playerStageData.step))
		else
			self.stepCountText:setString("0")
		end
	end
		
	if self.recordDateText ~= nil then
		if playerStageData ~= nil and playerStageData.record_time ~= nil then
			local tmpStr = os.date(" %Y ", playerStageData.record_time)..LangStringDefine.STR_YEAR..os.date(" %m ", playerStageData.record_time)..LangStringDefine.STR_MONTH..os.date(" %d ", playerStageData.record_time)..LangStringDefine.STR_DAY
			self.recordDateText:setString(tmpStr)
		else
			self.recordDateText:setString("")
		end
	end

	if self.friendRankText ~= nil then
		--todo  好友排行
		if false then

		else
			self.friendRankText:setString(LangStringDefine.NO_RANK_VALUE)
		end
	end
	if self.worldRankText ~= nil then
		if UserDataManager.RANK_LIST[tostring(self.stageId)] ~= nil and 
		   UserDataManager.RANK_LIST[tostring(self.stageId)].myRank ~= nil and 
		   UserDataManager.RANK_LIST[tostring(self.stageId)].myRank ~= 0 then
			self.worldRankText:setString(tostring(UserDataManager.RANK_LIST[tostring(self.stageId)].myRank))
		else
			self.worldRankText:setString(LangStringDefine.NO_RANK_VALUE)
		end
	end

end


function StageInfoLayer:challenge()
	if self.stageId == nil then
		return
	end

	local curScene = display.getRunningScene()
	if curScene ~= nil then
		curScene:enterGame(self.stageId)
	end
end

function StageInfoLayer:challengeNext()
	if self.stageId == nil then
		return
	end

	local nextStageId = nil
	local stageTblInfo = ConfigManager.stageTbl[tostring(self.stageId)]
	if stageTblInfo ~= nil and stageTblInfo.nextStageId ~= nil then
		nextStageId = stageTblInfo.nextStageId
	end

	local nextStageTblInfo = ConfigManager.stageTbl[tostring(nextStageId)]
	if nextStageTblInfo == nil then
		self:returnStageSelectLayer()
		AudioManager.playBackgroundMusic(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.mainBGMusic), true)
		return 
	end

	local curScene = display.getRunningScene()
	if curScene ~= nil then
		curScene:enterGame(nextStageId)
	end
end

function StageInfoLayer:returnStageSelectLayer()
	if self:isVisible() == false then
		return
	end

	self:closeLayer()

	local curScene = display.getRunningScene()
	if curScene ~= nil then
		curScene:returnStageSelectLayer()
		AudioManager.playBackgroundMusic(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.mainBGMusic), true)
	end
end

function StageInfoLayer:showRank()
	if self.stageId == nil then
		return
	end

	local curScene = display.getRunningScene()
	if curScene ~= nil then
		curScene:showTips(LangStringDefine.FUNC_NOT_OPEN)
	end
end

function StageInfoLayer:showVideo()
	if self.stageId == nil then
		return
	end

	local curScene = display.getRunningScene()
	if curScene ~= nil then
		curScene:showTips(LangStringDefine.FUNC_NOT_OPEN)
	end
end

function StageInfoLayer:openLayer()
	self:setVisible(true)
end


function StageInfoLayer:closeLayer()
	self:setVisible(false)
end

return StageInfoLayer
