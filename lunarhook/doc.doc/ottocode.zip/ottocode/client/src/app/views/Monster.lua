
local MonsterAI = import("app.views.MonsterAI")

local Monster = class("Monster", BaseCharacter)

function Monster:ctor(monsterId, parentMap, objId)
	Monster.super.ctor(self)
	
	self.objId = objId
	self.parentMapNode = parentMap
	self.faceR = false
	self.monsterId = monsterId

	self.aniTimeInternal = 0
	self.aniTime_record = 0
	self.aniIndex = 0
	self.nextDirection = GameDefine.GAME_CHARACTER_DIRECTION_TYPE.NONE
	self.curDirection = GameDefine.GAME_CHARACTER_DIRECTION_TYPE.NONE
	self.gravityRate = 1.0

	self.jumpState = GameDefine.CHARACTER_JUMP_STATE.BEGIN
	self.onGroundFlag = true
	self.haveReachMaxHeightFlag = false

	self.isAlive = true
	self.enable = true
	self.isFall = false
	self.fallTimeIndex = 0
	self.curMoveRate = 1.0

	self.needReviveFlag = false
	self.initPos = {x=0,y=0}

	self.AI = nil

	self:init()
end

function Monster:init()
	self.monsterTblInfo = ConfigManager.monsterTbl[tostring(self.monsterId)]
	if self.monsterTblInfo == nil then
		return
	end

	self.mainNode = display.newNode()
	if self.mainNode == nil then
		return
	end

	self.mainNode:setAnchorPoint(cc.p(0.5,0.5))
	self.mainNode:setPosition(cc.p(0,0))
	self:addChild(self.mainNode)


	--main pic
	local resStr = string.format("%s%.2d", self.monsterTblInfo.res, self.monsterTblInfo.animation.jump.begin.start)
	self.mainPic = display.newSprite(ResourceManager.ImageName(resStr))
	if self.mainPic ~= nil then
		self.mainPic:setAnchorPoint(cc.p(0.5,0))
		self.mainPic:setPosition(cc.p(0,-10))
		self.mainNode:addChild(self.mainPic, 1)

		self.warningIcon = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
		if self.warningIcon ~= nil then
			self.warningIcon:setAnchorPoint(cc.p(0.5,0.5))
			self.warningIcon:setPosition(cc.p(self.mainPic:getContentSize().width*0.75-self.warningIcon:getContentSize().width/2, 
											  self.mainPic:getContentSize().height*0.75-self.warningIcon:getContentSize().height/2))
			self.warningIcon:setVisible(false)
			self.mainPic:addChild(self.warningIcon)

			local warningAni = AnimationManager.getAniFromCacheByName("monster_find_target_warning")
			if warningAni ~= nil then
				self.warningIcon:runAction(cc.RepeatForever:create(cc.Animate:create(warningAni)))
			end
		end
	end

	--appear ani pic
	self.appearAniPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
	if self.appearAniPic ~= nil then
		self.appearAniPic:setAnchorPoint(cc.p(0.5,0))
		self.appearAniPic:setPosition(cc.p(0,-10))
		self.appearAniPic:setScaleX(self.mainPic:getScaleX())
		self.appearAniPic:setScaleY(self.mainPic:getScaleY())
		self.mainNode:addChild(self.appearAniPic, 2)
	end

	self.initShadowPosY = -6
	self.initShadowScale = 0.5
	self.mainShadowPic = display.newSprite(ResourceManager.ImageName(ResourceDef.MONSTER_SHADOW))
	if self.mainShadowPic ~= nil then
		self.mainShadowPic:setAnchorPoint(cc.p(0.5,0.5))
		self.mainShadowPic:setPosition(cc.p(0,self.initShadowPosY))
		self.mainShadowPic:setScale(self.initShadowScale)
		self.mainNode:addChild(self.mainShadowPic)
	end

	self.AI = MonsterAI.new(self, self.monsterTblInfo.aiID)

	self.difficultRate = GameConfig.PLAYER_JUMP_TIME_EACH_BLOCK[self.parentMapNode.difficultType]
	self.gravityRate = GameConfig.PLAYER_JUMP_TIME_EACH_BLOCK.normal / GameConfig.PLAYER_JUMP_TIME_EACH_BLOCK[self.parentMapNode.difficultType]
	
	self.aniTimeInternal = self.monsterTblInfo.animation.internal * self.difficultRate

	self:changeSpeed()
	self:resetMoveParams()
	self.jumpMoveUnitRecord = 0
	
	self.aniTime_record = self.aniTimeInternal

	if self.monsterTblInfo.animation.thunder.count > 0 and self.monsterTblInfo.animation.thunder.time > 0 then
		AnimationManager.setAniToCache(self.monsterTblInfo.res, self.monsterTblInfo.animation.thunder.start, self.monsterTblInfo.animation.thunder.count, self.monsterTblInfo.animation.thunder.time, "monster_thunder_" .. tostring(self.monsterId))
	end
	if self.monsterTblInfo.animation.victory.count > 0 and self.monsterTblInfo.animation.victory.time > 0 then
		AnimationManager.setAniToCache(self.monsterTblInfo.res, self.monsterTblInfo.animation.victory.start, self.monsterTblInfo.animation.victory.count, self.monsterTblInfo.animation.victory.time, "monster_victory_" .. tostring(self.monsterId))
	end
	if self.monsterTblInfo.animation.fall.count > 0 and self.monsterTblInfo.animation.fall.time > 0 then
		AnimationManager.setAniToCache(self.monsterTblInfo.res, self.monsterTblInfo.animation.fall.start, self.monsterTblInfo.animation.fall.count, self.monsterTblInfo.animation.fall.time, "monster_fall_" .. tostring(self.monsterId))
	end


	--thunder die effect pre construct
	self.thunderPic = cc.ProgressTimer:create(display.newSprite(ResourceManager.ImageName(ResourceDef.ITEM_EFFECT_LIGHTNING)))
	if self.thunderPic ~= nil then
		self.thunderPic:setType(cc.PROGRESS_TIMER_TYPE_BAR)
		self.thunderPic:setMidpoint(cc.p(0.5,1))
		self.thunderPic:setBarChangeRate(cc.p(0,1))
		self.thunderPic:setPercentage(0)
		self.thunderPic:setAnchorPoint(cc.p(0.5,0))
		self.thunderPic:setPosition(cc.p(0, self.mainPic:getContentSize().height/2+10))
		self.mainNode:addChild(self.thunderPic, 10)
	end

end

function Monster:changeFaceR(faceR)
	if faceR == nil then
		faceR = not self.faceR
	end

	if self.faceR == faceR then
		return
	end

	if faceR == true then
		self.mainPic:setScaleX(math.abs(self.mainPic:getScaleX())*(-1))
	else
		self.mainPic:setScaleX(math.abs(self.mainPic:getScaleX()))
	end

	self.faceR = faceR
end

function Monster:changeAnimationPic(res)
	if self.mainPic == nil or self.mainNode == nil or res == nil then
		return
	end

	local tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(res))
	if tpFrame ~= nil then
		self.mainPic:setSpriteFrame(tpFrame)
	end
end

function Monster:jump()
	if self.jumpState == GameDefine.CHARACTER_JUMP_STATE.RISE then
		local t = self.aniTimeInternal*self.jumpMoveUnitRecord
		local y = self.jumpInitSpeed*t - 0.5*self.gravity*t*t + self.initHeight
		local vy = self.jumpInitSpeed - self.gravity * t
		if vy <= 0 then
			self.mainNode:setPositionY(self.jumpMaxHeight)
			self.haveReachMaxHeightFlag = true
			self.gravity = GameDefine.GLOBAL_GRAVITY*self.gravityRate
		else
			self.mainNode:setPositionY(y)
		end

	elseif self.jumpState == GameDefine.CHARACTER_JUMP_STATE.FALL then
		local t = (self.aniTimeInternal*self.jumpMoveUnitRecord)
		local y = self.jumpMaxHeight - 0.5*self.gravity*t*t
		local vy = self.gravity * t
		if vy >= self.jumpMaxSpeed then
			self.mainNode:setPositionY(0)
			self.haveReachMaxHeightFlag = false
		else
			self.mainNode:setPositionY(y)
		end
	end

	self.onGroundFlag = (self.mainNode:getPositionY() <= 0)

	if self.mainShadowPic ~= nil then
		self.mainShadowPic:setPositionY(0-self.mainNode:getPositionY()+self.initShadowPosY)
		self.mainShadowPic:setScale(self.initShadowScale - (self.initShadowScale - 0.2) * (self.mainNode:getPositionY() / self.jumpMaxHeight))
	end

end

function Monster:fall()
	self.isAlive = false

	if self.mainPic == nil then
		self:die()
		return
	end

	-- local fallShowAni = AnimationManager.getAniFromCacheByName("monster_fall_" .. tostring(self.monsterId))
	-- if fallShowAni == nil then
	-- 	self:die()
	-- 	return
	-- end
	-- local fallShowAnimation = cc.Animate:create(fallShowAni)
	-- if fallShowAnimation == nil then
	-- 	self:die()
	-- 	return
	-- end

	self.mainPic:runAction(cc.Sequence:create(
		-- cc.DelayTime:create(0.2),
		-- fallShowAnimation,
		-- cc.DelayTime:create(0.2),
		cc.CallFunc:create(function()
			if self.mainNode ~= nil then
				self.mainNode:runAction(cc.Sequence:create(
					cc.MoveBy:create(0.5, cc.p(0, 0-display.height)),
					cc.CallFunc:create(function()
						self:die()
					end
					)
				))
			end
		end)
	))

end

function Monster:move()
	if self.curDirection == nil or self.curDirection == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.NONE then
		return
	end

	local dstMoveDis = {x=0, y=0}
	local moveMapVector = {x=0, y=0}
	if self.curDirection == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_TOP then
		dstMoveDis.x = 0 - self.moveDistanceEachTime.x
		dstMoveDis.y = self.moveDistanceEachTime.y
		moveMapVector.x = -1
		moveMapVector.y = 0
	elseif self.curDirection == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_BOTTOM then
		dstMoveDis.x = 0 - self.moveDistanceEachTime.x
		dstMoveDis.y = 0 - self.moveDistanceEachTime.y
		moveMapVector.x = 0
		moveMapVector.y = -1
	elseif self.curDirection == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_TOP then
		dstMoveDis.x = self.moveDistanceEachTime.x
		dstMoveDis.y = self.moveDistanceEachTime.y
		moveMapVector.x = 0
		moveMapVector.y = 1
	elseif self.curDirection == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_BOTTOM then
		dstMoveDis.x = self.moveDistanceEachTime.x
		dstMoveDis.y = 0 - self.moveDistanceEachTime.y
		moveMapVector.x = 1
		moveMapVector.y = 0
	end

	if self.jumpState == GameDefine.CHARACTER_JUMP_STATE.FALL and self.mainNode:getPositionY() == 0 then
		local xx = GameDefine.GROUND_BLOCK_WIDTH/2
		local yy = GameDefine.GROUND_BLOCK_HEIGHT/2
		local x = (self:getMapPosition().x-1)*xx + (self:getMapPosition().y-1)*xx
		local y = (self:getMapPosition().x-1)*(0-yy) + (self:getMapPosition().y-1)*yy + GameDefine.GROUND_OBJ_OFFSET_Y
		dstMoveDis.x = x - self:getPositionX()
		dstMoveDis.y = y - self:getPositionY()
	end

	self:setPositionX(self:getPositionX() + dstMoveDis.x)
	self:setPositionY(self:getPositionY() + dstMoveDis.y)

	if math.abs(self:getPositionX() - (self:getMapPosition().x + self:getMapPosition().y - 2) * GameDefine.GROUND_BLOCK_WIDTH/2) > GameDefine.GROUND_BLOCK_WIDTH/4 then
		self:setMapPosition({x=self:getMapPosition().x+moveMapVector.x, y=self:getMapPosition().y+moveMapVector.y})
		self:setLocalZOrder(GameDefine.MAX_GROUND_X+GameDefine.MAX_GROUND_Y+GameDefine.ZORDER_BASE_VALUE + self.parentMapNode:calcCharacterZorderAddValue(self:getMapPosition().x+moveMapVector.x, self:getMapPosition().y+moveMapVector.y))
	end
end

function Monster:getNextJumpPosition(dir)
	local pos = {x=self:getMapPosition().x, y=self:getMapPosition().y}
	if dir == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_TOP then
		pos.x = pos.x - 1
	elseif dir == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_BOTTOM then
		pos.y = pos.y - 1
	elseif dir == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_TOP then
		pos.y = pos.y + 1
	elseif dir == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_BOTTOM then
		pos.x = pos.x + 1
	end

	return pos
end

function Monster:checkChangeDirection()
	if self.AI ~= nil then
		if self.parentMapNode:checkFallByMapPosition(self:getNextJumpPosition(self.curDirection)) == true then
			if math.random(1,100)/100 < self.AI.avoidFallRate then
				self.AI:changeDirection(self.AI:calcNextDirection())
			end
		end
	end

	self.curDirection = self.nextDirection
	self:changeFaceR(self.nextDirection >= GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_TOP)

	if self:changeSpeed() == true then
		self:resetMoveParams()
	end
end

function Monster:changeSpeed()
	local rate = 1.0
	if self.AI ~= nil then
		if self.AI.foundTargetFlag ~= nil and self.AI.foundTargetFlag == true then
			rate = self.AI.AIAddMoveRate or 1.0
		end
	end

	if rate == 0 then
		rate = 1.0
	end

	if self.curMoveRate == rate then
		return false
	end

	self.curMoveRate = rate

	return true
end

function Monster:resetMoveParams()
	self.gravity = GameDefine.GLOBAL_GRAVITY*self.gravityRate
	self.jumpMaxHeight = GameDefine.MAX_JUMP_HEIGHT / (self.curMoveRate*self.curMoveRate)
	self.airTime = math.sqrt(2*self.jumpMaxHeight/self.gravity)
	self.jumpInitSpeed = self.gravity * self.airTime
	self.jumpMaxSpeed = math.abs(self.jumpInitSpeed)
	self.jumpMoveUnitCount = math.ceil(self.airTime / self.aniTimeInternal) * 2
	self.moveDistanceEachTime = {x=GameDefine.GROUND_BLOCK_WIDTH/2/self.jumpMoveUnitCount, y=GameDefine.GROUND_BLOCK_HEIGHT/2/self.jumpMoveUnitCount}
	self.initHeight = 0
end

function Monster:update(t)
	if self.enable == false then
		return
	end

	if self.isAlive == false then
		return
	end

	if self.AI ~= nil then
		self.AI:update(t)
	end

	if self.aniTimeInternal > 0 then
		self.aniTime_record = self.aniTime_record + t
		if self.aniTime_record >= self.aniTimeInternal then
			self.aniTime_record = self.aniTime_record - self.aniTimeInternal

			if self.jumpState == GameDefine.CHARACTER_JUMP_STATE.NO then
				--do nothing
			elseif self.jumpState == GameDefine.CHARACTER_JUMP_STATE.BEGIN then
				self.aniIndex = self.aniIndex + 1
				if self.aniIndex >= self.monsterTblInfo.animation.jump.begin.start and self.aniIndex < (self.monsterTblInfo.animation.jump.begin.start + self.monsterTblInfo.animation.jump.begin.count) then
					local resStr = string.format("%s%.2d", self.monsterTblInfo.res, self.aniIndex)
					self:changeAnimationPic(resStr)
				end

				if self.aniIndex == (self.monsterTblInfo.animation.jump.begin.start + self.monsterTblInfo.animation.jump.begin.count - 1) then
					self.jumpState = GameDefine.CHARACTER_JUMP_STATE.RISE
					self.jumpMoveUnitRecord = 0
				end

			elseif self.jumpState == GameDefine.CHARACTER_JUMP_STATE.RISE then
				self.jumpMoveUnitRecord = self.jumpMoveUnitRecord + 1
				self.aniIndex = self.aniIndex + 1
				if self.aniIndex > self.monsterTblInfo.animation.jump.rise.start + self.monsterTblInfo.animation.jump.rise.count then
					self.aniIndex = self.monsterTblInfo.animation.jump.rise.start + self.monsterTblInfo.animation.jump.rise.count
				end

				if self.aniIndex >= self.monsterTblInfo.animation.jump.rise.start and self.aniIndex < (self.monsterTblInfo.animation.jump.rise.start + self.monsterTblInfo.animation.jump.rise.count) then
					local resStr = string.format("%s%.2d", self.monsterTblInfo.res, self.aniIndex)
					self:changeAnimationPic(resStr)
				end
				
				self:jump()
				self:move()

				if self.haveReachMaxHeightFlag == true then
					self.aniIndex = self.aniIndex - 1
					self.jumpState = GameDefine.CHARACTER_JUMP_STATE.FALL
					self.jumpMoveUnitRecord = 0
				end

			elseif self.jumpState == GameDefine.CHARACTER_JUMP_STATE.FALL then
				self.jumpMoveUnitRecord = self.jumpMoveUnitRecord + 1
				self.aniIndex = self.aniIndex + 1
				if self.aniIndex > self.monsterTblInfo.animation.jump.fall.start + self.monsterTblInfo.animation.jump.fall.count then
					self.aniIndex = self.monsterTblInfo.animation.jump.fall.start + self.monsterTblInfo.animation.jump.fall.count
				end

				if self.aniIndex >= self.monsterTblInfo.animation.jump.fall.start and self.aniIndex < (self.monsterTblInfo.animation.jump.fall.start + self.monsterTblInfo.animation.jump.fall.count) then
					local resStr = string.format("%s%.2d", self.monsterTblInfo.res, self.aniIndex)
					self:changeAnimationPic(resStr)
				end

				self:jump()
				self:move()

				if self.onGroundFlag == true then
					self.aniIndex = self.aniIndex - 1
					self.jumpState = GameDefine.CHARACTER_JUMP_STATE.FALLGROUND
					self.jumpMoveUnitRecord = 0
				end

			elseif self.jumpState == GameDefine.CHARACTER_JUMP_STATE.FALLGROUND then
				self.aniIndex = self.aniIndex + 1
				if self.aniIndex >= self.monsterTblInfo.animation.jump.fallground.start and self.aniIndex < (self.monsterTblInfo.animation.jump.fallground.start + self.monsterTblInfo.animation.jump.fallground.count) then
					local resStr = string.format("%s%.2d", self.monsterTblInfo.res, self.aniIndex)
					self:changeAnimationPic(resStr)
				end

				if self.aniIndex == (self.monsterTblInfo.animation.jump.fallground.start + self.monsterTblInfo.animation.jump.fallground.count - 1) then
					if self.parentMapNode ~= nil then
						if self.parentMapNode:checkFall(self) == true then
							if self.mainShadowPic ~= nil then
								self.mainShadowPic:setVisible(false)
							end
							self:fall()
							return
						end
					end

					self:checkChangeDirection()

					self.jumpState = GameDefine.CHARACTER_JUMP_STATE.BEGIN
					self.aniIndex = 0
					self.jumpMoveUnitCount = math.ceil(self.airTime * 2 / self.aniTimeInternal)
					self.jumpMoveUnitRecord = 0
					self.moveDistanceEachTime = {x=GameDefine.GROUND_BLOCK_WIDTH/2/self.jumpMoveUnitCount, y=GameDefine.GROUND_BLOCK_HEIGHT/2/self.jumpMoveUnitCount}
				end

			elseif self.jumpState == GameDefine.CHARACTER_JUMP_STATE.MJ then
				--do nothing
			end

		end
	elseif self.aniTime_record ~= 0 then
		self.aniTime_record = 0
	end
end

function Monster:foundPlayer()
	if self.warningIcon ~= nil then
		self.warningIcon:setVisible(true)
	end
end

function Monster:missPlayer()
	if self.warningIcon ~= nil then
		self.warningIcon:setVisible(false)
	end
end

function Monster:win()
	if self.mainPic == nil then
		return
	end

	local winAni = AnimationManager.getAniFromCacheByName("monster_victory_" .. tostring(self.monsterId))
	if winAni == nil then
		return
	end
	local winAnimation = cc.Animate:create(winAni)
	if winAnimation == nil then
		return
	end

	self.mainPic:runAction(winAnimation)

end

function Monster:appear()
	if self.appearAniPic == nil then
		return
	end

	local disappearAni = AnimationManager.getAniFromCacheByName("disappear_cover_ani")
	if disappearAni ~= nil then
		self.appearAniPic:runAction(
				cc.Sequence:create(cc.Animate:create(disappearAni),
									cc.CallFunc:create(function()
										local tpPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
										if tpPic ~= nil then
											self.appearAniPic:setSpriteFrame(tpPic:getSpriteFrame())
										end
									end)
				)
			)
	end
end

function Monster:beKilled(timeIdx)
	self.isAlive = false
	if timeIdx == nil then
		timeIdx = 0
	end

	if self.mainPic == nil then
		self:die()
		return
	end

	local beThunderAni = AnimationManager.getAniFromCacheByName("monster_thunder_ani")--AnimationManager.getAniFromCacheByName("monster_thunder_" .. tostring(self.monsterId)) 
	if beThunderAni == nil then
		self:die()
		return
	end
	local beThunderAnimation = cc.Animate:create(beThunderAni)
	if beThunderAnimation == nil then
		self:die()
		return
	end
	beThunderAnimation:retain()

	local delay_time = timeIdx * 0.3
	self.mainPic:runAction(cc.Sequence:create(
		cc.DelayTime:create(delay_time),
		cc.CallFunc:create(function()
			if self.thunderPic ~= nil then
				self.thunderPic:runAction(cc.ProgressTo:create(0.2, 100))
			end
		end),
		cc.DelayTime:create(0.2),
		beThunderAnimation:clone(),
		cc.DelayTime:create(0.1),
		cc.CallFunc:create(function()
			beThunderAnimation:release()
			self:die(false)
		end)
		)
	)

end

function Monster:die(playEffectFlag)
	if playEffectFlag == nil then
		playEffectFlag = true
	end

	if self.enable == false then
		return
	end
	self.enable = false

	if self.thunderPic ~= nil then
		self.thunderPic:stopAllActions()
		self.thunderPic:removeFromParent(true)
	end

	local haveAni = false
	if playEffectFlag == true then
		if self.mainPic ~= nil then
			self.mainPic:stopAllActions()
			local disappearAni = AnimationManager.getAniFromCacheByName("disappear_cover_ani")
			if disappearAni ~= nil then
				local disappearAnimation = cc.Animate:create(disappearAni)
				if disappearAnimation ~= nil then
					haveAni = true
					self.mainPic:runAction(cc.Sequence:create(disappearAnimation, cc.CallFunc:create(function()
						self:stopAllActions()
						self.parentMapNode.monsterList[self.objId] = nil
						if self.needReviveFlag == true then
							self.parentMapNode.gameAI:monterDie(self.monsterId, self.initPos)
						end
						self:removeFromParent(true)
					end)))
				end
			end
		end
	end

	if haveAni == false then
		self:stopAllActions()
		self.parentMapNode.monsterList[self.objId] = nil
		if self.needReviveFlag == true then
			self.parentMapNode.gameAI:monterDie(self.monsterId, self.initPos)
		end
		self:removeFromParent(true)
	end
end

return Monster
