
local MonsterAI = class("MonsterAI")

function MonsterAI:ctor(parent, aiId)
	self.parent = parent

	self.aiID = aiId or GameConfig.DEFAULT_MONSTER_AI_ID
	self.ai_enabled = false
	self:init()
end

function MonsterAI:init()
	self.time_record = 0
	self.missTime_record = 0
	self.foundTargetFlag = false
	self.aiData = ConfigManager.monsterAITbl[tostring(self.aiID)]
	if self.aiData == nil then
		return
	end

	self.tick_internal = 0
	self.AIAddMoveRate = self.aiData.followSpeedRate
	self.miss2findDeltTime = self.aiData.miss2findDeltTime
	self.avoidFallRate = self.aiData.avoidFallRate

	self.ai_enabled = true
end

function MonsterAI:update(t)
	if self.ai_enabled == false then
		return
	end

	if self.tick_internal > 0 then
		self.time_record = self.time_record + t
	end

	if self.time_record >= self.tick_internal then
		self.time_record = self.time_record - self.tick_internal

		local ret = self:findPlayer()
		if self.foundTargetFlag == false then
			if ret == true then
				self.foundTargetFlag = true
				self.missTime_record = 0
				self.tick_internal = self.aiData.findTargetTickTime

				if self.parent ~= nil and self.parent.foundPlayer ~= nil then
					self.parent:foundPlayer()
				end
			end
		else
			if ret == false then
				self.foundTargetFlag = false
				self.missTime_record = 0
				self.time_record = 0
				self.tick_internal = self.miss2findDeltTime

				if self.parent ~= nil and self.parent.missPlayer ~= nil then
					self.parent:missPlayer()
				end
			end
		end

		self:changeDirection(self:calcNextDirection())
	end
	
	if self.foundTargetFlag == true then
		self.missTime_record = self.missTime_record + t
		if self.missTime_record >= self.aiData.missTargetTotalTime then
			self.foundTargetFlag = false
			self.missTime_record = 0
			self.time_record = 0
			self.tick_internal = self.miss2findDeltTime

			if self.parent ~= nil and self.parent.missPlayer ~= nil then
				self.parent:missPlayer()
			end
		end
	end

end

function MonsterAI:findPlayer()
	local viewport = self.aiData.findTargetViewport
	if self.foundTargetFlag == true then
		viewport = self.aiData.missTargetViewport
	end

	if viewport <= 0 then
		return false
	end

	local playerPos = self.parent.parentMapNode.mainPlayer:getMapPosition()
	local monsterPos = self.parent:getMapPosition()
	local monsterDir = self.parent.curDirection

	if monsterDir == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_TOP then
		if playerPos.x > monsterPos.x or playerPos.x < monsterPos.x - viewport then
			return false
		else
			local disX = monsterPos.x - playerPos.x
			if  (playerPos.y >= monsterPos.y - (viewport - disX)) and
				(playerPos.y <= monsterPos.y + (viewport - disX)) then
				return true
			else
				return false
			end
		end
	elseif monsterDir == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_BOTTOM then
		if playerPos.y > monsterPos.y or playerPos.y < monsterPos.y - viewport then
			return false
		else
			local disY = monsterPos.y - playerPos.y
			if  (playerPos.x >= monsterPos.x - (viewport - disY)) and
				(playerPos.x <= monsterPos.x + (viewport - disY)) then
				return true
			else
				return false
			end
		end
	elseif monsterDir == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_TOP then
		if playerPos.y < monsterPos.y or playerPos.y > monsterPos.y + viewport then
			return false
		else
			local disY = playerPos.y - monsterPos.y
			if  (playerPos.y >= monsterPos.y - (viewport - disY)) and
				(playerPos.y <= monsterPos.y + (viewport - disY)) then
				return true
			else
				return false
			end
		end
	elseif monsterDir == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_BOTTOM then
		if playerPos.x < monsterPos.x or playerPos.x > monsterPos.x + viewport then
			return false
		else
			local disX = playerPos.x - monsterPos.x
			if  (playerPos.y >= monsterPos.y - (viewport - disX)) and
				(playerPos.y <= monsterPos.y + (viewport - disX)) then
				return true
			else
				return false
			end
		end
	end

	return false
end

function MonsterAI:calcNextDirection()

	if self.foundTargetFlag == false then
		local pool = {}
		for k,v in pairs(GameDefine.GAME_CHARACTER_DIRECTION_TYPE) do
			if v > 0 then
				if self.parent.parentMapNode:checkFallByMapPosition(self.parent:getNextJumpPosition(v)) == false then
					table.insert(pool, v)
				end
			end
		end

		self.time_record = 0
		return pool[math.random(#pool)]
	else
		local playerPos = self.parent.parentMapNode.mainPlayer:getMapPosition()
		local monsterPos = self.parent:getMapPosition()
		local disX = playerPos.x - monsterPos.x
		local disY = playerPos.y - monsterPos.y
		if disX == 0 and disY == 0 then
			return nil
		else
			if math.abs(disX) == math.abs(disY) then
				if math.random(100) >= 50 then
					disX = disX + 0.5
				else
					disY = disY + 0.5
				end
			end

			if math.abs(disX) < math.abs(disY) then
				if disY > 0 then
					return GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_TOP
				else
					return GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_BOTTOM
				end
			elseif math.abs(disX) > math.abs(disY) then
				if disX > 0 then
					return GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_BOTTOM
				else
					return GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_TOP
				end
			end
		end

	end

	return nil
end

function MonsterAI:changeDirection(targetDirection)
	if self.parent == nil or targetDirection == nil then
		return
	end

	if targetDirection == self.parent.curDirection then
		return
	end

	self.parent.nextDirection = targetDirection
end

return MonsterAI
