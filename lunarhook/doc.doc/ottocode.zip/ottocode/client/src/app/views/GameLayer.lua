
local ControlNode = import("app.views.ControlNode")
local MapNode = import("app.views.MapNode")
local GameControlButton = import("app.views.GameControlButton")

local GameLayer = class("GameLayer", BaseLayer)

local GAME_LAYER_ZORDER_DEFINE = {
	BG = 1,
	MAP = 2,
	CONTROL = 3,
	UI_CONTENT = 4,
	UI_CONTENT_POP = 5,
	TIPS = 6,
	NOTICE = 7,
}

function GameLayer:ctor()
    GameLayer.super.ctor( self )

    self.stageId = 0
    self.isShopMap = false
    self.isTest = false
    self.steps = 0
    self.hasStartFlag = false
    self.gameEndFlag = false
    self.gameResultPreparedOKFlag = false
    self.gameEndPlayActionEndFlag = false

    self.commonJumpSoundEffectIndex = 1
    self.playingClockSoundEffectId = nil
    self.startTimeStamp = nil
    self.gameUseTime = 0

    self:initUI()
end

function GameLayer:initUI()

	--pos nodes
	self.nodeLeftBottom = display.newNode()
	if self.nodeLeftBottom == nil then
		return
	end

	self.nodeLeftBottom:setAnchorPoint(cc.p(0.5,0.5))
	self.nodeLeftBottom:setPosition(cc.p(0, 0))
	self:addChild(self.nodeLeftBottom)


	--bg
	self.bgNode = display.newNode()
	if self.bgNode ~= nil then
		self.bgNode:setAnchorPoint(cc.p(0,0))
		self.bgNode:setPosition(cc.p(0, 0))
		self:addChild(self.bgNode, GAME_LAYER_ZORDER_DEFINE.BG)

		-------bgcolorlayer
		local bgLayerSize = {width=display.width, height=display.height}
		local bgColorLayer = cc.LayerColor:create(cc.c4b(240, 240, 240, 255), bgLayerSize.width, bgLayerSize.height)
		if bgColorLayer ~= nil then
			bgColorLayer:setAnchorPoint(cc.p(0, 0))
			bgColorLayer:setPosition(cc.p(0, 0))
			self.bgNode:addChild(bgColorLayer, 10)
		end
		self.bgColorLayerFail = cc.LayerColor:create(cc.c4b(120, 50, 68, 255), bgLayerSize.width, bgLayerSize.height) --  29, 27, 28
		if self.bgColorLayerFail ~= nil then
			self.bgColorLayerFail:setAnchorPoint(cc.p(0, 0))
			self.bgColorLayerFail:setPosition(cc.p(0, 0))
			self.bgColorLayerFail:setOpacity(0)
			self.bgNode:addChild(self.bgColorLayerFail, 11)
		end

		self.thunderBg = cc.LayerColor:create(cc.c4b(0, 0, 0, 255), bgLayerSize.width, bgLayerSize.height)
		if self.thunderBg ~= nil then
			self.thunderBg:setAnchorPoint(cc.p(0, 0))
			self.thunderBg:setPosition(cc.p(0, 0))
			self.thunderBg:setVisible(false)
			self.bgNode:addChild(self.thunderBg, 11)
		end
		self.thunderEffectPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
		if self.thunderEffectPic ~= nil then
			self.thunderEffectPic:setAnchorPoint(cc.p(0.5, 1))
			self.thunderEffectPic:setPosition(cc.p(display.cx, display.height))
			self.thunderEffectPic:setScale(2)
			self.bgNode:addChild(self.thunderEffectPic, 12)
		end

		-------transparent bg pics
		local transparentBgPic1 = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.transparentBg1)))
		if transparentBgPic1 ~= nil then
			transparentBgPic1:setAnchorPoint(cc.p(0, 0))
			local scaleRate = display.height/transparentBgPic1:getContentSize().height
			transparentBgPic1:setScale(scaleRate)
			transparentBgPic1:setPosition(cc.p(0, 0))
			transparentBgPic1:setOpacity(150)
			self.bgNode:addChild(transparentBgPic1, 15)
		end
		local transparentBgPic2 = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.transparentBg2)))
		if transparentBgPic2 ~= nil then
			transparentBgPic2:setAnchorPoint(cc.p(0.5, 0))
			local scaleRate = display.height/transparentBgPic2:getContentSize().height
			transparentBgPic2:setScale(scaleRate)
			transparentBgPic2:setPosition(cc.p(display.width*1.25, 0))
			transparentBgPic2:setOpacity(150)
			self.bgNode:addChild(transparentBgPic2, 15)
		end

		-------clouds
		self.cloudNode = GameTools.makeMoveClouds(0-display.cx, display.cy+150, display.width*2, display.cy-100)
		if self.cloudNode ~= nil then
			self.bgNode:addChild(self.cloudNode, 17)
		end

		-------round small trees
		local roundSmallTreePosList = {
			{x=-30, y=80, zOrder=18,resIdx=2,scale=0.9},
			{x=186, y=58, zOrder=18,resIdx=1,scale=0.8},
			{x=display.cx+36, y=75, zOrder=17,resIdx=2,scale=0.8},
			{x=display.cx+90, y=67, zOrder=18,resIdx=1,scale=0.8},
			{x=display.width-96, y=55, zOrder=18,resIdx=3,scale=0.8},
			{x=display.width-64, y=100, zOrder=17,resIdx=2,scale=0.7},
			{x=display.width-35, y=75, zOrder=17,resIdx=1,scale=0.7},
		}
		for i=1, #roundSmallTreePosList do
			local roundTreePic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.roundSmallTree[roundSmallTreePosList[i].resIdx])))
			if roundTreePic ~= nil then
				roundTreePic:setAnchorPoint(cc.p(0.5, 0.5))
				roundTreePic:setPosition(cc.p(roundSmallTreePosList[i].x, roundSmallTreePosList[i].y))
				roundTreePic:setScale(roundSmallTreePosList[i].scale)
				self.bgNode:addChild(roundTreePic, roundSmallTreePosList[i].zOrder)
			end
		end

		self:makeFloatFlowers(self.bgNode, 20)
	end


	--header info
	self.headerInfoNode = display.newNode()
	if self.headerInfoNode ~= nil then
		self.headerInfoNode:setAnchorPoint(cc.p(0.5,0.5))
		self.headerInfoNode:setPosition(cc.p(display.cx, display.height-75))
		self:addChild(self.headerInfoNode, GAME_LAYER_ZORDER_DEFINE.UI_CONTENT)

		local headerInfoBgPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.GAME_TITLE_BG_PANEL)))
		if headerInfoBgPic ~= nil then
			headerInfoBgPic:setAnchorPoint(cc.p(0.5, 0.5))
			headerInfoBgPic:setPosition(cc.p(0, 0))
			headerInfoBgPic:setScaleX(display.width*0.85/headerInfoBgPic:getContentSize().width)
			headerInfoBgPic:setScaleY(0.85)
			self.headerInfoNode:addChild(headerInfoBgPic, 1)
		end

		--step info
		local stepTitleIcon = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.GAME_TITLE_ICON_STEPS)))
		if stepTitleIcon ~= nil then
			stepTitleIcon:setAnchorPoint(cc.p(0.5, 0.5))
			stepTitleIcon:setPosition(cc.p(-160, 0))
			self.headerInfoNode:addChild(stepTitleIcon, 2)
		end
		self.stepLabel = display.newTTFLabel({
	        text = tostring(self.steps),
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 24,
	        align = cc.TEXT_ALIGNMENT_CENTER
	    })
	    if self.stepLabel ~= nil then
	        self.stepLabel:setAnchorPoint(cc.p(0,0.5))
	        self.stepLabel:setPosition(cc.p(-125, 0))
	        self.headerInfoNode:addChild(self.stepLabel, 2)
	    end

	    --stage info
	    local stageTitleIcon = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.GAME_TITLE_ICON_STAGE)))
		if stageTitleIcon ~= nil then
			stageTitleIcon:setAnchorPoint(cc.p(0.5, 0.5))
			stageTitleIcon:setPosition(cc.p(115, 0))
			self.headerInfoNode:addChild(stageTitleIcon, 2)
		end
		self.stageLabel = display.newTTFLabel({
	        text = "",
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 24,
	        align = cc.TEXT_ALIGNMENT_CENTER
	    })
	    if self.stageLabel ~= nil then
	        self.stageLabel:setAnchorPoint(cc.p(0,0.5))
	        self.stageLabel:setPosition(cc.p(145, 0))
	        self.headerInfoNode:addChild(self.stageLabel, 2)
	    end
	end

	self.groundNode = display.newNode()
	if self.groundNode ~= nil then
		self.groundNode:setAnchorPoint(cc.p(0,0))
		self.groundNode:setPosition(cc.p(0, 0))
		self:addChild(self.groundNode, GAME_LAYER_ZORDER_DEFINE.UI_CONTENT)

		-------ground
		local tmpPosX = 0
		for i=3, 1, -1 do
			local ground = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.groundResList[i])))
			if ground ~= nil then
				ground:setAnchorPoint(cc.p(0, 0))
				ground:setPosition(cc.p(tmpPosX, 0))
				self.groundNode:addChild(ground, 10)
				tmpPosX = tmpPosX + ground:getContentSize().width - 2
			end
		end

		--pause button
		self.pauseNode = display.newNode()
		if self.pauseNode ~= nil then
			self.pauseNode:setAnchorPoint(cc.p(0.5,0.5))
			self.pauseNode:setPosition(cc.p(display.width-80, 38))
			self.groundNode:addChild(self.pauseNode, 5)

			local pauseBtnGanPic = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.BUTTON_BG_PANEL_CONNECT_POLE_LIST[1])))
			if pauseBtnGanPic ~= nil then
				pauseBtnGanPic:setAnchorPoint(cc.p(1, 0))
				pauseBtnGanPic:setPosition(cc.p(0, 0))
				self.pauseNode:addChild(pauseBtnGanPic, 1)
			end

			local pauseButton = GameControlButton.new({
		        btnBg = ResourceDef.BUTTON_BG_PANEL_LIST[1].res,
			    dstSize = {width=ResourceDef.BUTTON_BG_PANEL_LIST[1].size.width, height=ResourceDef.BUTTON_BG_PANEL_LIST[1].size.height},
			    -- pressedScale = 1,
			    buttonFont = LangStringDefine.RETURN_LABEL,
		        buttonFontSize = 30,
		        buttonFontColor = cc.c3b(255,255,255),
		        callback = function ()
		        	if self.gameEndFlag == true then
		        		return 
		        	end
		        	if self.startTimeStamp == nil then
		        		return
		        	end

		        	AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.clickButtonEffect_big), false)
		        	self:pauseGame()
		        end
		    })
		    if pauseButton ~= nil then
				pauseButton:setAnchorPoint(cc.p(0.5, 0.5))
				pauseButton:setPosition(cc.p(-35, 88))
			    self.pauseNode:addChild(pauseButton, 2)
			end
		end
	end

	--control
	self.controlNode = ControlNode.new(self)
	if self.controlNode ~= nil then
		self.controlNode:setAnchorPoint(cc.p(0.5,0.5))
		self.controlNode:setPosition(cc.p(display.cx, 250))
		self:addChild(self.controlNode, GAME_LAYER_ZORDER_DEFINE.CONTROL)
	end

	--map
	self.mapNode = MapNode.new(self)
	if self.mapNode ~= nil then
		self.mapNode:setAnchorPoint(cc.p(0.5,0.5))
		self.mapNode:setPosition(cc.p(display.cx, display.cy))
		self:addChild(self.mapNode, GAME_LAYER_ZORDER_DEFINE.MAP)
	end

	--pause
	self.pauseLayer = import("app.views.PauseLayer").new(self)
	if self.pauseLayer ~= nil then
		self.pauseLayer:setPosition(cc.p(0, 0))
		self.pauseLayer:closeLayer()
		self:addChild(self.pauseLayer, GAME_LAYER_ZORDER_DEFINE.UI_CONTENT_POP)
	end

end

function GameLayer:playStartAction(cb)
	if self.startActionMainLabel == nil then
		self.startActionMainLabel = display.newTTFLabel({
	        text = "",
	        font = ResourceDef.FONT_GAME_MAIN,
	        size = 56,
	        align = cc.TEXT_ALIGNMENT_CENTER
	    })
	    if self.startActionMainLabel ~= nil then
	        self.startActionMainLabel:setAnchorPoint(cc.p(0.5,0.5))
	        self.startActionMainLabel:setPosition(cc.p(display.cx, display.cy))
	        self:addChild(self.startActionMainLabel, GAME_LAYER_ZORDER_DEFINE.TIPS)
	    else
	    	return
	    end
	end

	local actionSeq = cc.Sequence:create(cc.DelayTime:create(0.5))
	local tmpNumber = 3
	for i=tmpNumber, 0, -1 do
		actionSeq = cc.Sequence:create(actionSeq,
			cc.CallFunc:create(function()
				if i > 0 then
					self.startActionMainLabel:setString(tostring(i))
					AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.gamePrepareShow[i]), false)
				elseif i == 0 then
				-- 	self.startActionMainLabel:setString("Ready")
				-- elseif i == -1 then
					self.startActionMainLabel:setString("Go")
					AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.gameReadyGo), false)
				end

				self.startActionMainLabel:setScale(2)
				self.startActionMainLabel:setVisible(true)
			end),
			cc.ScaleTo:create(0.3, 1),
			cc.DelayTime:create(0.8),
			cc.CallFunc:create(function()
				self.startActionMainLabel:setVisible(false)
			end)
		)
	end

	if cb ~= nil and type(cb) == "function" then
		actionSeq = cc.Sequence:create(actionSeq,
			cc.CallFunc:create(function()
				cb()
			end)
		)
	end

	self.startActionMainLabel:stopAllActions()
	self.startActionMainLabel:setVisible(false)
	self.startActionMainLabel:runAction(actionSeq)

end


function GameLayer:addStep()
	self.steps = self.steps + 1
	self:refreshSteps()
end

function GameLayer:refreshSteps()
	if self.stepLabel ~= nil then
		self.stepLabel:setString(self.steps)
	end
end

function GameLayer:update(t)
	if self.hasStartFlag == false then
		self.hasStartFlag = true
		self:playStartAction(function()
			self.startTimeStamp = os.time()
			self:onEvent({name=GameDefine.GAME_CONTROL_EVENT_TYPE.LEFT_BOTTOM}, true)
		end)
	end

	if self.mapNode ~= nil and self.mapNode.update ~= nil then
		self.mapNode:update(t)
	end

	if self.gameEndFlag == true then
		if self.gameEndPlayActionEndFlag == true then
			if self.gameResultPreparedOKFlag == true then
				self:showGameResult(self.gameEndResult)
			end
		end
	end

end

function GameLayer:prepareGame(stageId)
	if stageId == nil then
		return
	end

	self.stageId = stageId

	if self.mapNode ~= nil then
		self.mapNode:initWithStageID(stageId, self.isShopMap)
	end

	if self.stageLabel ~= nil then
		if self.isShopMap == false then
			self.stageLabel:setString(tostring(math.floor(self.stageId/100)) .. "-" .. tostring(math.fmod(self.stageId, 100)))
		else
			self.stageLabel:setString("")
		end
	end

end

function GameLayer:prepareGameWithData(mapData)
	if self.mapNode ~= nil then
		self.mapNode:initWithStageID(0, false, true, mapData)
	end

	if self.stageLabel ~= nil then
		self.stageLabel:setString(LangStringDefine.PLAYER_MADE_MAP)
	end
end

function GameLayer:GameEnd(isVictory)
	local curScene = display.getRunningScene()
	if curScene == nil then
		return 
	end
	self.gameEndFlag = true

	--hide cloud
	if self.cloudNode ~= nil then
		self.cloudNode:setVisible(false)
	end

	--hide return button
	if self.pauseNode ~= nil then
		self.pauseNode:runAction(cc.RotateBy:create(0.1, -180))
	end

	self:playGameEndAction(isVictory)
	if isVictory == true then
		AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.gameWinEffect_bg), false)
		AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.gameWinEffect_flower), false)
	else
		AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.gameFailedEffect), false)
	end

	local nowTime = os.time()
	if self.startTimeStamp ~= nil then
		self.gameUseTime = nowTime - self.startTimeStamp
	end

	local isNeedRefresh = false
	local isNewRecord = false

	if self.isTest == true then
		self.gameEndResult = {
			isWin = isVictory,
			steps = self.steps,
			isNewRecord = false,
			rankInfo = {},
			useTime = self.gameUseTime,
		}

		if self.GameResultLayer == nil then
			self.GameResultLayer = import("app.views.GameResult").new()
		    if self.GameResultLayer ~= nil then
		    	self.GameResultLayer:closeLayer()
		        self:addChild(self.GameResultLayer, GAME_LAYER_ZORDER_DEFINE.UI_CONTENT_POP)
		    end
		end
		self.gameResultPreparedOKFlag = true
		return
	end

	if isVictory == true then
		if self.stageId ~= nil and self.stageId > 0 then
			if GameConfig.ISONLINE == true then

				local nextStageId = nil
				if self.isShopMap == false then
					local stageTblInfo = ConfigManager.stageTbl[tostring(self.stageId)]
					if stageTblInfo ~= nil then
						nextStageId = stageTblInfo.nextStageId
					end
				end

				local params = {
					playerId = UserDataManager.PLAYER_UID,
					stageId = self.stageId,
					step = self.steps, 
					record_time = nowTime,
					nextStageId = nextStageId,
					use_time = self.gameUseTime,
				}
				local ret, resp = GameNetWorker.createHttpRequestWithPostParam(GameConfig.SERVER_ADDRESS .. GameConfig.REQUEST_URL.stagecomplete, params, false)
				-- dump(resp)
				if ret == true then
					local respInfo = json.decode(resp)
					if respInfo ~= nil and respInfo.stageInfo ~= nil then
						if respInfo.errorId ~= nil then
							if curScene ~= nil and curScene.showTips ~= nil then
								curScene:showTips(respInfo.errorMsg)
							end
						else
							isNewRecord = respInfo.needUpdateFlag
							if isNewRecord == true then
								UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(self.stageId)] = respInfo.stageInfo
								isNeedRefresh = true
							end

							if respInfo.nextStageId ~= nil and respInfo.nextStageInfo ~= nil then
								isNeedRefresh = true
								UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(respInfo.nextStageId)] = respInfo.nextStageInfo
							end

							self:requestForRank(isVictory, isNeedRefresh)
						end
					else
						if curScene ~= nil and curScene.showTips ~= nil then
							curScene:showTips("resp fromat error.")
						end
					end
				else
					if curScene ~= nil and curScene.showTips ~= nil then
						curScene:showTips("server fault.")
					end
				end
			end
		end
	else
		self:requestForRank(isVictory, isNeedRefresh)
	end

end

function GameLayer:requestForRank(isVictory, isNeedRefresh)
	--request for rank
    local params = {id = self.stageId}
    local ret, resp = GameNetWorker.createHttpRequestWithPostParam(GameConfig.SERVER_ADDRESS .. GameConfig.REQUEST_URL.rank, params, false)
    if ret == true then
        local respInfo = json.decode(resp)
        if respInfo ~= nil then
            -- dump(respInfo)
            if respInfo.errorId ~= nil then
                display.getRunningScene():showTips(respInfo.errorMsg)
            else
                UserDataManager.RANK_LIST[tostring(self.stageId)] = {
                    myRank = 0,
                    rankInfo = respInfo,
                    lastReqTime = os.time()
                }

                for i=1, #respInfo do
                    if tostring(respInfo[i].playerId) == tostring(UserDataManager.PLAYER_UID) then
                        UserDataManager.RANK_LIST[tostring(self.stageId)].myRank = i
                        break
                    end
                end

                local rankInfo = {
		    		myRank = "",
					myRecordTime = "",
					myBestStep = "",
					stageRank = {}
		    	}

		    	if UserDataManager.RANK_LIST[tostring(self.stageId)] ~= nil then
					rankInfo.myRank =UserDataManager.RANK_LIST[tostring(self.stageId)].myRank

					for i=1, 3 do
						rankInfo.stageRank[i] = {}
			    		if UserDataManager.RANK_LIST[tostring(self.stageId)].rankInfo[i] ~= nil then
			    			rankInfo.stageRank[i].name = UserDataManager.RANK_LIST[tostring(self.stageId)].rankInfo[i].playerId
			    			rankInfo.stageRank[i].steps = UserDataManager.RANK_LIST[tostring(self.stageId)].rankInfo[i].steps
			    		else
			    			rankInfo.stageRank[i].name = ""
			    			rankInfo.stageRank[i].steps = ""
			    		end
			    	end
				end
				if UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(self.stageId)] ~= nil then
					rankInfo.myRecordTime = UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(self.stageId)].record_use_time
					rankInfo.myBestStep = UserDataManager.PLAYER_STAGES_STATE_LIST[tostring(self.stageId)].step
				end

                self.gameEndResult = {
					isWin = isVictory,
					steps = self.steps,
					isNewRecord = isNeedRefresh,
					rankInfo = rankInfo,
					useTime = self.gameUseTime,
				}

				if self.GameResultLayer == nil then
					self.GameResultLayer = import("app.views.GameResult").new()
				    if self.GameResultLayer ~= nil then
				    	self.GameResultLayer:closeLayer()
				        self:addChild(self.GameResultLayer, GAME_LAYER_ZORDER_DEFINE.UI_CONTENT_POP)
				    end
				end

				self:refreshStageView()
				
				self.gameResultPreparedOKFlag = true
            end
        end
    end

end

function GameLayer:refreshStageView()
	if self.isShopMap == true or self.isTest == true then
		return
	end

	local curScene = display.getRunningScene()
	if curScene ~= nil and curScene.StageSelectLayer ~= nil then
		if curScene.StageSelectLayer.worldLayerList ~= nil then
			local curWorldId = math.floor(self.stageId/100)
			if curScene.StageSelectLayer.worldLayerList[curWorldId] ~= nil then
				if curScene.StageSelectLayer.worldLayerList[curWorldId].stageListView ~= nil then
					curScene.StageSelectLayer.worldLayerList[curWorldId].stageListView:refreshView()
				end
			end
		end
	end
end

function GameLayer:playSceneThunderEffect()
	if self.thunderBg == nil or self.thunderEffectPic == nil then
		return
	end

	local thunderAnimation = nil
	local thunderAnimation = AnimationManager.getAniFromCacheByName("thunder_scene_effect")
	if thunderAnimation == nil then
		AnimationManager.setAniToCache(ResourceDef.THUNDER_ANIMATION_RES_PARAM.res, 
						   ResourceDef.THUNDER_ANIMATION_RES_PARAM.start, 
						   ResourceDef.THUNDER_ANIMATION_RES_PARAM.count, 
						   ResourceDef.THUNDER_ANIMATION_RES_PARAM.time, 
						   "thunder_scene_effect")
		thunderAnimation = AnimationManager.getAniFromCacheByName("thunder_scene_effect")
	end
	if thunderAnimation == nil then
		return
	end
	thunderAnimation = cc.Animate:create(thunderAnimation)
	thunderAnimation:retain()

	self.thunderEffectPic:runAction(cc.Sequence:create(
		cc.CallFunc:create(function()
			self.thunderBg:setVisible(true)
		end),
		thunderAnimation:clone(),
		thunderAnimation:clone(),
		cc.CallFunc:create(function()
			local tpPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
			if tpPic ~= nil then
				self.thunderEffectPic:setSpriteFrame(tpPic:getSpriteFrame())
			end
		end),
		cc.DelayTime:create(1),
		cc.CallFunc:create(function()
			self.thunderBg:setVisible(false)
		end)
	))
end

function GameLayer:playGameEndAction(isVictory)
	if self.controlNode ~= nil then
		self.controlNode:setVisible(false)
	end

	if self.endEffectNode ~= nil then
		self.gameEndPlayActionEndFlag = true
		return
	end
	self.endEffectNode = display.newNode()
	if self.endEffectNode ~= nil then
		self.endEffectNode:setAnchorPoint(cc.p(0.5,0.5))
		self.endEffectNode:setPosition(cc.p(0,0))
		self.groundNode:addChild(self.endEffectNode, 7)
	else
		self.gameEndPlayActionEndFlag = true
		return
	end

	if self.mapNode ~= nil then
		self.mapNode:allMonsterDisappear()
		self.mapNode:allItemDisappear()
	end

	local FlowerParamList = {
		{resIdx=1, pos={x=100,y=40}, scale={x=1,y=1}, effPos={x=0, y=170}, effScale=0.8, delayGrowOut=0.7, rotateAnger=5, rotateTime=3, scaleEffYminVal=0.8, scaleEffYmaxVal=1.1, scaleEffTime=0.5}, 
		{resIdx=4, pos={x=180,y=30}, scale={x=1,y=1}, effPos={x=0, y=150}, effScale=0.8, delayGrowOut=1.0, rotateAnger=-5, rotateTime=3, scaleEffYminVal=0.8, scaleEffYmaxVal=1, scaleEffTime=0.5}, 
		{resIdx=2, pos={x=250,y=-10}, scale={x=1,y=1}, effPos={x=0, y=150}, effScale=0.8, delayGrowOut=0.8, rotateAnger=-5, rotateTime=3, scaleEffYminVal=0.8, scaleEffYmaxVal=1, scaleEffTime=0.5}, 
		{resIdx=1, pos={x=350,y=40}, scale={x=1,y=1}, effPos={x=0, y=170}, effScale=0.8, delayGrowOut=0.6, rotateAnger=5, rotateTime=3, scaleEffYminVal=0.8, scaleEffYmaxVal=1.1, scaleEffTime=0.5}, 
		{resIdx=3, pos={x=460,y=40}, scale={x=1,y=1}, effPos={x=0, y=190}, effScale=0.8, delayGrowOut=0.4, rotateAnger=5, rotateTime=3, scaleEffYminVal=0.9, scaleEffYmaxVal=1.2, scaleEffTime=0.5}, 
		{resIdx=2, pos={x=500,y=-10}, scale={x=1,y=1}, effPos={x=0, y=150}, effScale=0.8, delayGrowOut=1.2, rotateAnger=-5, rotateTime=3, scaleEffYminVal=0.8, scaleEffYmaxVal=1, scaleEffTime=0.5}, 
		{resIdx=4, pos={x=550,y=30}, scale={x=1,y=1}, effPos={x=0, y=150}, effScale=0.8, delayGrowOut=0.9, rotateAnger=-5, rotateTime=3, scaleEffYminVal=0.8, scaleEffYmaxVal=1, scaleEffTime=0.5}, 
	}

	self.flowerNode = {}
	self.flowerPic = {}
	self.flowerEffPic = {}
	self.blackCoverEffPic = {}

	if isVictory == true then
		for i=1, #FlowerParamList do
			self.flowerNode[i] = display.newNode()
			if self.flowerNode[i] ~= nil then
				self.flowerNode[i]:setAnchorPoint(cc.p(0.5,0.5))
				self.flowerNode[i]:setPosition(cc.p(FlowerParamList[i].pos.x, FlowerParamList[i].pos.y-200))
				self.endEffectNode:addChild(self.flowerNode[i])

				self.flowerPic[i] = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.GAME_WIN_FLOWER_RES_LIST[FlowerParamList[i].resIdx])))
				if self.flowerPic[i] ~= nil then
					self.flowerPic[i]:setAnchorPoint(cc.p(0.5, 0))
					self.flowerPic[i]:setPosition(cc.p(0, 0))
					self.flowerPic[i]:setScaleY(FlowerParamList[i].scaleEffYminVal)
					self.flowerNode[i]:addChild(self.flowerPic[i], 1)
				end
				self.flowerEffPic[i] = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.GAME_WIN_FLOWER_EFFECT_PIC)))
				if self.flowerEffPic[i] ~= nil then
					self.flowerEffPic[i]:setAnchorPoint(cc.p(0.5, 0.5))
					self.flowerEffPic[i]:setPosition(cc.p(FlowerParamList[i].effPos.x, FlowerParamList[i].effPos.y))
					self.flowerEffPic[i]:setScale(0.01)
					self.flowerEffPic[i]:setVisible(false)
					self.flowerNode[i]:addChild(self.flowerEffPic[i], 2)
				end

				self.flowerNode[i]:runAction(cc.Sequence:create(
					cc.DelayTime:create(FlowerParamList[i].delayGrowOut),
					cc.MoveBy:create(0.2, cc.p(0, 200)),
					cc.CallFunc:create(function()
						self.flowerNode[i]:runAction(cc.RepeatForever:create(cc.Sequence:create(
							cc.RotateBy:create(FlowerParamList[i].rotateTime, 0-FlowerParamList[i].rotateAnger),
							cc.RotateBy:create(FlowerParamList[i].rotateTime*2, FlowerParamList[i].rotateAnger*2),
							cc.RotateBy:create(FlowerParamList[i].rotateTime, 0-FlowerParamList[i].rotateAnger)
						)))
					end),
					cc.CallFunc:create(function()
						self.flowerPic[i]:runAction(cc.Sequence:create(
							cc.ScaleTo:create(FlowerParamList[i].scaleEffTime, 1, FlowerParamList[i].scaleEffYmaxVal),
							cc.ScaleTo:create(FlowerParamList[i].scaleEffTime, 1, FlowerParamList[i].scaleEffYminVal),
							cc.ScaleTo:create(FlowerParamList[i].scaleEffTime, 1, FlowerParamList[i].scaleEffYmaxVal),
							cc.DelayTime:create(0.5),
							cc.CallFunc:create(function()
								self.flowerEffPic[i]:setVisible(true)
								self.flowerEffPic[i]:runAction(cc.Sequence:create(
									cc.ScaleTo:create(0.05, FlowerParamList[i].effScale, FlowerParamList[i].effScale),
									cc.DelayTime:create(1),
									cc.CallFunc:create(function()
										if i == #FlowerParamList then
											self.gameEndPlayActionEndFlag = true
										end
									end)
								))
								local explodeEff = cc.ParticleSystemQuad:create(ResourceDef.FLOWER_EXPLODE_EFFECT .. ".plist") 
								if explodeEff ~= nil then
									explodeEff:setPositionType(cc.POSITION_TYPE_RELATIVE)
									explodeEff:setPosition(cc.p(self.flowerEffPic[i]:getPositionX(), self.flowerEffPic[i]:getPositionY()))
									self.flowerNode[i]:addChild(explodeEff, 5)
								end
							end)
						))
					end)
				))
			end
		end
	else
		if self.bgColorLayerFail ~= nil then
			self.bgColorLayerFail:runAction(cc.FadeTo:create(4, 255))
		end

		local flyMonsterList = {}
		local flyMonsterParamList = {
			{scale={x=0.3,y=0.3}, pos={x=240,y=200}, dirRate=1, moveUnitDis=20, moveUnitTime=5},
			{scale={x=-0.4,y=0.4}, pos={x=430,y=550}, dirRate=-1, moveUnitDis=20, moveUnitTime=5},
			{scale={x=0.3,y=0.3}, pos={x=550,y=300}, dirRate=1, moveUnitDis=18, moveUnitTime=6},
			{scale={x=-0.4,y=0.4}, pos={x=50,y=850}, dirRate=-1, moveUnitDis=18, moveUnitTime=6},
			{scale={x=0.3,y=0.3}, pos={x=520,y=900}, dirRate=1, moveUnitDis=20, moveUnitTime=5},
		}
		for i=1, #flyMonsterParamList do
			flyMonsterList[i] = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
			if flyMonsterList[i] ~= nil then
				flyMonsterList[i]:setAnchorPoint(cc.p(0.5, 0.5))
				flyMonsterList[i]:setPosition(cc.p(flyMonsterParamList[i].pos.x, flyMonsterParamList[i].pos.y))
				flyMonsterList[i]:setScaleX(flyMonsterParamList[i].scale.x)
				flyMonsterList[i]:setScaleY(flyMonsterParamList[i].scale.y)
				flyMonsterList[i]:setVisible(false)
				self.endEffectNode:addChild(flyMonsterList[i], 3)

				local showAni = AnimationManager.getAniFromCacheByName("monster_stage_show_5")
				if showAni == nil then
					AnimationManager.setAniToCache(ConfigManager.monsterTbl["5"].res, 1, 7, 0.2,"monster_stage_show_5")
					showAni = AnimationManager.getAniFromCacheByName("monster_stage_show_5")
				end
				if showAni == nil then
					break
				else
					local showAnimation = cc.RepeatForever:create(cc.Animate:create(showAni))
					if showAnimation ~= nil then
						flyMonsterList[i]:runAction(showAnimation)
					end
				end

				local moveSeq = cc.RepeatForever:create(cc.Sequence:create(cc.MoveBy:create(flyMonsterParamList[i].moveUnitTime, cc.p(0-flyMonsterParamList[i].moveUnitDis*flyMonsterParamList[i].dirRate, 0)),
													   cc.CallFunc:create(function()
															flyMonsterList[i]:setScaleX(flyMonsterList[i]:getScaleX()*(-1))
													   end),
													   cc.MoveBy:create(flyMonsterParamList[i].moveUnitTime*2, cc.p(flyMonsterParamList[i].moveUnitDis*2*flyMonsterParamList[i].dirRate, 0)),
													   cc.CallFunc:create(function()
															flyMonsterList[i]:setScaleX(flyMonsterList[i]:getScaleX()*(-1))
													   end),
													   cc.MoveBy:create(flyMonsterParamList[i].moveUnitTime, cc.p(0-flyMonsterParamList[i].moveUnitDis*flyMonsterParamList[i].dirRate, 0))
													   ))
				flyMonsterList[i]:runAction(moveSeq)
			end
		end

		local blackUnitParamList = {
			{resIdx=1, scale=0.6, pos={x=100, y=150}},
			{resIdx=1, scale=0.6, pos={x=250, y=100}},
			{resIdx=1, scale=0.6, pos={x=460, y=220}},
			{resIdx=1, scale=0.6, pos={x=550, y=135}},
		}
		for i=1, #blackUnitParamList do
			self.blackCoverEffPic[i] = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.STAGE_SELECT_CONTENT.blackUnitResList[blackUnitParamList[i].resIdx])))
			if self.blackCoverEffPic[i] ~= nil then
				self.blackCoverEffPic[i]:setAnchorPoint(cc.p(0.5, 0.5))
				self.blackCoverEffPic[i]:setPosition(cc.p(blackUnitParamList[i].pos.x, blackUnitParamList[i].pos.y))
				self.blackCoverEffPic[i]:setScale(blackUnitParamList[i].scale)
				self.blackCoverEffPic[i]:setVisible(false)
				self.endEffectNode:addChild(self.blackCoverEffPic[i], 2)

				local randStart = math.random(1, 3)
				local frames = display.newFrames(ResourceManager.ImageName("pic_repeat_darkclouds_%.2d"), randStart, 5-randStart+1, false)
				if frames ~= nil then
					local ani = display.newAnimation(frames, math.random(7, 13)/100)
					if ani ~= nil then
						self.blackCoverEffPic[i]:runAction(cc.RepeatForever:create(cc.Animate:create(ani)))
					end
				end
			end
		end


		for i=1, #FlowerParamList do
			self.flowerNode[i] = display.newNode()
			if self.flowerNode[i] ~= nil then
				self.flowerNode[i]:setAnchorPoint(cc.p(0.5,0.5))
				self.flowerNode[i]:setPosition(cc.p(FlowerParamList[i].pos.x, FlowerParamList[i].pos.y-200))
				self.endEffectNode:addChild(self.flowerNode[i])

				self.flowerPic[i] = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.GAME_LOSE_FLOWER_RES_LIST[FlowerParamList[i].resIdx])))
				if self.flowerPic[i] ~= nil then
					self.flowerPic[i]:setAnchorPoint(cc.p(0.5, 0))
					self.flowerPic[i]:setPosition(cc.p(0, 0))
					self.flowerPic[i]:setScaleY(FlowerParamList[i].scaleEffYminVal)
					self.flowerNode[i]:addChild(self.flowerPic[i], 1)
				end

				self.flowerEffPic[i] = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.GAME_LOSE_FLOWER_EFFECT_PIC)))
				if self.flowerEffPic[i] ~= nil then
					self.flowerEffPic[i]:setAnchorPoint(cc.p(0.5, 0.5))
					self.flowerEffPic[i]:setPosition(cc.p(FlowerParamList[i].effPos.x, FlowerParamList[i].effPos.y))
					self.flowerEffPic[i]:setScale(0.01)
					self.flowerEffPic[i]:setVisible(false)
					self.flowerNode[i]:addChild(self.flowerEffPic[i], 2)
				end

				self.flowerNode[i]:runAction(cc.Sequence:create(
					cc.DelayTime:create(FlowerParamList[i].delayGrowOut),
					cc.MoveBy:create(0.2, cc.p(0, 200)),
					cc.CallFunc:create(function()
						self.flowerNode[i]:runAction(cc.RepeatForever:create(cc.Sequence:create(
							cc.RotateBy:create(FlowerParamList[i].rotateTime, 0-FlowerParamList[i].rotateAnger),
							cc.RotateBy:create(FlowerParamList[i].rotateTime*2, FlowerParamList[i].rotateAnger*2),
							cc.RotateBy:create(FlowerParamList[i].rotateTime, 0-FlowerParamList[i].rotateAnger)
						)))
					end),
					cc.CallFunc:create(function()
						self.flowerPic[i]:runAction(cc.Sequence:create(
							cc.ScaleTo:create(FlowerParamList[i].scaleEffTime, 1, FlowerParamList[i].scaleEffYmaxVal),
							cc.ScaleTo:create(FlowerParamList[i].scaleEffTime, 1, FlowerParamList[i].scaleEffYminVal),
							cc.ScaleTo:create(FlowerParamList[i].scaleEffTime, 1, FlowerParamList[i].scaleEffYmaxVal),
							cc.DelayTime:create(0.5),
							cc.CallFunc:create(function()
								self.flowerEffPic[i]:setVisible(true)
								self.flowerEffPic[i]:runAction(cc.Sequence:create(
									cc.ScaleTo:create(0.05, FlowerParamList[i].effScale, FlowerParamList[i].effScale),
									cc.DelayTime:create(0.8),
									cc.CallFunc:create(function()
										if i == #FlowerParamList then
											for j=1, #flyMonsterList do
												if flyMonsterList[j] ~= nil then
													flyMonsterList[j]:setVisible(true)
												end
											end
											for k=1, table.nums(self.blackCoverEffPic) do
												if self.blackCoverEffPic[k] ~= nil then
													self.blackCoverEffPic[k]:setVisible(true)
													self.blackCoverEffPic[k]:runAction(cc.Sequence:create(
														cc.DelayTime:create(1),
														cc.CallFunc:create(function()
															if k == #blackUnitParamList then
																self.gameEndPlayActionEndFlag = true
															end
														end)
													))
												end
											end
										end
									end)
								))
							end)
						))
					end)
				))
			end
		end

	end
	
end

function GameLayer:showGameResult(result)
	if self.GameResultLayer ~= nil then
		self.GameResultLayer:resetLayer(self.stageId, result, self.isShopMap, self.isTest)
	    self.GameResultLayer:openLayer()
	end
end

function GameLayer:onEvent(event, forceFlag)
	if self:isVisible() == false then
		return
	end

	if self.mapNode.stopUpdateFlag == true then
		if forceFlag == nil or forceFlag == false then
			return
		end
	end

	if self.gameEndFlag == true then
		return 
	end

	if event == nil or event.name == nil then
		return
	end

	if event.name == GameDefine.GAME_CONTROL_EVENT_TYPE.LEFT_TOP then
		if self.mapNode ~= nil and self.mapNode.mainPlayer ~= nil then
			self.mapNode.stopUpdateFlag = false
			if self.mapNode.mainPlayer.jumpState < GameDefine.CHARACTER_JUMP_STATE.FALLGROUND and
			   self.mapNode.mainPlayer.jumpState > GameDefine.CHARACTER_JUMP_STATE.BEGIN and
			   self.mapNode.mainPlayer.curDirection == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_TOP then
				if self.mapNode.mainPlayer.secondJumpFlag == false then
					self.mapNode.mainPlayer.secondJumpFlag = true
					self.mapNode.mainPlayer:bigJump()
				end
			else
				self.mapNode.mainPlayer.nextDirection = GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_TOP
			end
		end
	elseif event.name == GameDefine.GAME_CONTROL_EVENT_TYPE.LEFT_BOTTOM then
		if self.mapNode ~= nil and self.mapNode.mainPlayer ~= nil then
			self.mapNode.stopUpdateFlag = false
			if self.mapNode.mainPlayer.jumpState < GameDefine.CHARACTER_JUMP_STATE.FALLGROUND and
			   self.mapNode.mainPlayer.jumpState > GameDefine.CHARACTER_JUMP_STATE.BEGIN and
			   self.mapNode.mainPlayer.curDirection == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_BOTTOM then
				if self.mapNode.mainPlayer.secondJumpFlag == false then
					self.mapNode.mainPlayer.secondJumpFlag = true
					self.mapNode.mainPlayer:bigJump()
				end
			else
				self.mapNode.mainPlayer.nextDirection = GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_BOTTOM
			end
		end
	elseif event.name == GameDefine.GAME_CONTROL_EVENT_TYPE.RIGHT_TOP then
		if self.mapNode ~= nil and self.mapNode.mainPlayer ~= nil then
			self.mapNode.stopUpdateFlag = false
			if self.mapNode.mainPlayer.jumpState < GameDefine.CHARACTER_JUMP_STATE.FALLGROUND and
			   self.mapNode.mainPlayer.jumpState > GameDefine.CHARACTER_JUMP_STATE.BEGIN and
			   self.mapNode.mainPlayer.curDirection == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_TOP then
				if self.mapNode.mainPlayer.secondJumpFlag == false then
					self.mapNode.mainPlayer.secondJumpFlag = true
					self.mapNode.mainPlayer:bigJump()
				end
			else
				self.mapNode.mainPlayer.nextDirection = GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_TOP
			end
		end
	elseif event.name == GameDefine.GAME_CONTROL_EVENT_TYPE.RIGHT_BOTTOM then
		if self.mapNode ~= nil and self.mapNode.mainPlayer ~= nil then
			self.mapNode.stopUpdateFlag = false
			if self.mapNode.mainPlayer.jumpState < GameDefine.CHARACTER_JUMP_STATE.FALLGROUND and
			   self.mapNode.mainPlayer.jumpState > GameDefine.CHARACTER_JUMP_STATE.BEGIN and
			   self.mapNode.mainPlayer.curDirection == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_BOTTOM then
				if self.mapNode.mainPlayer.secondJumpFlag == false then
					self.mapNode.mainPlayer.secondJumpFlag = true
					self.mapNode.mainPlayer:bigJump()
				end
			else
				self.mapNode.mainPlayer.nextDirection = GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_BOTTOM
			end
		end
	end
end


function GameLayer:pauseGame()
	cc.Director:getInstance():pause()

	if self.pauseLayer ~= nil then
		self.pauseLayer:resetLayer(self.stageId)
		self.pauseLayer:openLayer()
	end

	-- if self.mapNode ~= nil then
	-- 	self.mapNode.stopUpdateFlag = true
	-- end
end

function GameLayer:makeFloatFlowers(node, zorder)
	if node == nil then
		return
	end
	if zorder == nil then
		zorder = 1
	end

	local totalCountRow = 4
	local totalCountColumn = 4
	for i=1, totalCountRow*totalCountColumn do
		local randIdx = math.random(1, #ResourceDef.MAINSCENE_CONTENT.floatFlowers)
		local flower = display.newSprite(ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(ResourceDef.MAINSCENE_CONTENT.floatFlowers[randIdx])))
		if flower ~= nil then
			flower:setAnchorPoint(cc.p(0.5,0.5))
			flower:setScale(math.random(100, 120)/100)
			node:addChild(flower, zorder)
			flower:runAction(cc.RepeatForever:create(cc.RotateBy:create(1, 360)))

			local rowIdx = math.floor(i/totalCountRow)
			local columnIdx = math.fmod(i, totalCountColumn) + 1
			flower:setPosition(cc.p(math.random(display.width*columnIdx/totalCountColumn, display.width*(columnIdx+1)/totalCountColumn), math.random(display.height*rowIdx/totalCountRow, display.height*(rowIdx+1)/totalCountRow)))

			local offval = 5
			local bez = {
				cc.p(math.random(31-offval, 31+offval), math.random(-124-offval, -124+offval)),
				cc.p(math.random(100-offval, 100+offval), math.random(-138-offval, -138+offval)),
				cc.p(math.random(95-offval, 95+offval), math.random(-100-offval, -100+offval))
			}
			flower:runAction(cc.RepeatForever:create(cc.Sequence:create(
				cc.BezierBy:create(math.random(50, 100) / 10, bez), 
				cc.CallFunc:create(function()
					if flower:getPositionY() < 0 then
						flower:setPosition(cc.p(math.random(-150, display.cx-100), math.random(display.height, display.height+100)))
					end
				end)
			)))
		end
	end
end

function GameLayer:GameReset()
	self.stageId = 0
	self.steps = 0
	self.isShopMap = false
	self.isTest = false
	self.startTimeStamp = nil
	self.gameUseTime = 0
	self:refreshSteps()
	self.hasStartFlag = false
	self.gameEndFlag = false
	self.gameResultPreparedOKFlag = false
	self.gameEndPlayActionEndFlag = false
	if self.mapNode ~= nil then
		self.mapNode:reset()
	end

	if self.cloudNode ~= nil then
		self.cloudNode:setVisible(true)
	end

	if self.controlNode ~= nil then
		self.controlNode:setVisible(true)
	end

	if self.GameResultLayer ~= nil then
		self.GameResultLayer:closeLayer()
	end

	if self.PauseLayer ~= nil then
		self.pauseLayer:closeLayer()
	end

	if self.endEffectNode ~= nil then
		self.endEffectNode:stopAllActions()
		self.endEffectNode:removeFromParent(true)
		self.endEffectNode = nil
	end

	if self.bgColorLayerFail ~= nil then
		self.bgColorLayerFail:setOpacity(0)
	end
	if self.thunderBg ~= nil then
		self.thunderBg:setVisible(false)
	end

	if self.thunderEffectPic ~= nil then
		local tpPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
		if tpPic ~= nil then
			self.thunderEffectPic:setSpriteFrame(tpPic:getSpriteFrame())
		end
	end

	if self.pauseNode ~= nil then
		self.pauseNode:stopAllActions()
		self.pauseNode:setRotation(0)
	end

	self.flowerNode = {}
	self.flowerPic = {}
	self.flowerEffPic = {}
	self.blackCoverEffPic = {}

	if self.playingClockSoundEffectId ~= nil then
		AudioManager.stopEffect(self.playingClockSoundEffectId)
		self.playingClockSoundEffectId = nil
	end
end

function GameLayer:openLayer(stageId, isShopMap, isTest, mapData)
	self:GameReset()
	self.isShopMap = isShopMap
	self.isTest = isTest
	if stageId > 0 then
		self:prepareGame(stageId)
	elseif self.isTest == true and mapData ~= nil then
		self:prepareGameWithData(mapData)
	end
	self:setVisible(true)
end


function GameLayer:closeLayer()
	self:setVisible(false)
	self:GameReset()
end


return GameLayer