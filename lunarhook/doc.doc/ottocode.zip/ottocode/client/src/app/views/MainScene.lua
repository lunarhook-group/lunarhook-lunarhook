
local MainScene = class("MainScene", function()
    return display.newScene("MainScene")
end)

function MainScene:ctor()

    --flags
    self.isGamingFlag = false

    self.isTransitionFlag = false

    UserDataManager.loadPlayerData()

	self:init()

    self:initKeypadControl()
end

function MainScene:init()
    --preload sprite frame
    for k,v in pairs(ResourceDef.GAME_MAIN_SPRITE) do
        ResourceManager.addFramesToCache(ResourceManager.ImageName(v),
                                         ResourceManager.ResourceName(v) .. ResourceDef.SPRITE_PLIST_STR
                                         )
    end

    --preload sound
    for k,v in pairs(ResourceDef.GAME_SOUND_LIST) do
        if type(v) == "string" then
            AudioManager.preloadEffect(ResourceManager.SoundName(v))
        elseif type(v) == "table" then
            for kk,vv in pairs(v) do
                if type(vv) == "string" then
                    AudioManager.preloadEffect(ResourceManager.SoundName(vv))
                end
            end
        end
    end

    --
    AudioManager.playBackgroundMusic(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.mainBGMusic), true)

    -- ui
    self:initUILayer()


    -- scheduler
    self.mainSchedulerHandler = scheduler.scheduleUpdateGlobal(function(t)
        self:update(t)
    end)

    self:registerEvent()

    self:initNetwork()
end

function MainScene:initUILayer()

    self.blackCoverLayer = cc.LayerColor:create(cc.c4b(0, 0, 0, 0), display.width, display.height)
    if self.blackCoverLayer ~= nil then
        self.blackCoverLayer:setAnchorPoint(cc.p(0,0))
        self.blackCoverLayer:setPosition(cc.p(0,0))
        self:addChild(self.blackCoverLayer, 200)
    end

    --init major ui list
    self.MainLayer = import("app.views.MainLayer").new()
    if self.MainLayer ~= nil then
        self:addChild(self.MainLayer)
    end

    --loading layer
    self.loadingLayer = import("app.views.LoadingLayer").new()
    if self.loadingLayer ~= nil then
        self.loadingLayer:setVisible(false)
        self:addChild(self.loadingLayer, 100)
    end

    self.tipsLabel = display.newTTFLabel({
        text = "",
        font = ResourceDef.FONT_GAME_MAIN,
        size = 24,
        color = cc.c3b(0,0,0),
        align = cc.TEXT_ALIGNMENT_CENTER
    })
    if self.tipsLabel ~= nil then
        self.tipsLabel:setVisible(false)
        self.tipsLabel:setAnchorPoint(cc.p(0.5,0.5))
        self.tipsLabel:setPosition(cc.p(display.cx, display.height - 50))
        self.tipsLabel.isShowing = false
        self:addChild(self.tipsLabel, 100)
    end

    self.confirmLayer = import("app.views.ConfirmDialogLayer").new()
    if self.confirmLayer ~= nil then
        self.confirmLayer:setPosition(cc.p(0, 0))
        self.confirmLayer:closeLayer()
        self:addChild(self.confirmLayer, 99)
    end

    self:returnMainLayer()

end


function MainScene:update(t)
    if self.MainLayer ~= nil and self.MainLayer.update ~= nil then
        self.MainLayer:update(t)
    end

    if self.StageSelectLayer ~= nil and self.StageSelectLayer.update ~= nil then
        self.StageSelectLayer:update(t)
    end

    if self.GameLayer ~= nil and self.GameLayer.update ~= nil and self.isGamingFlag == true then
        if self.GameLayer:isVisible() == true then
            self.GameLayer:update(t)
        end
    end

    if self.ShopLayer ~= nil and self.ShopLayer.update ~= nil then
        self.ShopLayer:update(t)
    end

    if self.StageEditLayer ~= nil and self.StageEditLayer.update ~= nil then
        self.StageEditLayer:update(t)
    end

end

function MainScene:UITransition(cb)
    if cb == nil then
        return 
    end

    if self.blackCoverLayer == nil then
        self.isTransitionFlag = true
        cb()
        self.isTransitionFlag = false
        return 
    end

    self.blackCoverLayer:runAction(cc.Sequence:create(
            cc.CallFunc:create(function()
                self.isTransitionFlag = true
            end),
            cc.FadeTo:create(GameConfig.UI_TRANSITION_TIME, 255),
            cc.CallFunc:create(function()
                cb()
            end),
            cc.DelayTime:create(0.5),
            cc.FadeTo:create(GameConfig.UI_TRANSITION_TIME, 0),
            cc.CallFunc:create(function()
                self.isTransitionFlag = false
            end)
        )
    )

end

function MainScene:showLoading()
    if self.loadingLayer ~= nil then
        self.loadingLayer:setVisible(true)
    end
end

function MainScene:hideLoading()
    if self.loadingLayer ~= nil then
        self.loadingLayer:setVisible(false)
    end
end

function MainScene:HideAllMainLayer()
    if self.MainLayer ~= nil then
        -- self.MainLayer:closeLayer()
        self.MainLayer.isMainLayerShowing = false
    end
    if self.StageSelectLayer ~= nil then
        self.StageSelectLayer:closeLayer()
    end
    if self.ShopLayer ~= nil then
        self.ShopLayer:closeLayer()
    end
    if self.StageEditLayer ~= nil then
        self.StageEditLayer:closeLayer()
    end
    if self.GameLayer ~= nil then
        self.GameLayer:closeLayer()
    end
    if self.confirmLayer ~= nil then
        self.confirmLayer:closeLayer()
    end
    if self.playerInfoLayer ~= nil then
        self.playerInfoLayer:closeLayer()
    end
end

function MainScene:showStageInfo(stageId)
    if stageId == nil then
        return
    end

    if UserDataManager.RANK_LIST[tostring(stageId)] == nil or
       UserDataManager.RANK_LIST[tostring(stageId)].lastReqTime == nil or 
       UserDataManager.RANK_LIST[tostring(stageId)].lastReqTime < os.time() - 30 then

        --request for rank
        local params = {id = stageId}
        local ret, resp = GameNetWorker.createHttpRequestWithPostParam(GameConfig.SERVER_ADDRESS .. GameConfig.REQUEST_URL.rank, params, false)
        if ret == true then
            local respInfo = json.decode(resp)
            if respInfo ~= nil then
                -- dump(respInfo)
                if respInfo.errorId ~= nil then
                    self:showTips(respInfo.errorMsg)
                else
                    UserDataManager.RANK_LIST[tostring(stageId)] = {
                        myRank = 0,
                        rankInfo = respInfo,
                        lastReqTime = os.time()
                    }

                    for i=1, #respInfo do
                        if tostring(respInfo[i].playerId) == tostring(UserDataManager.PLAYER_UID) then
                            UserDataManager.RANK_LIST[tostring(stageId)].myRank = i
                            break
                        end
                    end
                end
            end
        end
    end

    if self.StageInfoLayer ~= nil then
        self.StageInfoLayer:resetLayer(stageId, {isGameEnd=false, isWin=false, steps=0})
        self.StageInfoLayer:openLayer()
    end
end

function MainScene:enterGame(stageId, isShopMap, isTest, mapData)
    self:HideAllMainLayer()
    if isShopMap == nil then
        isShopMap = false
    end
    if isTest == nil then
        isTest = false
    end

    if self.GameLayer == nil then
        self.GameLayer = import("app.views.GameLayer").new()
        if self.GameLayer ~= nil then
            self:addChild(self.GameLayer)
            self.GameLayer:openLayer(stageId, isShopMap, isTest, mapData)
            self.isGamingFlag = true
        end
    else
        self.GameLayer:openLayer(stageId, isShopMap, isTest, mapData)
        self.isGamingFlag = true
    end

    AudioManager.stopBackgroundMusic(false)
    AudioManager.playBackgroundMusic(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.gameBGMusic), true)
end

function MainScene:openShop(shopType)
    -- self:showTips(LangStringDefine.FUNC_NOT_OPEN)

    self:HideAllMainLayer()
    if self.ShopLayer == nil then
        self.ShopLayer = import("app.views.ShopLayer").new()
        if self.ShopLayer ~= nil then
            self:addChild(self.ShopLayer)
        end
        self.ShopLayer:openLayer(shopType)
    else
        self.ShopLayer:openLayer(shopType)
    end
end

function MainScene:openEditor()
    -- self:showTips(LangStringDefine.FUNC_NOT_OPEN)
    self:HideAllMainLayer()
    if self.StageEditLayer == nil then
        self.StageEditLayer = import("app.views.StageEditLayer").new()
        if self.StageEditLayer ~= nil then
            self:addChild(self.StageEditLayer)
            self.StageEditLayer:openLayer()
        end
    else
        self.StageEditLayer:openLayer()
    end
end

function MainScene:openPlayerInfo()
    -- self:showTips(LangStringDefine.FUNC_NOT_OPEN)

    self:HideAllMainLayer()
    if self.playerInfoLayer == nil then
        self.playerInfoLayer = import("app.views.PlayerInfo").new()
        if self.playerInfoLayer ~= nil then
            self:addChild(self.playerInfoLayer)
            self.playerInfoLayer:openLayer()
        end
    else
        self.playerInfoLayer:openLayer()
    end
end

function MainScene:returnMainLayer()
    self:HideAllMainLayer()
    if self.MainLayer ~= nil then
        self.MainLayer:openLayer()
    end
end

function MainScene:returnStageSelectLayer(worldIdx)
    self:HideAllMainLayer()
    if self.MainLayer ~= nil then
        self.MainLayer:closeLayer()
    end

    if worldIdx == nil then
        worldIdx = 1
    end
    if self.StageSelectLayer == nil then
        self.StageSelectLayer = import("app.views.StageSelectLayer").new()
        if self.StageSelectLayer ~= nil then
            self:addChild(self.StageSelectLayer)
            self.StageSelectLayer:openLayer(worldIdx)
        end
    else
        self.StageSelectLayer:openLayer(worldIdx)
    end
end

function MainScene:showTips(str, offY)
    if self.tipsLabel == nil or self.tipsLabel.isShowing == true then
        return
    end

    if offY == nil then
        offY = 0
    end

    self.tipsLabel.isShowing = true
    self.tipsLabel:runAction(
        cc.Sequence:create(
            cc.CallFunc:create(function()
                self.tipsLabel:setString(str)
                self.tipsLabel:setPositionY(self.tipsLabel:getPositionY()+offY)
                self.tipsLabel:setVisible(true)
            end),
            cc.DelayTime:create(2),
            cc.CallFunc:create(function()
                self.tipsLabel:setVisible(false)
                self.tipsLabel:setString("")
                self.tipsLabel:setPositionY(self.tipsLabel:getPositionY()-offY)
                self.tipsLabel.isShowing = false
            end)
        )
    )

end

function MainScene:showConfirmLayer(str, cb)
    if self.confirmLayer ~= nil then
        self.confirmLayer:resetLayer(str, cb)
        self.confirmLayer:openLayer()
    end
end

function MainScene:initKeypadControl()
    if device.platform == "android" then 
        local listener = cc.EventListenerKeyboard:create()
        listener:registerScriptHandler(handler(self, self.onKeyPressed), cc.Handler.EVENT_KEYBOARD_PRESSED )
        listener:registerScriptHandler(handler(self, self.onKeyReleased), cc.Handler.EVENT_KEYBOARD_RELEASED )
        local eventDispatcher = self:getEventDispatcher()
        eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)
    end
end

-- 按键按下
function MainScene:onKeyPressed(keyCode, event)
    if keyCode == cc.KeyCode.KEY_BACK then
        self.key_back_pressed = true
    end
end

-- 按键抬起
function MainScene:onKeyReleased(keyCode, event)
    if keyCode == cc.KeyCode.KEY_BACK and self.key_back_pressed then
        self.key_back_pressed = false
        self:showConfirmLayer(LangStringDefine.LABEL_TEXT_EXIT_GAME_DESC, function()
            os.exit()
        end)
    end
end

function MainScene:registerEvent()
    if cc.Director:getInstance().eventDispatcher ~= nil then
        cc.Director:getInstance().eventDispatcher:bind(self)
    end

    EventListener.addEventListener(GameDefine.GAME_CONTROL_EVENT_TYPE.LEFT_TOP, function ()
       if self.GameLayer ~= nil and self.GameLayer.onEvent ~= nil then
            self.GameLayer:onEvent({name = GameDefine.GAME_CONTROL_EVENT_TYPE.LEFT_TOP})
       end
    end)
    EventListener.addEventListener(GameDefine.GAME_CONTROL_EVENT_TYPE.LEFT_BOTTOM, function ()
       if self.GameLayer ~= nil and self.GameLayer.onEvent ~= nil then
            self.GameLayer:onEvent({name = GameDefine.GAME_CONTROL_EVENT_TYPE.LEFT_BOTTOM})
       end
    end)
    EventListener.addEventListener(GameDefine.GAME_CONTROL_EVENT_TYPE.RIGHT_TOP, function ()
       if self.GameLayer ~= nil and self.GameLayer.onEvent ~= nil then
            self.GameLayer:onEvent({name = GameDefine.GAME_CONTROL_EVENT_TYPE.RIGHT_TOP})
       end
    end)
    EventListener.addEventListener(GameDefine.GAME_CONTROL_EVENT_TYPE.RIGHT_BOTTOM, function ()
       if self.GameLayer ~= nil and self.GameLayer.onEvent ~= nil then
            self.GameLayer:onEvent({name = GameDefine.GAME_CONTROL_EVENT_TYPE.RIGHT_BOTTOM})
       end
    end)
    
    --game item event
    EventListener.addEventListener(GameDefine.GAME_EVENT_TYPE.GET_ITEM, function (data)
        if data ~= nil and data.item_id ~= nil and self.GameLayer ~= nil and self.GameLayer.mapNode ~= nil then 
            local itemTblInfo = ConfigManager.itemTbl[tostring(data.item_id)]
            if itemTblInfo ~= nil and itemTblInfo.item_type ~= nil then
                if itemTblInfo.item_type == GameDefine.ITEM_TYPE.ADD_COIN then
                    --todo need refresh coin

                elseif itemTblInfo.item_type == GameDefine.ITEM_TYPE.ADD_CANDY then
                    --todo need refresh candy

                elseif itemTblInfo.item_type == GameDefine.ITEM_TYPE.GOD then
                    if itemTblInfo.params ~= nil and type(itemTblInfo.params == "table") then
                        if itemTblInfo.params[1] ~= nil and itemTblInfo.params[1] > 0 then
                            self.GameLayer.mapNode.god_leftTime = itemTblInfo.params[1]
                            self.GameLayer.mapNode.bigfoot_leftTime = 0
                            self.GameLayer.mapNode.bigfoot_is_next_block = false

                            if self.GameLayer.playingClockSoundEffectId == nil then
                                self.GameLayer.playingClockSoundEffectId = AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.buffTimeDecreaseEffect), true)
                            end
                        end
                    end
                elseif itemTblInfo.item_type == GameDefine.ITEM_TYPE.BIG_FOOT then
                    if itemTblInfo.params ~= nil and type(itemTblInfo.params == "table") then
                        if itemTblInfo.params[1] ~= nil and itemTblInfo.params[1] > 0 then
                            self.GameLayer.mapNode.bigfoot_leftTime = itemTblInfo.params[1]
                            self.GameLayer.mapNode.god_leftTime = 0

                            if self.GameLayer.playingClockSoundEffectId == nil then
                                self.GameLayer.playingClockSoundEffectId = AudioManager.playEffect(ResourceManager.SoundName(ResourceDef.GAME_SOUND_LIST.buffTimeDecreaseEffect), true)
                            end
                        end
                    end
                elseif itemTblInfo.item_type == GameDefine.ITEM_TYPE.WATER_PROTECT then
                    if itemTblInfo.params ~= nil and type(itemTblInfo.params == "table") then
                        if itemTblInfo.params[1] ~= nil and itemTblInfo.params[1] > 0 then
                            self.GameLayer.mapNode.extra_life = itemTblInfo.params[1]
                        end
                    end
                elseif itemTblInfo.item_type == GameDefine.ITEM_TYPE.THUNDER then
                    self.GameLayer.mapNode:killAllMonster()

                elseif itemTblInfo.item_type == GameDefine.ITEM_TYPE.MAGIC_BALL then
                    self.GameLayer.mapNode:WinImmediately()

                end

                self.GameLayer.mapNode:addItemEffectShow(itemTblInfo)
            end
        end
    end)
end

function MainScene:initNetwork()
    --nothing to do except using tcp socket
    -- local params = {}
    -- local ret, resp = GameNetWorker.createHttpRequestWithPostParam(GameConfig.SERVER_ADDRESS .. GameConfig.REQUEST_URL.login, params, false)
    -- dump(resp)
end

return MainScene
