
local MonsterFly = class("MonsterFly", BaseCharacter)

function MonsterFly:ctor(monsterId, parentMap, dir, objId)
	MonsterFly.super.ctor(self)

	self.objId = objId
	self.parentMapNode = parentMap
	self.faceR = false
	self.monsterId = monsterId
	self.isAlive = false

	self.nextDirection = GameDefine.GAME_CHARACTER_DIRECTION_TYPE.NONE
	self.curDirection = dir or GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_BOTTOM

	self.aniTimeInternal = 0
	self.aniTime_record = 0
	self.aniIndex = 0

	self.eachBlockMoveUseFrameCount = 50
	-- self.floatMaxHeight = 15
	-- self.floatMaxHeightUseTime = 1
	-- self.floatMaxHeightDelayTime = 0.1
	self.walkBlockCount = 0

	self:init()
end

function MonsterFly:init()
	self.monsterTblInfo = ConfigManager.monsterTbl[tostring(self.monsterId)]
	if self.monsterTblInfo == nil then
		return
	end

	self.mainNode = display.newNode()
	if self.mainNode == nil then
		return
	end

	self.mainNode:setAnchorPoint(cc.p(0.5,0.5))
	self.mainNode:setPosition(cc.p(0,0))
	self:addChild(self.mainNode)


	--main pic
	local resStr = string.format("%s%0.2d", self.monsterTblInfo.res, self.monsterTblInfo.animation.fall.start)
	self.mainPic = display.newSprite(ResourceManager.ImageName(resStr))
	if self.mainPic ~= nil then
		self.mainPic:setAnchorPoint(cc.p(0.5,0))
		self.mainPic:setPosition(cc.p(0, 0))
		self.mainNode:addChild(self.mainPic, 1)


		-- local seq = cc.Sequence:create(cc.MoveBy:create(self.floatMaxHeightUseTime, cc.p(0, self.floatMaxHeight)),
		-- 							   cc.DelayTime:create(self.floatMaxHeightDelayTime),
		-- 							   cc.MoveBy:create(self.floatMaxHeightUseTime, cc.p(0, 0-self.floatMaxHeight)),
		-- 							   cc.DelayTime:create(self.floatMaxHeightDelayTime))
		-- if seq ~= nil then
		-- 	self.mainPic:runAction(cc.RepeatForever:create(seq))
		-- end
	end

	--appear ani pic
	self.appearAniPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
	if self.appearAniPic ~= nil then
		self.appearAniPic:setAnchorPoint(cc.p(0.5,0))
		self.appearAniPic:setPosition(cc.p(0,0))
		self.appearAniPic:setScaleX(self.mainPic:getScaleX())
		self.appearAniPic:setScaleY(self.mainPic:getScaleY())
		self.mainNode:addChild(self.appearAniPic, 2)
	end

	self.initShadowPosY = 0
	self.initShadowScale = 0.4
	self.mainShadowPic = display.newSprite(ResourceManager.ImageName(ResourceDef.MONSTER_SHADOW))
	if self.mainShadowPic ~= nil then
		self.mainShadowPic:setAnchorPoint(cc.p(0.5,0.5))
		self.mainShadowPic:setPosition(cc.p(0,self.initShadowPosY))
		self.mainShadowPic:setScale(self.initShadowScale)
		self.mainNode:addChild(self.mainShadowPic)
		self.mainShadowPic:setVisible(false)
	end

	-- self.eachJumpCostSecond = self.monsterTblInfo.animation.jump.time * GameConfig.PLAYER_JUMP_TIME_EACH_BLOCK[self.parentMapNode.difficultType]
	-- self.aniTimeInternal = self.eachJumpCostSecond / self.monsterTblInfo.animation.jump.count
	-- self.jumpAniFrameCount = self.eachBlockMoveUseFrameCount
	self.moveDistanceEachTime = {x=GameDefine.GROUND_BLOCK_WIDTH/2/self.eachBlockMoveUseFrameCount, y=GameDefine.GROUND_BLOCK_HEIGHT/2/self.eachBlockMoveUseFrameCount}
	-- self.aniTime_record = self.aniTimeInternal

	if self.monsterTblInfo.animation.thunder.count > 0 and self.monsterTblInfo.animation.thunder.time > 0 then
		AnimationManager.setAniToCache(self.monsterTblInfo.res, self.monsterTblInfo.animation.thunder.start, self.monsterTblInfo.animation.thunder.count, self.monsterTblInfo.animation.thunder.time, "monster_thunder_" .. tostring(self.monsterId))
	end
	if self.monsterTblInfo.animation.victory.count > 0 and self.monsterTblInfo.animation.victory.time > 0 then
		AnimationManager.setAniToCache(self.monsterTblInfo.res, self.monsterTblInfo.animation.victory.start, self.monsterTblInfo.animation.victory.count, self.monsterTblInfo.animation.victory.time, "monster_victory_" .. tostring(self.monsterId))
	end
	if self.monsterTblInfo.animation.fall.count > 0 and self.monsterTblInfo.animation.fall.time > 0 then
		AnimationManager.setAniToCache(self.monsterTblInfo.res, self.monsterTblInfo.animation.fall.start, self.monsterTblInfo.animation.fall.count, self.monsterTblInfo.animation.fall.time, "monster_fall_" .. tostring(self.monsterId))
	end

	--飞行怪飞行动画使用fall动画的配置内容
	local flyAni = AnimationManager.getAniFromCacheByName("monster_fall_" .. tostring(self.monsterId))
	if flyAni ~= nil then
		local flyAnimation = cc.RepeatForever:create(cc.Animate:create(flyAni))
		if flyAnimation ~= nil then
			self.mainPic:stopAllActions()
			self.isAlive = true
			self.mainPic:runAction(flyAnimation)
		end
	end

	--thunder die effect pre construct
	self.thunderPic = cc.ProgressTimer:create(display.newSprite(ResourceManager.ImageName(ResourceDef.ITEM_EFFECT_LIGHTNING)))
	if self.thunderPic ~= nil then
		self.thunderPic:setType(cc.PROGRESS_TIMER_TYPE_BAR)
		self.thunderPic:setMidpoint(cc.p(0.5,1))
		self.thunderPic:setBarChangeRate(cc.p(0,1))
		self.thunderPic:setPercentage(0)
		self.thunderPic:setAnchorPoint(cc.p(0.5,0))
		self.thunderPic:setPosition(cc.p(0, self.mainPic:getContentSize().height/2+10))
		self.mainNode:addChild(self.thunderPic, 10)
	end

	self:changeFaceR(self.curDirection >= GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_TOP)
end

function MonsterFly:playAppearSmoke()
	
end

function MonsterFly:changeFaceR(faceR)
	if faceR == nil then
		faceR = not self.faceR
	end

	if self.faceR == faceR then
		return
	end

	if faceR == true then
		self.mainPic:setScaleX(math.abs(self.mainPic:getScaleX())*(-1))
	else
		self.mainPic:setScaleX(math.abs(self.mainPic:getScaleX()))
	end

	self.faceR = faceR
end

function MonsterFly:changeAnimationPic(res)
	if self.mainPic == nil or self.mainNode == nil or self.monsterTblInfo == nil or res == nil then
		return
	end

	local tpFrame = ResourceManager.getSpriteFrameFromCache(ResourceManager.ImageName(res))
	if tpFrame ~= nil then
		self.mainPic:setSpriteFrame(tpFrame)
	end
end

function MonsterFly:update(t)
	if self.isAlive == false then
		return
	end

	if self.tpNumber == nil then
		self.tpNumber = self.eachBlockMoveUseFrameCount/2
	end
	self.tpNumber = self.tpNumber + 1
	self:move(self.tpNumber >= self.eachBlockMoveUseFrameCount)
	if self.tpNumber >= self.eachBlockMoveUseFrameCount then
		self.tpNumber = 0
	end

	if self.mainShadowPic ~= nil then
		if self.parentMapNode ~= nil then
			self.mainShadowPic:setVisible(not self.parentMapNode:checkFall(self))
		end
		-- if self.mainShadowPic:isVisible() == true then
		-- 	self.mainShadowPic:setPositionY(0-self.mainNode:getPositionY()+self.initShadowPosY)
		-- 	self.mainShadowPic:setScale(self.initShadowScale - (self.initShadowScale - 0.3) * (self.mainNode:getPositionY() / self.floatMaxHeight))
		-- end
	end
	
end

function MonsterFly:move(needChangeMapPosFlag)
	if self.curDirection == nil or self.curDirection == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.NONE then
		return
	end

	local dstMoveDis = {x=0, y=0}
	local moveMapVector = {x=0, y=0}
	if self.curDirection == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_TOP then
		dstMoveDis.x = 0 - self.moveDistanceEachTime.x
		dstMoveDis.y = self.moveDistanceEachTime.y
		moveMapVector.x = -1
		moveMapVector.y = 0
	elseif self.curDirection == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.LEFT_BOTTOM then
		dstMoveDis.x = 0 - self.moveDistanceEachTime.x
		dstMoveDis.y = 0 - self.moveDistanceEachTime.y
		moveMapVector.x = 0
		moveMapVector.y = -1
	elseif self.curDirection == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_TOP then
		dstMoveDis.x = self.moveDistanceEachTime.x
		dstMoveDis.y = self.moveDistanceEachTime.y
		moveMapVector.x = 0
		moveMapVector.y = 1
	elseif self.curDirection == GameDefine.GAME_CHARACTER_DIRECTION_TYPE.RIGHT_BOTTOM then
		dstMoveDis.x = self.moveDistanceEachTime.x
		dstMoveDis.y = 0 - self.moveDistanceEachTime.y
		moveMapVector.x = 1
		moveMapVector.y = 0
	end

	self:setPositionX(self:getPositionX() + dstMoveDis.x)
	self:setPositionY(self:getPositionY() + dstMoveDis.y)

	if needChangeMapPosFlag ~= nil and needChangeMapPosFlag == true then
		self:setMapPosition({x=self:getMapPosition().x+moveMapVector.x, y=self:getMapPosition().y+moveMapVector.y})
		self:setLocalZOrder(GameDefine.MAX_GROUND_X+GameDefine.MAX_GROUND_Y+GameDefine.ZORDER_BASE_VALUE + self.parentMapNode:calcCharacterZorderAddValue(self:getMapPosition().x+moveMapVector.x, self:getMapPosition().y+moveMapVector.y))
	
		self.walkBlockCount = self.walkBlockCount + 1
		if self.walkBlockCount > 30 then
			self.isAlive = false
			self:die()
		end
	end

end

function MonsterFly:win()
	if self.mainPic == nil then
		return
	end

	local winAni = AnimationManager.getAniFromCacheByName("monster_victory_" .. tostring(self.monsterId))
	if winAni == nil then
		return
	end
	local winAnimation = cc.Animate:create(winAni)
	if winAnimation == nil then
		return
	end

	self.isAlive = false
	self.mainPic:stopAllActions()
	self.mainPic:runAction(winAnimation)

end

function MonsterFly:appear()
	if self.appearAniPic == nil then
		return
	end

	local disappearAni = AnimationManager.getAniFromCacheByName("disappear_cover_ani")
	if disappearAni ~= nil then
		self.appearAniPic:runAction(
				cc.Sequence:create(cc.Animate:create(disappearAni),
									cc.CallFunc:create(function()
										local tpPic = display.newSprite(ResourceManager.ImageName(ResourceDef.IMAGE_TRANSPARENT))
										if tpPic ~= nil then
											self.appearAniPic:setSpriteFrame(tpPic:getSpriteFrame())
										end
									end)
				)
			)
	end
end

function MonsterFly:beKilled(timeIdx)
	self.isAlive = false
	if timeIdx == nil then
		timeIdx = 0
	end

	if self.mainPic == nil then
		self:die()
		return
	end

	local beThunderAni = AnimationManager.getAniFromCacheByName("monster_thunder_" .. tostring(self.monsterId))
	if beThunderAni == nil then
		self:die()
		return
	end
	local beThunderAnimation = cc.Animate:create(beThunderAni)
	if beThunderAnimation == nil then
		self:die()
		return
	end
	beThunderAnimation:retain()

	self.mainPic:stopAllActions()
	local delay_time = timeIdx * 0.3
	self.mainPic:runAction(cc.Sequence:create(
		cc.DelayTime:create(delay_time),
		cc.CallFunc:create(function()
			if self.thunderPic ~= nil then
				self.thunderPic:runAction(cc.ProgressTo:create(0.2, 100))
			end
		end),
		cc.DelayTime:create(0.2),
		beThunderAnimation:clone(),
		cc.DelayTime:create(0.1),
		cc.CallFunc:create(function()
			beThunderAnimation:release()
			self:die(false)
		end)
		)
	)
end

function MonsterFly:die(playEffectFlag)
	if playEffectFlag == nil then
		playEffectFlag = true
	end

	if self.thunderPic ~= nil then
		self.thunderPic:stopAllActions()
		self.thunderPic:removeFromParent(true)
	end

	local haveAni = false
	if playEffectFlag == true then
		if self.mainPic ~= nil then
			self.mainPic:stopAllActions()
			local disappearAni = AnimationManager.getAniFromCacheByName("disappear_cover_ani")
			if disappearAni ~= nil then
				local disappearAnimation = cc.Animate:create(disappearAni)
				if disappearAnimation ~= nil then
					haveAni = true
					self.mainPic:runAction(cc.Sequence:create(disappearAnimation, cc.CallFunc:create(function()
						self:stopAllActions()
						self.parentMapNode.monsterList[self.objId] = nil
						self:removeFromParent(true)
					end)))
				end
			end
		end
	end

	if haveAni == false then
		self:stopAllActions()
		self.parentMapNode.monsterList[self.objId] = nil
		self:removeFromParent(true)
	end
end

return MonsterFly
