local GameControlButton = import("app.views.GameControlButton")
local ShopItemCell = import("app.views.ShopItemCell")

local ShopMapList = class("ShopLayer", BaseLayer)

function ShopMapList:ctor()
	ShopMapList.super.ctor(self)

	self.data = {}

	self:initUI()
end

function ShopMapList:initUI()
	--pos nodes
	self.nodeLeftBottom = display.newNode()
	self.leftTopNode = display.newNode()
	if self.nodeLeftBottom == nil or self.leftTopNode == nil then
		return
	end
	self.nodeLeftBottom:setAnchorPoint(cc.p(0.5,0.5))
	self.nodeLeftBottom:setPosition(cc.p(0, 0))
	self:addChild(self.nodeLeftBottom, SHOP_LAYER_ZORDER_DEFINE.UI_CONTENT)
	self.leftTopNode:setAnchorPoint(cc.p(0.5,0.5))
	self.leftTopNode:setPosition(cc.p(0, display.height))
	self:addChild(self.leftTopNode, SHOP_LAYER_ZORDER_DEFINE.UI_CONTENT)

	--bg
	self.bgNode = display.newNode()
	if self.bgNode ~= nil then
		self.bgNode:setAnchorPoint(cc.p(0.5,0.5))
		self.bgNode:setPosition(cc.p(display.cx, display.cy))
		self:addChild(self.bgNode, SHOP_LAYER_ZORDER_DEFINE.BG)

		--main bg
		self.bgPic = display.newSprite(ResourceManager.ImageName(ResourceDef.GAME_BG))
		if self.bgPic ~= nil then
			self.bgPic:setAnchorPoint(cc.p(0.5,0.5))
			self.bgPic:setPosition(cc.p(0,0))
			self.bgPic:setScaleX(display.width/self.bgPic:getContentSize().width)
			self.bgPic:setScaleY(display.height/self.bgPic:getContentSize().height)
			self.bgNode:addChild(self.bgPic)
		end
	end

	--return button
	self.buttonReturn = GameControlButton.new({
        btnBg = ResourceDef.BUTTON_RETURN,
        dstSize = {width=90, height=90},
        callback = function ()
        	--todo

        end
    })
    if self.buttonReturn ~= nil then
		self.buttonReturn:setAnchorPoint(cc.p(0.5, 0.5))
		self.buttonReturn:setPosition(cc.p(50, -50))
	    self.leftTopNode:addChild(self.buttonReturn)
	end

	--title
    self.shopTitleLabel = display.newTTFLabel({
        text = "",
        font = ResourceDef.FONT_GAME_MAIN,
        size = 38,
        align = cc.TEXT_ALIGNMENT_CENTER,
        color = cc.c3b(0,0,250)
    })
    if self.shopTitleLabel ~= nil then
        self.shopTitleLabel:setAnchorPoint(cc.p(0.5,0.5))
        self.shopTitleLabel:setPosition(cc.p(display.cx, -100))
        self.leftTopNode:addChild(self.shopTitleLabel, 10)
    end

    --line
    --todo

	self:initView()

end

function ShopMapList:initView()
	local viewSize = {width=display.width*0.8, height=display.height*0.6}
	self.tableView = cc.TableView:create(cc.size(viewSize.width, viewSize.height))
   	if self.tableView ~= nil then

   		self.tableView:setPosition(cc.p(display.cx-viewSize.width/2, display.cy-viewSize.height/2))
	    self.tableView:setAnchorPoint(cc.p(0, 0))
	    
	    self.tableView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)
	   
	    self.tableView:setDelegate()
	    self.tableView:setDataSource()
	    self.tableView:setBounceable(false)
	    self.tableView:setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN)
	    
	    self.tableView:registerScriptHandler(function(tbl, cell)
	    	if self.isSelecting ~= nil and self.isSelecting == true then
	    		return
	    	end
	    	print("------- viewl cell touched ---- ", cell.idx)

	    	self.isSelecting = true
	    	--todo


	    	if cell.bgPanelPic ~= nil then
	    		cell.bgPanelPic:runAction(cc.Sequence:create(
	    			cc.ScaleTo:create(0.05, 0.9),
	    			cc.ScaleTo:create(0.05, 1.0)
	    		))
	    	end
	    end, cc.TABLECELL_TOUCHED)
	    self.tableView:registerScriptHandler(function()
	    	return viewSize.width, viewSize.height/3
	    end, cc.TABLECELL_SIZE_FOR_INDEX)
	    self.tableView:registerScriptHandler(function()
     		return #self.data
	    end, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)

	    self.tableView:registerScriptHandler(function()
	    	-- if self.scrollNoticeNode == nil then
		    --     return
		    -- end
		    -- local nowX = self.tableView:getContentOffset().x
		    -- local tmpX = 0
		    -- if GameConfig.IS_IPHONEX == true then
	   		-- 	tmpX = GameConfig.IPHONEX_XPOS*2
	   		-- end
		    -- if nowX >= -65 then
		    --     self.scrollNoticeNode:showOrHideMainIcon(false, true)
		    --     self.scrollNoticeNode:showOrHideMainIcon(true, false)
		    -- elseif nowX <= -3293-(1136-tmpOffsetX-display.width) + 65 + tmpX then
		    --     self.scrollNoticeNode:showOrHideMainIcon(false, false)
		    --     self.scrollNoticeNode:showOrHideMainIcon(true, true)
		    -- else
		    --     self.scrollNoticeNode:showOrHideMainIcon(false, true)
		    --     self.scrollNoticeNode:showOrHideMainIcon(true, true)
		    -- end
		    -- print("=======    ", self.tableView:getContentOffset().x, self.tableView:getContentOffset().y)
	    end, cc.SCROLLVIEW_SCRIPT_SCROLL)

	    self.tableView:registerScriptHandler(function(tbl, idx)
			local keyIdx = idx + 1 
		    local cell = tbl:dequeueCell()
		    local isNewCell = false
		    if nil == cell then
		        cell = cc.TableViewCell:new()
		        isNewCell = true
		    end
		    cell.idx = keyIdx

		    if isNewCell == true then
	    		cell.content = ShopItemCell.new()
	    		if cell.content ~= nil then
	    			cell.content.resetCell(self.data[keyIdx])
	    		end
			else
				if cell.content ~= nil then
	    			cell.content.resetCell(self.data[keyIdx])
	    		end
			end

		    return cell

	    end, cc.TABLECELL_SIZE_AT_INDEX)

	    self.tableView:reloadData()
	    self.nodeLeftBottom:addChild(self.tableView, 10)
	    self.tableView:setTouchEnabled(true)

	    -- --scroll node
		-- self.scrollNoticeNode = GameTools.getScrollNoticeNode(false, viewSize.width-30)
		-- if self.scrollNoticeNode ~= nil then
		-- 	self.scrollNoticeNode:setPosition(cc.p(self.tableView:getPositionX()+25, viewSize.height/2+0))
		-- 	self.viewNode:addChild(self.scrollNoticeNode, 11)
		-- 	--default
		-- 	self.scrollNoticeNode:showOrHideMainIcon(false, false)
		-- 	self.scrollNoticeNode:showOrHideMainIcon(true, true)
		-- end
   	end
end

function ShopMapList:resetLayer()
	self.data = 
	{
		{
			itemId = 1,
			res = "",
			maker = "xx1",
			publishTime = "111",
			price = 10,
			tagState = {true, false, true},
		},
		{
			itemId = 2,
			res = "",
			maker = "xx2",
			publishTime = "222",
			price = 30,
			tagState = {false, false, true},
		},
		{
			itemId = 3,
			res = "",
			maker = "xx3",
			publishTime = "333",
			price = 20,
			tagState = {true, true, false},
		}
	}

	if self.tableView ~= nil then
		self.tableView:reloadData()
	end

	
end

function ShopMapList:openLayer()
	self.isSelecting = false
	self:setVisible(true)
end


function ShopMapList:closeLayer()
	self:setVisible(false)
	self.isSelecting = false
end

return ShopMapList
