
local BaseCreater = class("BaseCreater")


function BaseCreater:ctor()
end


function BaseCreater:addListener( eventName,handler )
	ViewListener:getInstance():addListener( eventName,handler )
end









return BaseCreater