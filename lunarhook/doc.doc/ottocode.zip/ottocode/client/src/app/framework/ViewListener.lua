
local ViewListener = class("ViewListener")

function ViewListener:ctor()
	self:reset()
end

function ViewListener:reset()
	self._instance = nil
	self._listener = nil
end


function ViewListener:getInstance()
	if not self._instance then
		self._instance = ViewListener.new()
	end
	return self._instance
end



function ViewListener:addListener( eventName,handler )
	assert( eventName," !! eventName is nil !! ")
	assert( type(eventName) == "string"," eventName not string " )
	assert( handler," !! handler is nil !! ")
	assert( type(handler) == "function"," !! handler not function !! " )

	if self._listener == nil then
		self._listener = {}
	end
	assert( self._listener[eventName]," !! listener has exist !! " )
	self._listener[eventName] = handler
end

rawset(_G,"ViewListener",ViewListener)


