
local BaseCharacter = class("BaseCharacter",function()
	return display.newNode()
end )

function BaseCharacter:ctor()
	
	self.mapPosition = {x=0,y=0}
	
end

function BaseCharacter:setMapPosition(pos)
	if pos == nil or pos.x == nil or pos.y == nil then
		return
	end

	self.mapPosition.x = pos.x
	self.mapPosition.y = pos.y
end

function BaseCharacter:getMapPosition()
	return self.mapPosition
end

rawset(_G, "BaseCharacter", BaseCharacter)
