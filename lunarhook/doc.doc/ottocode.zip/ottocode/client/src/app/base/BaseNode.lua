
local BaseNode = class("BaseNode",function()
	return cc.Node:create()
end )



-- 构造函数
function BaseNode:ctor()
	self:init()
end

function BaseNode:init()
    self:enableNodeEvents()
end

function BaseNode:onEnter() 
    
end

function BaseNode:onExit()
    
end


-- 定时器(只允许存在一个定时器)
function BaseNode:schedule(func, time)
    if not self.scheduleNode then 
        self.scheduleNode = cc.Node:create()
        self:addChild(self.scheduleNode)
        self.scheduleNode:runAction(cc.RepeatForever:create( cc.Sequence:create(
            cc.DelayTime:create(time),
            cc.CallFunc:create(func)
            ) 
        ))
    end
end
function BaseNode:stopSchedule()
    self.scheduleNode:pause()
end
function BaseNode:startSchedule() 
    self.scheduleNode:resume()
end
function BaseNode:unSchedule()
    if self.scheduleNode then
        self.scheduleNode:stopAllActions()
        self.scheduleNode:removeFromParent()
        self.scheduleNode = nil
    end
end


rawset(_G, "BaseNode", BaseNode)
