
local BaseLayer = class("BaseLayer",BaseNode )

function BaseLayer:ctor()
    self:setContentSize(cc.size( display.width,display.height ))
    self:registTouchEvent()
    BaseLayer.super.ctor(self)
end

function BaseLayer:registTouchEvent()
    self.listener = cc.EventListenerTouchOneByOne:create()
    self.listener:setSwallowTouches(true)
    self.listener:registerScriptHandler(handler(self, self.onTouchBegan), cc.Handler.EVENT_TOUCH_BEGAN)
    self.listener:registerScriptHandler(handler(self, self.onTouchMoved), cc.Handler.EVENT_TOUCH_MOVED)
    self.listener:registerScriptHandler(handler(self, self.onTouchEnded), cc.Handler.EVENT_TOUCH_ENDED)
    self.listener:registerScriptHandler(handler(self, self.onTouchCancelled), cc.Handler.EVENT_TOUCH_CANCELLED)
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(self.listener, self)
end


function BaseLayer:onTouchBegan(touch, event)
    local touchPoint = touch:getLocation()
    local localPoint = self:getParent():convertToNodeSpace(touchPoint)
    local boxRect = self:getBoundingBox()
    if cc.rectContainsPoint(boxRect, localPoint) then
        if not self:isVisible() then
            return false
        end        
        return true
    end
    return false
end

function BaseLayer:onTouchMoved(touch, event)
end

function BaseLayer:onTouchEnded(touch, event)
end

rawset(_G, "BaseLayer", BaseLayer)
