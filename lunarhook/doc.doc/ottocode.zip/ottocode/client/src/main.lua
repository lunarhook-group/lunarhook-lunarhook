
cc.FileUtils:getInstance():setPopupNotify(false)

xpcall(function()
		require("app.EnterApp"):create():run()
	end, 
	function()
		 print("----------------------------------------")
	    print("LUA ERROR: " .. tostring(errorMessage))
	    local traceStr = debug.traceback("", 2)
	    print(traceStr)
	    print("----------------------------------------")

	    if ErrorManager ~= nil then
	    	ErrorManager.sendError2Developer(errorMessage, traceStr)
	    end
	end
)

