
var redis = require("redis");

var client = null;

var server_addr = "127.0.0.1";
var server_port = 6379;
var connect_pwd = "Redis12345";
var select_db_index = 0;

var initClient = function() {
	client = redis.createClient(server_port, server_addr, {});
	client.auth(connect_pwd, function(){
		console.log("auth success");
	});
	client.select(select_db_index, function(){
		console.log("select db: "+ select_db_index);
	});
	// client.on("connect", function(err){
	// 	var xx = client.get("test", function(err, reply){
	// 		console.log("-----redis get  test: " + reply);
	// 	});
	// });
	// client.on("ready", function(err){
	// 	console.log("ready");
	// });
	// client.on("end", function(err){
	// 	console.log("end");
	// });
};

var getValue = function(key, cb) {
	client.get(key, function(err, reply){
		cb(reply);
	});
};

var setValue = function(key, val, cb) {
	client.set(key, val, function(){
		if (cb != null) {
			cb();
		}	
	});
};

exports.initClient = initClient;
exports.getValue = getValue;
exports.setValue = setValue;
