
var makeErrorString = function(errId, errMsg) {
	var errArr = {
		"errorId" : errId,
		"errorMsg" : errMsg
	};
	return JSON.stringify(errArr);
};


exports.makeErrorString = makeErrorString;