var recv_packet_log = function() {
	return function(req, resp, next) {
		console.log(new Date().toLocaleString() + " ---recv packet --- " + req.url);
		next();
	};
};

exports.recv_packet_log = recv_packet_log;