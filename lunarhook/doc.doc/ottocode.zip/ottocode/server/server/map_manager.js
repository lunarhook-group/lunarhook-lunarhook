var playerManager = require("./player_manager");
var redisManager = require("./redis_manager");

var mapList = {};
var mapListStr = "";
var mapDataList = {};
var map_new_id = 10001;

var initMapList = function() {
	redisManager.getValue("map_list", function(ret){
		if(ret == null) {
			ret = "{}";
			redisManager.setValue("map_list", ret);
		}

		mapListStr = ret;
		mapList = JSON.parse(ret);

		redisManager.getValue("map_new_id", function(ret) {
			if (ret == null){
				map_new_id = 10001;
				redisManager.setValue("map_new_id", map_new_id);
			}else{
				map_new_id = parseInt(ret);
			}
		});

		// var mapCount = 0;
		for(var mapId in mapList) {
			// mapCount = mapCount + 1;
			redisManager.getValue("mapData_"+mapId, function(result) {
				if (result != null){
					var mapData = JSON.parse(result);
					mapDataList[""+mapData["mapId"]] = mapData
					// if (mapCount == Object.getOwnPropertyNames(mapList).length){
					// 	console.log("--- Map init finish ---" + mapCount);
					// }
				}
			});
		}

		// if (mapCount == 0)
		// 	console.log("--- Map init finish --- " + mapCount);
	});
};

var makeMapId = function(playerId) {
	var mapId = map_new_id;
	map_new_id = map_new_id + 1;
	redisManager.setValue("map_new_id", map_new_id);
	return mapId;
};

var addMap = function(playerId, mapData, mapTitle, cb) {
	var mapId = makeMapId(playerId);
	var mapInfo = {
		"mapId" : mapId,
		"maker": playerId,
		"uploadTime": Math.ceil(Date.now() / 1000),
		"downloadTimes" : 0,
		"price" : 1,
		"title" : mapTitle
	};

	mapList[""+mapId] = mapInfo;
	mapDataList[""+mapId] = mapData;
	mapDataList[""+mapId]["mapId"] = mapId;
	redisManager.setValue("mapData_"+mapId, JSON.stringify(mapData));

	mapListStr = JSON.stringify(mapList);
	redisManager.setValue("map_list", mapListStr);

	playerManager.playerAddMap(playerId, mapId, mapInfo, false);

	cb(mapInfo);
};

var getMapList = function() {
	return mapListStr;
};

var getMapInfo = function(mapId) {
	if (mapDataList[""+mapId] == null) {
		return {"errorId":2, "errorMsg":"map not exist"};
	}

	return mapDataList[""+mapId];
};

var buyMap = function(playerId, mapId, cb) {
	var playerMapInfo = playerManager.getPlayerMapInfo(playerId);
	if (playerMapInfo == null) {
		if (cb != null) {
			cb({"errorId":1, "errorMsg":"player not login"});
			return;
		}
	}

	if (mapDataList[""+mapId] == null) {
		cb({"errorId":2, "errorMsg":"map not exist"});
		return;
	}

	// if (mapList[""+mapId] == null ||
	//     mapList[""+mapId]["maker"] == playerId ||
	//     playerMapInfo["download"] == null ||
	//     playerMapInfo["download"][""+mapId] != null) 
	// {
	// 	cb({"errorId":3, "errorMsg":"player has own the map"});
	// 	return;
	// }

	// if(playerManager.changeCoin(playerId, 0-mapList[""+mapId]["price"]) == false){
	// 	cb({"errorId":4, "errorMsg":"player coin not enough"});
	// 	return;
	// }

	mapList[""+mapId]["downloadTimes"] = mapList[""+mapId]["downloadTimes"] + 1;
	mapListStr = JSON.stringify(mapList);
	redisManager.setValue("map_list", mapListStr);

	playerManager.playerAddMap(playerId, mapId, mapList[""+mapId], true);

	var resp = mapList[""+mapId];
	resp["mapData"] = mapDataList[""+mapId];
	resp["coin"] = playerManager.getCoin(playerId);
	cb(resp);
};

exports.initMapList = initMapList;
exports.addMap = addMap;
exports.buyMap = buyMap;
exports.getMapList = getMapList;
exports.getMapInfo = getMapInfo;
