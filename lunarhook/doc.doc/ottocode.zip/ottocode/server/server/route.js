var playerManager = require("./player_manager");
var rankManager = require("./rank_manager");
var mapManager = require("./map_manager");
var errorManager = require("./error_manager");

var login = function() {
	return function(req, resp, next) {
		req.on("data", function(data) {
			var params = JSON.parse(data.toString());
			if(params["playerId"] != null) {
				var playerId = params["playerId"];
				if(params["playerId"] == "0000") {
					playerId = "" + playerManager.findNewPlayerId();
				}

				playerManager.loadPlayer(playerId, function() {
					if (playerManager.getPlayerLoadFlag(playerId) == 7) {
						var playerData = playerManager.findPlayer(playerId);
						if (playerData != null) {
							resp.write(JSON.stringify(playerData));
							resp.end();
						}
					}
				});
			}else{
				resp.write(errorManager.makeErrorString(1, "param error!"));
				resp.end();
			}
		});
	};
};
exports.login = login;

var stageComplete = function() {
	return function(req, resp, next) {
		req.on("data", function(data) {
			var nowTime = Math.ceil(Date.now() / 1000);
			var params = JSON.parse(data.toString());
			if(params["playerId"] != null && params["stageId"] != null) {
				var playerData = playerManager.findPlayer(params["playerId"]);
				if (playerData != null && playerData["stageInfo"] != null) {
					var stageData = playerData["stageInfo"][params["stageId"].toString()];
					var needUpdateFlag = false;
					if (stageData == null) {
						needUpdateFlag = true;
						playerData["stageInfo"][params["stageId"].toString()] = {
							'step': parseInt(params["step"]),
							'record_time': nowTime,
							'firstTime': nowTime,
							'record_use_time': parseInt(params["use_time"])
						};
					}else{
						if ((stageData["step"] > parseInt(params["step"])) || (stageData["step"] == 0)) {
							needUpdateFlag = true;
							playerData["stageInfo"][params["stageId"].toString()]["step"] = parseInt(params["step"]);
							playerData["stageInfo"][params["stageId"].toString()]["record_time"] = nowTime;
							playerData["stageInfo"][params["stageId"].toString()]["record_use_time"] = parseInt(params["use_time"]);
							if (stageData["firstTime"] == 0)
								playerData["stageInfo"][params["stageId"].toString()]["firstTime"] = nowTime;
						}
					}
					if (needUpdateFlag == true){
						playerManager.updateStageInfo(params["playerId"]);
						rankManager.applyToRank(params["playerId"], params["stageId"], parseInt(params["step"]), nowTime);
					}

					var retArr = {
						"stageInfo" : playerData["stageInfo"][params["stageId"].toString()],
						"needUpdateFlag" : needUpdateFlag
					}

					if (params["nextStageId"] != null) {
						var nextStageId = "" + params["nextStageId"];
						if (nextStageId != "0" && playerData["stageInfo"][nextStageId] == null) {
							playerData["stageInfo"][nextStageId] = {
								'step': 0,
								'record_time': 0,
								'firstTime': 0,
								'record_use_time': 0
							};
							playerManager.updateStageInfo(params["playerId"]);

							retArr["nextStageId"] = nextStageId;
							retArr["nextStageInfo"] = playerData["stageInfo"][nextStageId];
						}
					}

					resp.write(JSON.stringify(retArr));

				}else{
					resp.write(errorManager.makeErrorString(1, "param error!"));
				}
			}else{
				resp.write(errorManager.makeErrorString(1, "param error!"));
			}

			resp.end();
		});
	};
};
exports.stageComplete = stageComplete;

var getMapInfo = function() {
	return function(req, resp, next) {
		req.on("data", function(data) {
			var params = JSON.parse(data.toString());
			if(params["mapId"] != null) {
				
				var mapInfo = mapManager.getMapInfo(params["mapId"]);
				if (mapInfo != null) {
					resp.write(JSON.stringify(mapInfo));
					resp.end();
				}
				else
				{
					resp.write(errorManager.makeErrorString(2, "map info data error!"));
					resp.end();
				}
			}else{
				resp.write(errorManager.makeErrorString(1, "param error!"));
				resp.end();
			}
		});
	};
}
exports.getMapInfo = getMapInfo;

var upload = function() {
	return function(req, resp, next) {
		var dataStr = "";
		req.on("data", function(data) {
			dataStr = dataStr + data;
		});

		req.on("end", function() {
			var params = JSON.parse(dataStr.toString());
			if(params["playerId"] != null && params["mapData"] != null) {
				mapManager.addMap(params["playerId"], params["mapData"], params["title"], function(mapData) {
					resp.write(JSON.stringify(mapData));
					resp.end();
				});
			}else{
				resp.write(errorManager.makeErrorString(1, "param error!"));
				resp.end();
			}
		});
	};
};
exports.upload = upload;


var shopList = function() {
	return function(req, resp, next) {
		req.on("data", function(data) {			
			var shoplistStr = mapManager.getMapList();
			resp.write(shoplistStr);
			resp.end();
		});
	};
};
exports.shoplist = shopList;


var shopBuy = function() {
	return function(req, resp, next) {
		req.on("data", function(data) {
			var params = JSON.parse(data.toString());
			if(params["playerId"] != null && params["mapId"] != null) {
				mapManager.buyMap(params["playerId"], params["mapId"], function(ret){
					if (ret["errorId"] != null) {
						resp.write(errorManager.makeErrorString(ret["errorId"], ret["errorMsg"]));
					}else{
						resp.write(JSON.stringify(ret));
					}
					resp.end();
				});
			}else{
				resp.write(errorManager.makeErrorString(1, "param error!"));
				resp.end();
			}
		});
	};
};
exports.shopbuy = shopBuy;

var getRank = function() {
	return function(req, resp, next) {
		req.on("data", function(data) {
			var params = JSON.parse(data.toString());
			if(params["id"] != null) {
				rankManager.getRank(params["id"], function(rankStr){
					resp.write(rankStr);
					resp.end();
				});
			}else{
				resp.write(errorManager.makeErrorString(1, "param error!"));
				resp.end();
			}
		});
	};
}
exports.getRank = getRank;

