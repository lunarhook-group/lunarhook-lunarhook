
var mysql = require("mysql");

var dbpool = mysql.createPool({
	host : "127.0.0.1",
	port : 3306,
	database : "gamedb",
	user : "root",
	password : "root123",
});

var query = function(sql) {
	dbpool.getConnection(function(err, connection) {
		if (err) {
			return err;
		}else{
			connection.query(sql);
		}
	});
};

var insert =  function(tblname, data) {

};

exports.query = query;
exports.insert = insert;
