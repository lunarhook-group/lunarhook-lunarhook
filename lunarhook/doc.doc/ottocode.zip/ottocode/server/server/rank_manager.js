var redisManager = require("./redis_manager");

var ranks = {};
var ranks_str = {};
var ranks_player_cache = {};

// ranks = {
// 	"101" : [
// 		{"playerId" : "111", "steps": 10, "finTime" : 15011123},

// 	];
// }


var getRank = function(id, cb) {
	if (cb == null || id == null)
		return;
	var idStr = ""+id;

	if(ranks[idStr] != null && ranks_str[idStr] != null) {
		cb(ranks_str[idStr]);
		return;
	}

	redisManager.getValue("rankInfo_"+id, function(ret) {
		if (ret == null) {
			ranks[idStr] = [];
			ranks_str[idStr] = "[]";
			ranks_player_cache[idStr] = {};
		}else{
			ranks[idStr] = JSON.parse(ret);
			ranks_str[idStr] = ret;
			if (ranks_player_cache[idStr] == null)
				ranks_player_cache[idStr] = {};
			for (var i = 0; i < ranks[idStr].length; i++) {
				ranks_player_cache[idStr][""+ranks[idStr][i]["playerId"]] = {"index" : i, "steps" : ranks[idStr][i]["steps"]};
			}
		}
		cb(ranks_str[idStr]);
	});
};

var sortRank = function(playerId, id, steps, finTime) {
	if (ranks[id] == null)
		ranks[id] = [];

	if (ranks_player_cache[id] == null)
		ranks_player_cache[id] = {};

	var arr_length = ranks[id].length;
	var changeFlag = false;

	if (ranks_player_cache[id][""+playerId] != null) {
		if (steps < ranks_player_cache[id][""+playerId]["steps"]) {
			if (ranks_player_cache[id][""+playerId]["index"] == 0) {
				ranks[id][0]["steps"] = steps;
				ranks[id][0]["finTime"] = finTime;
				ranks_player_cache[id][""+playerId]["steps"] = steps;
			}else{
				var tmpIdx = ranks_player_cache[id][""+playerId]["index"];
				for (var i = ranks_player_cache[id][""+playerId]["index"]-1; i >= 0; i--) {
					if ( (steps < ranks[id][i]["steps"]) ||
						 (steps == ranks[id][i]["steps"] && finTime < ranks[id][i]["finTime"]) ) 
					{
						tmpIdx = i;
					}else{
						break;
					}
				}

				if (i == 0) {
					var arr1 = [{"playerId" : playerId, "steps": steps, "finTime" : finTime}];
					var arr2 = ranks[id].slice(0, ranks_player_cache[id][""+playerId]["index"]-1);
					var arr3 = ranks[id].slice(ranks_player_cache[id][""+playerId]["index"]+1);
					ranks[id] = arr1.concat(arr2, arr3);
				}else{
					var arr1 = ranks[id].slice(0, tmpIdx);
					var arr2 = [{"playerId" : playerId, "steps": steps, "finTime" : finTime}];
					var arr3 = ranks[id].slice(tmpIdx, ranks_player_cache[id][""+playerId]["index"]-1);
					var arr4 = ranks[id].slice(ranks_player_cache[id][""+playerId]["index"]+1);
					ranks[id] = arr1.concat(arr2, arr3, arr4);
				}
			}			
		}
	}else{
		var tmpIdx = arr_length;
		for (var i = arr_length-1; i >= 0; i--) {
			if ( (steps < ranks[id][i]["steps"]) ||
				 (steps == ranks[id][i]["steps"] && finTime < ranks[id][i]["finTime"]) ) 
			{
				tmpIdx = i;
			}else{
				break;
			}
		}

		if (tmpIdx == 0){
			ranks[id].unshift({"playerId" : playerId, "steps": steps, "finTime" : finTime});
		}else if(tmpIdx == arr_length) {
			ranks[id].push({"playerId" : playerId, "steps": steps, "finTime" : finTime});
		}else{
			var arr1 = ranks[id].slice(0, tmpIdx);
			var arr2 = [{"playerId" : playerId, "steps": steps, "finTime" : finTime}];
			var arr3 = ranks[id].slice(tmpIdx);
			ranks[id] = arr1.concat(arr2, arr3);
		}

		if (ranks[id].length > 100) {
			ranks[id].pop();
		}
	}
};

var applyToRank = function(playerId, id, steps, finTime) {
	if (playerId == null || id == null)
		return;
	if (steps == null || steps <= 0)
		return;
	if (finTime == null || finTime <= Math.ceil(Date.now() / 1000) - 5*60)
		return;

	var idStr = ""+id;
	if(ranks[idStr] == null) {
		redisManager.getValue("rankInfo_"+id, function(ret) {
			if (ret == null) {
				ranks[idStr] = [{"playerId" : playerId, "steps": steps, "finTime" : finTime}];
				ranks_player_cache[idStr] = {};
				ranks_player_cache[idStr][""+playerId] = steps;
			}else{
				ranks[idStr] = JSON.parse(ret);
				sortRank(playerId, idStr, steps, finTime);
			}
			ranks_str[idStr] = JSON.stringify(ranks[idStr]);
			redisManager.setValue("rankInfo_"+id, ranks_str[idStr]);
		});
	}else{
		sortRank(playerId, idStr, steps, finTime);
		ranks_str[idStr] = JSON.stringify(ranks[idStr]);
		redisManager.setValue("rankInfo_"+id, ranks_str[idStr]);
	}	
};

exports.getRank = getRank;
exports.applyToRank = applyToRank;
