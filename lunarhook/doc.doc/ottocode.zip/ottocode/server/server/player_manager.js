﻿var redisManager = require("./redis_manager");
var errorManager = require("./error_manager");

var players = {};
var players_load_flag = {};
var player_new_id = 10001;

var initPlayerMananger = function() {
	redisManager.getValue("player_new_id", function(ret) {
		if (ret == null){
			player_new_id = 10001;
			redisManager.setValue("player_new_id", player_new_id);
		}else{
			player_new_id = parseInt(ret);
		}
	});
};

var findPlayer = function(playerId) {
	return players[playerId];
};

var getPlayerLoadFlag = function(playerId) {
	return players_load_flag[playerId];
};

var findNewPlayerId = function() {
	var targetId = player_new_id;
	player_new_id = player_new_id + 1;
	redisManager.setValue("player_new_id", player_new_id);
	return targetId;
};

var loadPlayer = function(playerId, cb) {
	if (findPlayer(playerId) == null)
	{
		players_load_flag[playerId] = 0;
		redisManager.getValue("baseInfo_"+playerId, function(ret) {
			if (ret == null) {
				var baseInfo = {
					'model_id':1,
					'coin':0,
					'candy':0,
					'name':'玩家'
				};
				redisManager.setValue("baseInfo_"+playerId, JSON.stringify(baseInfo));
				
				if (players[playerId] == null)
					players[playerId] = {};
				players[playerId]["playerId"] = playerId;
				players[playerId]["baseInfo"] = baseInfo;

			}else{
				if (players[playerId] == null)
					players[playerId] = {};
				players[playerId]["baseInfo"] = JSON.parse(ret);
			}

			players_load_flag[playerId] = players_load_flag[playerId] + 1;
			if (cb != null)
				cb();
		});

		redisManager.getValue("stageInfo_"+playerId, function(ret) {
			if (ret == null) {
				var stageInfo = {
					'101':{'step':0,'record_time':0,'firstTime':0, 'record_use_time':0}
				};
				redisManager.setValue("stageInfo_"+playerId, JSON.stringify(stageInfo));

				if (players[playerId] == null)
					players[playerId] = {};
				players[playerId]["stageInfo"] = stageInfo;
				
			}else{
				if (players[playerId] == null)
					players[playerId] = {};
				players[playerId]["stageInfo"] = JSON.parse(ret);
			}

			players_load_flag[playerId] = players_load_flag[playerId] + 2;
			if (cb != null)
				cb();
		});

		redisManager.getValue("mapInfo_"+playerId, function(ret) {
			if (ret == null) {
				var mapInfo = {
					"upload" : {},
					"download" : {}
				};
				redisManager.setValue("mapInfo_"+playerId, JSON.stringify(mapInfo));

				if (players[playerId] == null)
					players[playerId] = {};
				players[playerId]["mapInfo"] = mapInfo;
				
			}else{
				if (players[playerId] == null)
					players[playerId] = {};
				players[playerId]["mapInfo"] = JSON.parse(ret);
			}

			players_load_flag[playerId] = players_load_flag[playerId] + 4;
			if (cb != null)
				cb();
		});
	}else{
		if (cb != null)
			cb();
	}
};

var updateStageInfo = function(playerId) {
	redisManager.setValue("stageInfo_"+playerId, JSON.stringify(players[playerId]["stageInfo"]));
};

var getCoin = function(playerId) {
	var playerData = findPlayer(playerId);
	if (playerData == null || playerData["baseInfo"] == null || playerData["baseInfo"]["coin"] == null)
		return 0;
	return playerData["baseInfo"]["coin"]; 
};

var changeCoin = function(playerId, val) {
	var playerData = findPlayer(playerId);
	if (playerData == null || playerData["baseInfo"] == null || playerData["baseInfo"]["coin"] == null)
		return false;

	if (playerData["baseInfo"]["coin"] + val < 0)
		return false;

	playerData["baseInfo"]["coin"] = playerData["baseInfo"]["coin"] + val;
	redisManager.setValue("baseInfo_"+playerId, JSON.stringify(playerData["baseInfo"]));

	return true;
};

var changeCandy = function(playerId, val) {
	var playerData = findPlayer(playerId);
	if (playerData == null || playerData["baseInfo"] == null || playerData["baseInfo"]["candy"] == null)
		return false;

	if (playerData["baseInfo"]["candy"] + val < 0)
		return false;

	playerData["baseInfo"]["candy"] = playerData["baseInfo"]["candy"] + val;
	redisManager.setValue("baseInfo_"+playerId, JSON.stringify(playerData["baseInfo"]));

	return true;
};

var getPlayerMapInfo = function(playerId) {
	if (findPlayer(playerId) == null)
		return null;

	return players[playerId]["mapInfo"];
};

var playerAddMap = function(playerId, mapId, mapInfo, isBuy) {
	if (isBuy == true){
		players[playerId]["mapInfo"]["download"][""+mapId] = mapInfo
	}else{
		players[playerId]["mapInfo"]["upload"][""+mapId] = mapInfo
	}
	redisManager.setValue("mapInfo_"+playerId, JSON.stringify(players[playerId]["mapInfo"]));
};


exports.initPlayerMananger = initPlayerMananger;
exports.findPlayer = findPlayer;
exports.findNewPlayerId = findNewPlayerId;
exports.getPlayerLoadFlag = getPlayerLoadFlag;
exports.loadPlayer = loadPlayer;
exports.changeCoin = changeCoin;
exports.changeCandy = changeCandy;
exports.updateStageInfo = updateStageInfo;
exports.getPlayerMapInfo = getPlayerMapInfo;
exports.playerAddMap = playerAddMap;
exports.getCoin = getCoin;
