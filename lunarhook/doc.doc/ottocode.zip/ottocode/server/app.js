var express = require("express");
var http = require("http");

var route = require("./server/route");
var log = require("./server/log");

var redis = require("./server/redis_manager");
redis.initClient();

var playerManager = require("./server/player_manager");
playerManager.initPlayerMananger();

var mapManager = require("./server/map_manager");
mapManager.initMapList();



var app = express();

app.use(log.recv_packet_log());
app.use("/login", route.login());
app.use("/shoplist", route.shoplist());
app.use("/shopbuy", route.shopbuy());
app.use("/upload", route.upload());
app.use("/mapInfo", route.getMapInfo());
app.use("/rank", route.getRank());
app.use("/stagecomplete", route.stageComplete());

app.post("/*", function(req, resp) {
	console.log("--- unregister protocol POST --- ");

	resp.end();
});

app.get("/*", function(req, resp) {
	console.log("--- unregister protocol GET --- ");

	resp.end();
});

app.listen(1337);

